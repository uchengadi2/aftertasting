# ext-theme-neptune-703c9aa8-350a-4397-b2d2-0050ce4bfab2/resources

This folder contains static resources (typically an `"images"` folder as well).
