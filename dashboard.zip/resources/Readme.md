# ext-theme-neptune-cfa70380-38b3-4e56-a8b9-9caeea766557/resources

This folder contains static resources (typically an `"images"` folder as well).
