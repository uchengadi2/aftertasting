<?php

/**
 * This is the model class for table "domain_verification_outcome".
 *
 * The followings are the available columns in table 'domain_verification_outcome':
 * @property string $id
 * @property string $domain_id
 * @property integer $is_name_verification_requested
 * @property integer $is_address_verification_requested
 * @property integer $is_registration_number_verification_requested
 * @property integer $is_website_verification_requested
 * @property integer $is_email_verification_requested
 * @property integer $is_wechat_verification_requested
 * @property integer $is_telegram_verification_requested
 * @property integer $is_whatsapp_verification_requested
 * @property integer $is_facebook_verification_requested
 * @property integer $is_tweeter_verification_requested
 * @property integer $is_youtube_verification_requested
 * @property integer $is_logo_verification_requested
 * @property integer $is_first_telephone_number_verification_requested
 * @property integer $is_second_telephone_number_verification_requested
 * @property integer $is_name_verified
 * @property integer $is_address_verified
 * @property integer $is_registration_number_verified
 * @property integer $is_website_verified
 * @property integer $is_email_verified
 * @property integer $is_wechat_verified
 * @property integer $is_telegram_verified
 * @property integer $is_whatsapp_verified
 * @property integer $is_facebook_verified
 * @property integer $is_tweeter_verified
 * @property integer $is_youtube_verified
 * @property integer $is_logo_verified
 * @property integer $is_first_telephone_number_verified
 * @property integer $is_second_telephone_number_verified
 * @property string $date_name_was_verified
 * @property integer $name_was_verified_by
 * @property string $date_address_was_verified
 * @property integer $address_was_verified_by
 * @property string $date_registration_number_was_verified
 * @property integer $registration_number_was_verified_by
 * @property string $date_website_was_verified
 * @property integer $website_was_verified_by
 * @property string $date_email_was_verified
 * @property integer $email_was_verified_by
 * @property string $date_wechat_was_verified
 * @property integer $wechat_was_verified_by
 * @property string $date_telegram_was_verified
 * @property integer $telegram_was_verified_by
 * @property string $date_whatsapp_was_verified
 * @property integer $whatsapp_was_verified_by
 * @property string $date_facebook_was_verified
 * @property integer $facebook_was_verified_by
 * @property string $date_tweeter_was_verified
 * @property integer $tweeter_was_verified_by
 * @property string $date_youtube_was_verified
 * @property integer $youtube_was_verified_by
 * @property string $date_logo_was_verified
 * @property integer $logo_was_verified_by
 * @property string $date_first_telephone_number_was_verified
 * @property integer $first_telephone_number_was_verified_by
 * @property string $date_second_telephone_number_was_verified
 * @property integer $second_telephone_number_was_verified_by
 * @property string $date_name_verification_was_requested
 * @property integer $name_verification_was_requested_by
 * @property string $date_address_verification_was_requested
 * @property integer $address_verification_was_requested_by
 * @property string $date_registration_number_verification_was_requested
 * @property integer $registration_number_verification_was_requested_by
 * @property string $date_website_verification_was_requested
 * @property integer $website_verification_was_requested_by
 * @property string $date_email_verification_was_requested
 * @property integer $email_verification_was_requested_by
 * @property string $date_wechat_verification_was_requested
 * @property integer $wechat_verification_was_requested_by
 * @property string $date_telegram_verification_was_requested
 * @property integer $telegram_verification_was_requested_by
 * @property string $date_whatsapp_verification_was_requested
 * @property integer $whatsapp_verification_was_requested_by
 * @property string $date_facebook_verification_was_requested
 * @property integer $facebook_verification_was_requested_by
 * @property string $date_tweeter_verification_was_requested
 * @property integer $tweeter_verification_was_requested_by
 * @property string $date_youtube_verification_was_requested
 * @property integer $youtube_verification_was_requested_by
 * @property string $date_logo_verification_was_requested
 * @property integer $logo_verification_was_requested_by
 * @property string $date_first_telephone_number_verification_was_requested
 * @property integer $first_telephone_number_verification_was_requested_by
 * @property string $date_second_telephone_number_verification_was_requested
 * @property integer $second_telephone_number_verification_was_requested_by
 * @property integer $is_website_expiry_date_requested
 * @property integer $is_residency_expiry_date_requested
 * @property integer $is_instagram_verification_requested
 * @property integer $is_instagram_verified
 * @property string $date_instagram_was_verified
 * @property integer $instagram_was_verified_by
 * @property string $date_instagram_verification_was_requested
 * @property integer $instagram_verification_was_requested_by
 * @property integer $is_residency_expiry_date_verified
 * @property integer $is_website_expiry_date_verified
 */
class DomainVerificationOutcome extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_verification_outcome';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id', 'required'),
			array('is_name_verification_requested, is_address_verification_requested, is_registration_number_verification_requested, is_website_verification_requested, is_email_verification_requested, is_wechat_verification_requested, is_telegram_verification_requested, is_whatsapp_verification_requested, is_facebook_verification_requested, is_tweeter_verification_requested, is_youtube_verification_requested, is_logo_verification_requested, is_first_telephone_number_verification_requested, is_second_telephone_number_verification_requested, is_name_verified, is_address_verified, is_registration_number_verified, is_website_verified, is_email_verified, is_wechat_verified, is_telegram_verified, is_whatsapp_verified, is_facebook_verified, is_tweeter_verified, is_youtube_verified, is_logo_verified, is_first_telephone_number_verified, is_second_telephone_number_verified, name_was_verified_by, address_was_verified_by, registration_number_was_verified_by, website_was_verified_by, email_was_verified_by, wechat_was_verified_by, telegram_was_verified_by, whatsapp_was_verified_by, facebook_was_verified_by, tweeter_was_verified_by, youtube_was_verified_by, logo_was_verified_by, first_telephone_number_was_verified_by, second_telephone_number_was_verified_by, name_verification_was_requested_by, address_verification_was_requested_by, registration_number_verification_was_requested_by, website_verification_was_requested_by, email_verification_was_requested_by, wechat_verification_was_requested_by, telegram_verification_was_requested_by, whatsapp_verification_was_requested_by, facebook_verification_was_requested_by, tweeter_verification_was_requested_by, youtube_verification_was_requested_by, logo_verification_was_requested_by, first_telephone_number_verification_was_requested_by, second_telephone_number_verification_was_requested_by, is_website_expiry_date_requested, is_residency_expiry_date_requested, is_instagram_verification_requested, is_instagram_verified, instagram_was_verified_by, instagram_verification_was_requested_by, is_residency_expiry_date_verified, is_website_expiry_date_verified', 'numerical', 'integerOnly'=>true),
			array('domain_id', 'length', 'max'=>10),
			array('date_name_was_verified, date_address_was_verified, date_registration_number_was_verified, date_website_was_verified, date_email_was_verified, date_wechat_was_verified, date_telegram_was_verified, date_whatsapp_was_verified, date_facebook_was_verified, date_tweeter_was_verified, date_youtube_was_verified, date_logo_was_verified, date_first_telephone_number_was_verified, date_second_telephone_number_was_verified, date_name_verification_was_requested, date_address_verification_was_requested, date_registration_number_verification_was_requested, date_website_verification_was_requested, date_email_verification_was_requested, date_wechat_verification_was_requested, date_telegram_verification_was_requested, date_whatsapp_verification_was_requested, date_facebook_verification_was_requested, date_tweeter_verification_was_requested, date_youtube_verification_was_requested, date_logo_verification_was_requested, date_first_telephone_number_verification_was_requested, date_second_telephone_number_verification_was_requested, date_instagram_was_verified, date_instagram_verification_was_requested', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, domain_id, is_name_verification_requested, is_address_verification_requested, is_registration_number_verification_requested, is_website_verification_requested, is_email_verification_requested, is_wechat_verification_requested, is_telegram_verification_requested, is_whatsapp_verification_requested, is_facebook_verification_requested, is_tweeter_verification_requested, is_youtube_verification_requested, is_logo_verification_requested, is_first_telephone_number_verification_requested, is_second_telephone_number_verification_requested, is_name_verified, is_address_verified, is_registration_number_verified, is_website_verified, is_email_verified, is_wechat_verified, is_telegram_verified, is_whatsapp_verified, is_facebook_verified, is_tweeter_verified, is_youtube_verified, is_logo_verified, is_first_telephone_number_verified, is_second_telephone_number_verified, date_name_was_verified, name_was_verified_by, date_address_was_verified, address_was_verified_by, date_registration_number_was_verified, registration_number_was_verified_by, date_website_was_verified, website_was_verified_by, date_email_was_verified, email_was_verified_by, date_wechat_was_verified, wechat_was_verified_by, date_telegram_was_verified, telegram_was_verified_by, date_whatsapp_was_verified, whatsapp_was_verified_by, date_facebook_was_verified, facebook_was_verified_by, date_tweeter_was_verified, tweeter_was_verified_by, date_youtube_was_verified, youtube_was_verified_by, date_logo_was_verified, logo_was_verified_by, date_first_telephone_number_was_verified, first_telephone_number_was_verified_by, date_second_telephone_number_was_verified, second_telephone_number_was_verified_by, date_name_verification_was_requested, name_verification_was_requested_by, date_address_verification_was_requested, address_verification_was_requested_by, date_registration_number_verification_was_requested, registration_number_verification_was_requested_by, date_website_verification_was_requested, website_verification_was_requested_by, date_email_verification_was_requested, email_verification_was_requested_by, date_wechat_verification_was_requested, wechat_verification_was_requested_by, date_telegram_verification_was_requested, telegram_verification_was_requested_by, date_whatsapp_verification_was_requested, whatsapp_verification_was_requested_by, date_facebook_verification_was_requested, facebook_verification_was_requested_by, date_tweeter_verification_was_requested, tweeter_verification_was_requested_by, date_youtube_verification_was_requested, youtube_verification_was_requested_by, date_logo_verification_was_requested, logo_verification_was_requested_by, date_first_telephone_number_verification_was_requested, first_telephone_number_verification_was_requested_by, date_second_telephone_number_verification_was_requested, second_telephone_number_verification_was_requested_by, is_website_expiry_date_requested, is_residency_expiry_date_requested, is_instagram_verification_requested, is_instagram_verified, date_instagram_was_verified, instagram_was_verified_by, date_instagram_verification_was_requested, instagram_verification_was_requested_by, is_residency_expiry_date_verified, is_website_expiry_date_verified', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'domain_id' => 'Domain',
			'is_name_verification_requested' => 'Is Name Verification Requested',
			'is_address_verification_requested' => 'Is Address Verification Requested',
			'is_registration_number_verification_requested' => 'Is Registration Number Verification Requested',
			'is_website_verification_requested' => 'Is Website Verification Requested',
			'is_email_verification_requested' => 'Is Email Verification Requested',
			'is_wechat_verification_requested' => 'Is Wechat Verification Requested',
			'is_telegram_verification_requested' => 'Is Telegram Verification Requested',
			'is_whatsapp_verification_requested' => 'Is Whatsapp Verification Requested',
			'is_facebook_verification_requested' => 'Is Facebook Verification Requested',
			'is_tweeter_verification_requested' => 'Is Tweeter Verification Requested',
			'is_youtube_verification_requested' => 'Is Youtube Verification Requested',
			'is_logo_verification_requested' => 'Is Logo Verification Requested',
			'is_first_telephone_number_verification_requested' => 'Is First Telephone Number Verification Requested',
			'is_second_telephone_number_verification_requested' => 'Is Second Telephone Number Verification Requested',
			'is_name_verified' => 'Is Name Verified',
			'is_address_verified' => 'Is Address Verified',
			'is_registration_number_verified' => 'Is Registration Number Verified',
			'is_website_verified' => 'Is Website Verified',
			'is_email_verified' => 'Is Email Verified',
			'is_wechat_verified' => 'Is Wechat Verified',
			'is_telegram_verified' => 'Is Telegram Verified',
			'is_whatsapp_verified' => 'Is Whatsapp Verified',
			'is_facebook_verified' => 'Is Facebook Verified',
			'is_tweeter_verified' => 'Is Tweeter Verified',
			'is_youtube_verified' => 'Is Youtube Verified',
			'is_logo_verified' => 'Is Logo Verified',
			'is_first_telephone_number_verified' => 'Is First Telephone Number Verified',
			'is_second_telephone_number_verified' => 'Is Second Telephone Number Verified',
			'date_name_was_verified' => 'Date Name Was Verified',
			'name_was_verified_by' => 'Name Was Verified By',
			'date_address_was_verified' => 'Date Address Was Verified',
			'address_was_verified_by' => 'Address Was Verified By',
			'date_registration_number_was_verified' => 'Date Registration Number Was Verified',
			'registration_number_was_verified_by' => 'Registration Number Was Verified By',
			'date_website_was_verified' => 'Date Website Was Verified',
			'website_was_verified_by' => 'Website Was Verified By',
			'date_email_was_verified' => 'Date Email Was Verified',
			'email_was_verified_by' => 'Email Was Verified By',
			'date_wechat_was_verified' => 'Date Wechat Was Verified',
			'wechat_was_verified_by' => 'Wechat Was Verified By',
			'date_telegram_was_verified' => 'Date Telegram Was Verified',
			'telegram_was_verified_by' => 'Telegram Was Verified By',
			'date_whatsapp_was_verified' => 'Date Whatsapp Was Verified',
			'whatsapp_was_verified_by' => 'Whatsapp Was Verified By',
			'date_facebook_was_verified' => 'Date Facebook Was Verified',
			'facebook_was_verified_by' => 'Facebook Was Verified By',
			'date_tweeter_was_verified' => 'Date Tweeter Was Verified',
			'tweeter_was_verified_by' => 'Tweeter Was Verified By',
			'date_youtube_was_verified' => 'Date Youtube Was Verified',
			'youtube_was_verified_by' => 'Youtube Was Verified By',
			'date_logo_was_verified' => 'Date Logo Was Verified',
			'logo_was_verified_by' => 'Logo Was Verified By',
			'date_first_telephone_number_was_verified' => 'Date First Telephone Number Was Verified',
			'first_telephone_number_was_verified_by' => 'First Telephone Number Was Verified By',
			'date_second_telephone_number_was_verified' => 'Date Second Telephone Number Was Verified',
			'second_telephone_number_was_verified_by' => 'Second Telephone Number Was Verified By',
			'date_name_verification_was_requested' => 'Date Name Verification Was Requested',
			'name_verification_was_requested_by' => 'Name Verification Was Requested By',
			'date_address_verification_was_requested' => 'Date Address Verification Was Requested',
			'address_verification_was_requested_by' => 'Address Verification Was Requested By',
			'date_registration_number_verification_was_requested' => 'Date Registration Number Verification Was Requested',
			'registration_number_verification_was_requested_by' => 'Registration Number Verification Was Requested By',
			'date_website_verification_was_requested' => 'Date Website Verification Was Requested',
			'website_verification_was_requested_by' => 'Website Verification Was Requested By',
			'date_email_verification_was_requested' => 'Date Email Verification Was Requested',
			'email_verification_was_requested_by' => 'Email Verification Was Requested By',
			'date_wechat_verification_was_requested' => 'Date Wechat Verification Was Requested',
			'wechat_verification_was_requested_by' => 'Wechat Verification Was Requested By',
			'date_telegram_verification_was_requested' => 'Date Telegram Verification Was Requested',
			'telegram_verification_was_requested_by' => 'Telegram Verification Was Requested By',
			'date_whatsapp_verification_was_requested' => 'Date Whatsapp Verification Was Requested',
			'whatsapp_verification_was_requested_by' => 'Whatsapp Verification Was Requested By',
			'date_facebook_verification_was_requested' => 'Date Facebook Verification Was Requested',
			'facebook_verification_was_requested_by' => 'Facebook Verification Was Requested By',
			'date_tweeter_verification_was_requested' => 'Date Tweeter Verification Was Requested',
			'tweeter_verification_was_requested_by' => 'Tweeter Verification Was Requested By',
			'date_youtube_verification_was_requested' => 'Date Youtube Verification Was Requested',
			'youtube_verification_was_requested_by' => 'Youtube Verification Was Requested By',
			'date_logo_verification_was_requested' => 'Date Logo Verification Was Requested',
			'logo_verification_was_requested_by' => 'Logo Verification Was Requested By',
			'date_first_telephone_number_verification_was_requested' => 'Date First Telephone Number Verification Was Requested',
			'first_telephone_number_verification_was_requested_by' => 'First Telephone Number Verification Was Requested By',
			'date_second_telephone_number_verification_was_requested' => 'Date Second Telephone Number Verification Was Requested',
			'second_telephone_number_verification_was_requested_by' => 'Second Telephone Number Verification Was Requested By',
			'is_website_expiry_date_requested' => 'Is Website Expiry Date Requested',
			'is_residency_expiry_date_requested' => 'Is Residency Expiry Date Requested',
			'is_instagram_verification_requested' => 'Is Instagram Verification Requested',
			'is_instagram_verified' => 'Is Instagram Verified',
			'date_instagram_was_verified' => 'Date Instagram Was Verified',
			'instagram_was_verified_by' => 'Instagram Was Verified By',
			'date_instagram_verification_was_requested' => 'Date Instagram Verification Was Requested',
			'instagram_verification_was_requested_by' => 'Instagram Verification Was Requested By',
			'is_residency_expiry_date_verified' => 'Is Residency Expiry Date Verified',
			'is_website_expiry_date_verified' => 'Is Website Expiry Date Verified',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('is_name_verification_requested',$this->is_name_verification_requested);
		$criteria->compare('is_address_verification_requested',$this->is_address_verification_requested);
		$criteria->compare('is_registration_number_verification_requested',$this->is_registration_number_verification_requested);
		$criteria->compare('is_website_verification_requested',$this->is_website_verification_requested);
		$criteria->compare('is_email_verification_requested',$this->is_email_verification_requested);
		$criteria->compare('is_wechat_verification_requested',$this->is_wechat_verification_requested);
		$criteria->compare('is_telegram_verification_requested',$this->is_telegram_verification_requested);
		$criteria->compare('is_whatsapp_verification_requested',$this->is_whatsapp_verification_requested);
		$criteria->compare('is_facebook_verification_requested',$this->is_facebook_verification_requested);
		$criteria->compare('is_tweeter_verification_requested',$this->is_tweeter_verification_requested);
		$criteria->compare('is_youtube_verification_requested',$this->is_youtube_verification_requested);
		$criteria->compare('is_logo_verification_requested',$this->is_logo_verification_requested);
		$criteria->compare('is_first_telephone_number_verification_requested',$this->is_first_telephone_number_verification_requested);
		$criteria->compare('is_second_telephone_number_verification_requested',$this->is_second_telephone_number_verification_requested);
		$criteria->compare('is_name_verified',$this->is_name_verified);
		$criteria->compare('is_address_verified',$this->is_address_verified);
		$criteria->compare('is_registration_number_verified',$this->is_registration_number_verified);
		$criteria->compare('is_website_verified',$this->is_website_verified);
		$criteria->compare('is_email_verified',$this->is_email_verified);
		$criteria->compare('is_wechat_verified',$this->is_wechat_verified);
		$criteria->compare('is_telegram_verified',$this->is_telegram_verified);
		$criteria->compare('is_whatsapp_verified',$this->is_whatsapp_verified);
		$criteria->compare('is_facebook_verified',$this->is_facebook_verified);
		$criteria->compare('is_tweeter_verified',$this->is_tweeter_verified);
		$criteria->compare('is_youtube_verified',$this->is_youtube_verified);
		$criteria->compare('is_logo_verified',$this->is_logo_verified);
		$criteria->compare('is_first_telephone_number_verified',$this->is_first_telephone_number_verified);
		$criteria->compare('is_second_telephone_number_verified',$this->is_second_telephone_number_verified);
		$criteria->compare('date_name_was_verified',$this->date_name_was_verified,true);
		$criteria->compare('name_was_verified_by',$this->name_was_verified_by);
		$criteria->compare('date_address_was_verified',$this->date_address_was_verified,true);
		$criteria->compare('address_was_verified_by',$this->address_was_verified_by);
		$criteria->compare('date_registration_number_was_verified',$this->date_registration_number_was_verified,true);
		$criteria->compare('registration_number_was_verified_by',$this->registration_number_was_verified_by);
		$criteria->compare('date_website_was_verified',$this->date_website_was_verified,true);
		$criteria->compare('website_was_verified_by',$this->website_was_verified_by);
		$criteria->compare('date_email_was_verified',$this->date_email_was_verified,true);
		$criteria->compare('email_was_verified_by',$this->email_was_verified_by);
		$criteria->compare('date_wechat_was_verified',$this->date_wechat_was_verified,true);
		$criteria->compare('wechat_was_verified_by',$this->wechat_was_verified_by);
		$criteria->compare('date_telegram_was_verified',$this->date_telegram_was_verified,true);
		$criteria->compare('telegram_was_verified_by',$this->telegram_was_verified_by);
		$criteria->compare('date_whatsapp_was_verified',$this->date_whatsapp_was_verified,true);
		$criteria->compare('whatsapp_was_verified_by',$this->whatsapp_was_verified_by);
		$criteria->compare('date_facebook_was_verified',$this->date_facebook_was_verified,true);
		$criteria->compare('facebook_was_verified_by',$this->facebook_was_verified_by);
		$criteria->compare('date_tweeter_was_verified',$this->date_tweeter_was_verified,true);
		$criteria->compare('tweeter_was_verified_by',$this->tweeter_was_verified_by);
		$criteria->compare('date_youtube_was_verified',$this->date_youtube_was_verified,true);
		$criteria->compare('youtube_was_verified_by',$this->youtube_was_verified_by);
		$criteria->compare('date_logo_was_verified',$this->date_logo_was_verified,true);
		$criteria->compare('logo_was_verified_by',$this->logo_was_verified_by);
		$criteria->compare('date_first_telephone_number_was_verified',$this->date_first_telephone_number_was_verified,true);
		$criteria->compare('first_telephone_number_was_verified_by',$this->first_telephone_number_was_verified_by);
		$criteria->compare('date_second_telephone_number_was_verified',$this->date_second_telephone_number_was_verified,true);
		$criteria->compare('second_telephone_number_was_verified_by',$this->second_telephone_number_was_verified_by);
		$criteria->compare('date_name_verification_was_requested',$this->date_name_verification_was_requested,true);
		$criteria->compare('name_verification_was_requested_by',$this->name_verification_was_requested_by);
		$criteria->compare('date_address_verification_was_requested',$this->date_address_verification_was_requested,true);
		$criteria->compare('address_verification_was_requested_by',$this->address_verification_was_requested_by);
		$criteria->compare('date_registration_number_verification_was_requested',$this->date_registration_number_verification_was_requested,true);
		$criteria->compare('registration_number_verification_was_requested_by',$this->registration_number_verification_was_requested_by);
		$criteria->compare('date_website_verification_was_requested',$this->date_website_verification_was_requested,true);
		$criteria->compare('website_verification_was_requested_by',$this->website_verification_was_requested_by);
		$criteria->compare('date_email_verification_was_requested',$this->date_email_verification_was_requested,true);
		$criteria->compare('email_verification_was_requested_by',$this->email_verification_was_requested_by);
		$criteria->compare('date_wechat_verification_was_requested',$this->date_wechat_verification_was_requested,true);
		$criteria->compare('wechat_verification_was_requested_by',$this->wechat_verification_was_requested_by);
		$criteria->compare('date_telegram_verification_was_requested',$this->date_telegram_verification_was_requested,true);
		$criteria->compare('telegram_verification_was_requested_by',$this->telegram_verification_was_requested_by);
		$criteria->compare('date_whatsapp_verification_was_requested',$this->date_whatsapp_verification_was_requested,true);
		$criteria->compare('whatsapp_verification_was_requested_by',$this->whatsapp_verification_was_requested_by);
		$criteria->compare('date_facebook_verification_was_requested',$this->date_facebook_verification_was_requested,true);
		$criteria->compare('facebook_verification_was_requested_by',$this->facebook_verification_was_requested_by);
		$criteria->compare('date_tweeter_verification_was_requested',$this->date_tweeter_verification_was_requested,true);
		$criteria->compare('tweeter_verification_was_requested_by',$this->tweeter_verification_was_requested_by);
		$criteria->compare('date_youtube_verification_was_requested',$this->date_youtube_verification_was_requested,true);
		$criteria->compare('youtube_verification_was_requested_by',$this->youtube_verification_was_requested_by);
		$criteria->compare('date_logo_verification_was_requested',$this->date_logo_verification_was_requested,true);
		$criteria->compare('logo_verification_was_requested_by',$this->logo_verification_was_requested_by);
		$criteria->compare('date_first_telephone_number_verification_was_requested',$this->date_first_telephone_number_verification_was_requested,true);
		$criteria->compare('first_telephone_number_verification_was_requested_by',$this->first_telephone_number_verification_was_requested_by);
		$criteria->compare('date_second_telephone_number_verification_was_requested',$this->date_second_telephone_number_verification_was_requested,true);
		$criteria->compare('second_telephone_number_verification_was_requested_by',$this->second_telephone_number_verification_was_requested_by);
		$criteria->compare('is_website_expiry_date_requested',$this->is_website_expiry_date_requested);
		$criteria->compare('is_residency_expiry_date_requested',$this->is_residency_expiry_date_requested);
		$criteria->compare('is_instagram_verification_requested',$this->is_instagram_verification_requested);
		$criteria->compare('is_instagram_verified',$this->is_instagram_verified);
		$criteria->compare('date_instagram_was_verified',$this->date_instagram_was_verified,true);
		$criteria->compare('instagram_was_verified_by',$this->instagram_was_verified_by);
		$criteria->compare('date_instagram_verification_was_requested',$this->date_instagram_verification_was_requested,true);
		$criteria->compare('instagram_verification_was_requested_by',$this->instagram_verification_was_requested_by);
		$criteria->compare('is_residency_expiry_date_verified',$this->is_residency_expiry_date_verified);
		$criteria->compare('is_website_expiry_date_verified',$this->is_website_expiry_date_verified);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainVerificationOutcome the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
