<?php

/**
 * This is the model class for table "payment".
 *
 * The followings are the available columns in table 'payment':
 * @property string $id
 * @property string $status
 * @property string $payment_mode
 * @property string $invoice_number
 * @property string $order_id
 * @property string $toolbox_id
 * @property integer $subscribers
 * @property string $last_service_end_date
 * @property string $remark
 * @property double $net_amount
 * @property double $gross_amount
 * @property double $discounted_amount
 * @property double $vat
 * @property string $payee_domain_id
 * @property string $payment_date
 * @property string $paid_by
 * @property string $payment_confirmed_by
 *
 * The followings are the available model relations:
 * @property Resourcegroupcategory $payeeDomain
 * @property User $paidBy
 * @property Order $order
 */
class Payment extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'payment';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('status, order_id, toolbox_id, net_amount, gross_amount, payee_domain_id, paid_by, payment_confirmed_by', 'required'),
			array('subscribers', 'numerical', 'integerOnly'=>true),
			array('net_amount, gross_amount, discounted_amount, vat', 'numerical'),
			array('status', 'length', 'max'=>11),
			array('payment_mode', 'length', 'max'=>17),
			array('invoice_number', 'length', 'max'=>50),
			array('order_id, toolbox_id, payee_domain_id, paid_by, payment_confirmed_by', 'length', 'max'=>10),
			array('remark', 'length', 'max'=>200),
			array('last_service_end_date, payment_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, status, payment_mode, invoice_number, order_id, toolbox_id, subscribers, last_service_end_date, remark, net_amount, gross_amount, discounted_amount, vat, payee_domain_id, payment_date, paid_by, payment_confirmed_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'payeeDomain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'payee_domain_id'),
			'paidBy' => array(self::BELONGS_TO, 'User', 'paid_by'),
			'order' => array(self::BELONGS_TO, 'Order', 'order_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'status' => 'Status',
			'payment_mode' => 'Payment Mode',
			'invoice_number' => 'Invoice Number',
			'order_id' => 'Order',
			'toolbox_id' => 'Toolbox',
			'subscribers' => 'Subscribers',
			'last_service_end_date' => 'Last Service End Date',
			'remark' => 'Remark',
			'net_amount' => 'Net Amount',
			'gross_amount' => 'Gross Amount',
			'discounted_amount' => 'Discounted Amount',
			'vat' => 'Vat',
			'payee_domain_id' => 'Payee Domain',
			'payment_date' => 'Payment Date',
			'paid_by' => 'Paid By',
			'payment_confirmed_by' => 'Payment Confirmed By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('payment_mode',$this->payment_mode,true);
		$criteria->compare('invoice_number',$this->invoice_number,true);
		$criteria->compare('order_id',$this->order_id,true);
		$criteria->compare('toolbox_id',$this->toolbox_id,true);
		$criteria->compare('subscribers',$this->subscribers);
		$criteria->compare('last_service_end_date',$this->last_service_end_date,true);
		$criteria->compare('remark',$this->remark,true);
		$criteria->compare('net_amount',$this->net_amount);
		$criteria->compare('gross_amount',$this->gross_amount);
		$criteria->compare('discounted_amount',$this->discounted_amount);
		$criteria->compare('vat',$this->vat);
		$criteria->compare('payee_domain_id',$this->payee_domain_id,true);
		$criteria->compare('payment_date',$this->payment_date,true);
		$criteria->compare('paid_by',$this->paid_by,true);
		$criteria->compare('payment_confirmed_by',$this->payment_confirmed_by,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Payment the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
