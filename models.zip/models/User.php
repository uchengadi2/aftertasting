<?php

/**
 * This is the model class for table "user".
 *
 * The followings are the available columns in table 'user':
 * @property string $id
 * @property string $city_id
 * @property string $username
 * @property string $email
 * @property string $password
 * @property string $picture
 * @property integer $picture_size
 * @property string $status
 * @property string $firstname
 * @property string $middlename
 * @property string $lastname
 * @property string $domain_id
 * @property string $dateofbirth
 * @property string $religion
 * @property string $maritalstatus
 * @property string $gender
 * @property integer $is_profilable
 * @property integer $select_value
 * @property integer $login_device_id
 * @property string $login_time
 * @property string $logout_time
 * @property integer $is_first_time_user
 * @property string $first_login_time
 * @property string $last_login_time
 * @property integer $total_login_time
 * @property integer $daily_login_frequency
 * @property string $role
 * @property integer $max_device_allowable
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 * @property double $login_location_latitude
 * @property double $login_location_longtitude
 * @property double $logout_location_latitude
 * @property double $logout_location_longtitude
 * @property string $type
 * @property string $security_level
 * @property string $name
 * @property string $security_level_weight
 * @property string $home_address
 * @property string $nationality
 * @property string $instrument_of_identification
 * @property integer $mobile_number
 * @property string $identification_number
 * @property string $issuance_date
 * @property string $expiry_date
 * @property string $issuance_authority
 * @property string $bvn
 * @property string $nin
 * @property string $passport_number
 * @property string $driving_license_number
 * @property string $pvc
 * @property string $domain_name
 */
class User extends CActiveRecord
{
	
       private $_identity;
        public $password_repeat;
        public $current_pass;
    
    /**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
                        array('password,password_repeat','required', 'on' => 'insert' ),
			array('username, email, status, firstname, lastname, domain_id, role, type, security_level, name, security_level_weight', 'required'),
			array('picture_size, is_profilable, select_value, login_device_id, is_first_time_user, total_login_time, daily_login_frequency, max_device_allowable, create_user_id, update_user_id, mobile_number', 'numerical', 'integerOnly'=>true),
			array('login_location_latitude, login_location_longtitude, logout_location_latitude, logout_location_longtitude', 'numerical'),
			array('city_id, status, domain_id, maritalstatus', 'length', 'max'=>10),
			array('username, email, lastname', 'length', 'max'=>100),
                        array('username', 'required', 'on' => 'insert'),
                        array('username, email', 'unique'),
                        array('password', 'authenticate', 'on' => 'login'),
			array('password, picture, firstname, middlename, bvn, nin, passport_number, driving_license_number, pvc, domain_name', 'length', 'max'=>60),
			array('password, password_repeat', 'length', 'min'=>8, 'max'=>60, 'tooShort'=>'Your Password is less than eight(8) characters', 'tooLong'=>'Password cannot be greater than 60 characters'),
                        array('password, picture, firstname, middlename', 'length', 'max'=>60),
                        array('password, password_repeat', 'match', 'pattern'=>'/^.*(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])(?=.*[\W]).*$/', 'message'=>'Password must have at least one capital letter, at least one number, at least one special character, and at least a lower case letter'),
                        array('religion', 'length', 'max'=>12),
			array('gender, type', 'length', 'max'=>6),
			array('role', 'length', 'max'=>64),
			array('security_level', 'length', 'max'=>11),
			array('name, home_address, nationality, issuance_authority', 'length', 'max'=>250),
			array('security_level_weight', 'length', 'max'=>2),
			array('instrument_of_identification', 'length', 'max'=>22),
			array('identification_number', 'length', 'max'=>200),
			array('dateofbirth, login_time, logout_time, first_login_time, last_login_time, create_time, update_time, issuance_date, expiry_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, city_id, username, email, password, picture, picture_size, status, firstname, middlename, lastname, domain_id, dateofbirth, religion, maritalstatus, gender, is_profilable, select_value, login_device_id, login_time, logout_time, is_first_time_user, first_login_time, last_login_time, total_login_time, daily_login_frequency, role, max_device_allowable, create_time, create_user_id, update_time, update_user_id, login_location_latitude, login_location_longtitude, logout_location_latitude, logout_location_longtitude, type, security_level, name, security_level_weight, home_address, nationality, instrument_of_identification, mobile_number, identification_number, issuance_date, expiry_date, issuance_authority, bvn, nin, passport_number, driving_license_number, pvc, domain_name', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'city_id' => 'City',
			'username' => 'Username',
			'email' => 'Email',
			'password' => 'Password',
			'picture' => 'Picture',
			'picture_size' => 'Picture Size',
			'status' => 'Status',
			'firstname' => 'Firstname',
			'middlename' => 'Middlename',
			'lastname' => 'Lastname',
			'domain_id' => 'Domain',
			'dateofbirth' => 'Dateofbirth',
			'religion' => 'Religion',
			'maritalstatus' => 'Maritalstatus',
			'gender' => 'Gender',
			'is_profilable' => 'Is Profilable',
			'select_value' => 'Select Value',
			'login_device_id' => 'Login Device',
			'login_time' => 'Login Time',
			'logout_time' => 'Logout Time',
			'is_first_time_user' => 'Is First Time User',
			'first_login_time' => 'First Login Time',
			'last_login_time' => 'Last Login Time',
			'total_login_time' => 'Total Login Time',
			'daily_login_frequency' => 'Daily Login Frequency',
			'role' => 'Role',
			'max_device_allowable' => 'Max Device Allowable',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
			'login_location_latitude' => 'Login Location Latitude',
			'login_location_longtitude' => 'Login Location Longtitude',
			'logout_location_latitude' => 'Logout Location Latitude',
			'logout_location_longtitude' => 'Logout Location Longtitude',
			'type' => 'Type',
			'security_level' => 'Security Level',
			'name' => 'Name',
			'security_level_weight' => 'Security Level Weight',
			'home_address' => 'Home Address',
			'nationality' => 'Nationality',
			'instrument_of_identification' => 'Instrument Of Identification',
			'mobile_number' => 'Mobile Number',
			'identification_number' => 'Identification Number',
			'issuance_date' => 'Issuance Date',
			'expiry_date' => 'Expiry Date',
			'issuance_authority' => 'Issuance Authority',
			'bvn' => 'Bvn',
			'nin' => 'Nin',
			'passport_number' => 'Passport Number',
			'driving_license_number' => 'Driving License Number',
			'pvc' => 'Pvc',
			'domain_name' => 'Domain Name',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('city_id',$this->city_id,true);
		$criteria->compare('username',$this->username,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('password',$this->password,true);
		$criteria->compare('picture',$this->picture,true);
		$criteria->compare('picture_size',$this->picture_size);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('firstname',$this->firstname,true);
		$criteria->compare('middlename',$this->middlename,true);
		$criteria->compare('lastname',$this->lastname,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('dateofbirth',$this->dateofbirth,true);
		$criteria->compare('religion',$this->religion,true);
		$criteria->compare('maritalstatus',$this->maritalstatus,true);
		$criteria->compare('gender',$this->gender,true);
		$criteria->compare('is_profilable',$this->is_profilable);
		$criteria->compare('select_value',$this->select_value);
		$criteria->compare('login_device_id',$this->login_device_id);
		$criteria->compare('login_time',$this->login_time,true);
		$criteria->compare('logout_time',$this->logout_time,true);
		$criteria->compare('is_first_time_user',$this->is_first_time_user);
		$criteria->compare('first_login_time',$this->first_login_time,true);
		$criteria->compare('last_login_time',$this->last_login_time,true);
		$criteria->compare('total_login_time',$this->total_login_time);
		$criteria->compare('daily_login_frequency',$this->daily_login_frequency);
		$criteria->compare('role',$this->role,true);
		$criteria->compare('max_device_allowable',$this->max_device_allowable);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('login_location_latitude',$this->login_location_latitude);
		$criteria->compare('login_location_longtitude',$this->login_location_longtitude);
		$criteria->compare('logout_location_latitude',$this->logout_location_latitude);
		$criteria->compare('logout_location_longtitude',$this->logout_location_longtitude);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('security_level',$this->security_level,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('security_level_weight',$this->security_level_weight,true);
		$criteria->compare('home_address',$this->home_address,true);
		$criteria->compare('nationality',$this->nationality,true);
		$criteria->compare('instrument_of_identification',$this->instrument_of_identification,true);
		$criteria->compare('mobile_number',$this->mobile_number);
		$criteria->compare('identification_number',$this->identification_number,true);
		$criteria->compare('issuance_date',$this->issuance_date,true);
		$criteria->compare('expiry_date',$this->expiry_date,true);
		$criteria->compare('issuance_authority',$this->issuance_authority,true);
		$criteria->compare('bvn',$this->bvn,true);
		$criteria->compare('nin',$this->nin,true);
		$criteria->compare('passport_number',$this->passport_number,true);
		$criteria->compare('driving_license_number',$this->driving_license_number,true);
		$criteria->compare('pvc',$this->pvc,true);
		$criteria->compare('domain_name',$this->domain_name,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return User the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /*
	 * Authenticates the password.
	 * This is the 'authenticate' validator as declared in rules().
	 */
	//public function authenticate($attribute,$params)
       public function authenticate($attribute,$params)
	{
		if(!$this->hasErrors())
		{
			$this->_identity=new UserIdentity($this->username,$this->password);
			if(!$this->_identity->authenticate())
				$this->addError('password','Incorrect username or password.');
		}
	}
        
        
        /**
	 * Logs in the user using the given username and password in the model.
	 * @return boolean whether login is successful
	 */
	public function login()
	{
		if($this->_identity===null)
		{
			
                        $this->_identity=new UserIdentity($this->username,$this->password);
			$this->_identity->authenticate();
		}
		if($this->_identity->errorCode===UserIdentity::ERROR_NONE)
		{
			//$duration=$this->rememberMe ? 3600*24*30 : 0; // 30 days
			Yii::app()->user->login($this->_identity);
			return true;
		}
		else
			return false;
	}
        
        /*
         * Hash the password for security reasons
         */
        public function hashPassword($password){
            
            //return md5($password);
           /**
            if (CRYPT_STD_DES == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_1']);
            }
            if (CRYPT_EXT_DES == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_2']);
            }
            if (CRYPT_MD5 == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_3']);
            }
            if (CRYPT_BLOWFISH == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_4']);
            }
            if (CRYPT_SHA256 == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_5']);
            }
            if (CRYPT_SHA512 == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_6']);
            }
            * 
            */
          $options = [
                
                'cost' => 11,
                'salt' => Yii::app()->params['encryptionKey_6']
            ];
            return password_hash($password,PASSWORD_BCRYPT, $options );
         
         
            
            
        }
        
        
        /**
         * Obtain the password validation for maximum length rules
         */
        
        public function getPasswordMaxLengthRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CStringValidator && $validator->max !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                if(is_string($password)){
                   
                        return(strlen($password)<=$validator->max);
                        
                    
                }
                
            }
            }
            
    }
    
    
      /**
         * Obtain the password validation for minimum length rules
         */
        
        public function getPasswordMinLengthRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CStringValidator && $validator->min !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                if(is_string($password)){
                   
                        return(strlen($password)>= $validator->min);
                        
                    
                }
                
            }
            }
            
    }
    
    
    /**
         * overwrite the beforeSave() function
         */
      
        public function beforeSave(){
            
            
                if(parent::beforeSave()){
                  if($this->password !== ''){
                      $pass = $this->hashPassword($this->password);
                      //$pass = md5($this->password);
                     $this->password = $pass;
                    return true;
                      
                  }elseif($this->password === ''){
                      
                      $this->password = $this->current_pass;
                      
                      return true;
                  }
                
                
            } else{
                
                return false;
            }
                
           
            
              
          
            
            
            
    }
       
       
    
    
    /**
         * Obtain the password validation for pattern rules
         */
        
        public function getPasswordCharacterPatternRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CRegularExpressionValidator && $validator->pattern !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                return(preg_match($validator->pattern,$password));
                   
                       
            }
            }
        } 
        
        
        /**
         * This is the function that retrieves all the awaiting colleagues request for a user
         */
        public function getAllTheColleaguesAwaitingRequestOfThisMember($userid){
            
            $model = new MemberHasColleagues;
            return $model->getAllTheColleaguesAwaitingRequestOfThisMember($userid);
        }
        
        
        /**
         * This is the function that determines if a colleague is in the required domain type
         */
        public function isColleagueInTheRequiredDomainType($colleague_id,$domain_type){
            $model = new Resourcegroupcategory;
            //get the domain of this colleague
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$colleague_id);
             $member = User::model()->find($criteria);
             
             if($model->isDomainOfTheRequiredDomainType($member['domain_id'],$domain_type)){
                 return true;
             }else{
                 return false;
             }
        }
        
        /**
         * This is the function that determines if the required domain, domain type and country of the country is the required type
         */
        public function isDomainOfTheColleagueRequiredDomainTypeAndCountry($colleague_id,$domain_type,$country_id){
            $model = new Resourcegroupcategory;
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$colleague_id);
             $member = User::model()->find($criteria);
             
                        
             if($model->isDomainOfTheRequiredDomainTypeAndCountry($member['domain_id'],$domain_type,$country_id)){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
        /**
         * This is the function that retrieves all the colleagues members of a user
         */
        public function getAllTheColleaguesOfThisMember($userid){
            
            $model = new MemberHasColleagues;
            return $model->getAllTheColleaguesOfThisMember($userid);
        }
        
        
        /**
         * This is the function that determines if a members's domain is the owner of a network
         */
        public function isMemberInTheSameDomainAsNetwork($member_id,$domain_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$member_id);
             $member = User::model()->find($criteria);
             
             if($member['domain_id'] == $domain_id){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function that determines if a user has an appropriate security level to access a network
         */
        public function isMemberWithAppropriateSecurityClearance($member_id,$network_security_weight){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$member_id);
             $member = User::model()->find($criteria);
              if($member['security_level_weight'] <= $network_security_weight){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        
        /**
         * This is the function that retrieves the name of a user
         */
        public function getTheNameOfThisMember($member_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$member_id);
             $member = User::model()->find($criteria);
             return $member['name'];
            
        }
        
        
        
         /**
         * This is the function that conforms if the new user had already been created before with same email
         */
        public function doesThisUserAlreadyHaveAProfileOnThePlatform($email){
            
                       
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("email = '$email'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
  
        
       
        
        /**
         * This is the function that gets the domain of a user
         */
        public function getTheDomainOfThisUser($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$id);
                $user = User::model()->find($criteria);
                
                return $user['domain_id'];
            
        }
        
        
        /**
         * This is the function that gets an email address of a user
         */
        public function getTheEmailAddressOfThisUser($receiver_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$receiver_id);
                $user = User::model()->find($criteria);
                return $user['email'];
        }
        
        
        /**
         * This is the function that determines if a user is already existing on the platform
         */
        public function isThisUserAlreadyExistingOnThePlatform($model){
           if($this->isThisBvnAlreadyUsedOnThePlatform($model->bvn)){
                return true;
            }else if($this->isThisPvcAlreadyUsedOnThePlatform($model->pvc)){
                return true;
            }else if($this->isThisNinAlreadyUsedOnThePlatform($model->nin)){
                return true;
            }else if($this->isThisDrivingLicenseAlreadyUsedOnThePlatform($model->driving_license_number)){
                return true;
            }else if($this->isThisOtherIdTypeAlreadyUsedOnThePlatform($model->others_identification_number)){
                return true;
            }else if($this->isThisUserEmailAlreadyUsedOnThePlatform($model->email)){
                return true;
            }else if($this->isThisInternationalPassportAlreadyUsedOnThePlatform($model->passport_number)){
                return true;
            }else{
                return false;
            }
           
        }
        
        
        /**
         * This is the function that confirms if a bvn number had already been used on the platform
         */
        public function isThisBvnAlreadyUsedOnThePlatform($bvn){
            if($bvn !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("bvn = '$bvn'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
            
            
        }
        
        
         /**
         * This is the function that confirms if a nin number had already been used on the platform
         */
        public function isThisNinAlreadyUsedOnThePlatform($nin){
             
            if($nin != null){
                 $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("nin = '$nin'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
           
        }
        
        
        
         /**
         * This is the function that confirms if a pvc number had already been used on the platform
         */
        public function isThisPvcAlreadyUsedOnThePlatform($pvc){
            if($pvc != null){
                 $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("pvc = '$pvc'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
           
        }
        
        
           /**
         * This is the function that confirms if a international passport number had already been used on the platform
         */
        public function isThisInternationalPassportAlreadyUsedOnThePlatform($passport_number){
            if($passport_number != null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("passport_number = '$passport_number'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
                
                
            }else{
                return false;
            } 
            
        }
        
        
          /**
         * This is the function that confirms if a driving license number had already been used on the platform
         */
        public function isThisDrivingLicenseAlreadyUsedOnThePlatform($driving_license_number){
            if($driving_license_number != null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("driving_license_number = '$driving_license_number'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }
        
        
         /**
         * This is the function that confirms if a other identification types id number had already been used on the platform
         */
        public function isThisOtherIdTypeAlreadyUsedOnThePlatform($others_identification_number){
            if($others_identification_number != null){
                 $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("others_identification_number = '$others_identification_number'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
                
            }else{
                return false;
            } 
           
        }
        
        
        
         /**
         * This is the function that confirms if a user's email had already been used on the platform
         */
        public function isThisUserEmailAlreadyUsedOnThePlatform($email){
            if($email !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("email = '$email'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
            
        }
        
        
        
         /**
         * This is the function that determines if a user had been created as one of your domain staff
         */
        public function isThisUserAlreadyCreatedAsOneOfYourDomainStaff($model,$domain_id){
            if($this->isBvnOfUserAssociatedWithDomain($model->bvn,$domain_id)){
                return true;
            }else if($this->isNinOfUserAssociatedWithDomain($model->nin,$domain_id)){
                return true;
            }else if($this->isPvcOfUserAssociatedWithDomain($model->pvc,$domain_id)){
                return true;
            }else if($this->isPassportOfUserAssoiatedWithDomain($model->passport_number,$domain_id)){
                return true;
            }else if($this->isDrivingLicenseOfUserAssociatedWithDomain($model->driving_license_number,$domain_id)){
                return true;
            }else if($this->isOtherIdOfUserAssociatedWithDomain($model->others_identification_number,$domain_id)){
                return true;
            }else if($this->isTheEmailOfUserAssociatedWithDomain($model->email,$domain_id)){
                return true;
            }else{
                return false;
            }
           
        }
        
        
        /**
         * This is the function that determines if a user is already a staff of this domain based on its bvn
         */
        public function isBvnOfUserAssociatedWithDomain($bvn,$domain_id){
             if($bvn !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("bvn = '$bvn' and (domain_id=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        /**
         * This is the function that determines if a user is already a stff of this domain based on its pvc number
         */
        public function isPvcOfUserAssociatedWithDomain($pvc,$domain_id){
             if($pvc !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("pvc = '$pvc' and (domain_id=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
          /**
         * This is the function that determines if a user is already a staff of this domain based on its nin number
         */
        public function isNinOfUserAssociatedWithDomain($nin,$domain_id){
             if($nin !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("nin = '$nin' and (domain_id=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of this domain based on its passport number
         */
        public function isPassportOfUserAssoiatedWithDomain($passport_number,$domain_id){
             if($passport_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("passport_number = '$passport_number' and (domain_id=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
        /**
         * This is the function that determines if a user is already a staff of this domain based on its driving license number
         */
        public function isDrivingLicenseOfUserAssociatedWithDomain($driving_license_number,$domain_id){
             if($driving_license_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("driving_license_number = '$driving_license_number' and (domain_id=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of this domain based on his other identification number
         */
        public function isOtherIdOfUserAssociatedWithDomain($others_identification_number,$domain_id){
             if($others_identification_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("others_identification_number = '$others_identification_number' and (domain_id=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of this domain based on his email address
         */
        public function isTheEmailOfUserAssociatedWithDomain($email,$domain_id){
             if($email !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("email = '$email' and (domain_id=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
        /**
         * This is the function that confirms if a user is already a staff of another domain
         */
        public function isThisUserAlreadyAStaffOfAnotherDomain($model,$domain_id){
            
             if($this->isBvnOfUserAssociatedWithAnotherDomain($model->bvn,$domain_id)){
                return true;
            }else if($this->isNinOfUserAssociatedWithAnotherDomain($model->nin,$domain_id)){
                return true;
            }else if($this->isPvcOfUserAssociatedWithAnotherDomain($model->pvc,$domain_id)){
                return true;
            }else if($this->isPassportOfUserAssoiatedWithAnotherDomain($model->passport_number,$domain_id)){
                return true;
            }else if($this->isDrivingLicenseOfUserAssociatedWithAnotherDomain($model->driving_license_number,$domain_id)){
                return true;
            }else if($this->isOtherIdOfUserAssociatedWithAnotherDomain($model->others_identification_number,$domain_id)){
                return true;
            }else if($this->isTheEmailOfUserAssociatedWithAnotherDomain($model->email,$domain_id)){
                return true;
            }else{
                return false;
            }
   
        }
       
        
        /**
         * This is the function that determines if a user is already a staff of another domain based on its bvnnumber
         */
        public function isBvnOfUserAssociatedWithAnotherDomain($bvn,$domain_id){
             if($bvn !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("bvn = '$bvn' and (domain_id!=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of another domain based on its pvc number
         */
        public function isPvcOfUserAssociatedWithAnotherDomain($pvc,$domain_id){
             if($pvc !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("pvc = '$pvc' and (domain_id!=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
          /**
         * This is the function that determines if a user is already a staff of  another domain based on its nin number
         */
        public function isNinOfUserAssociatedWithAnotherDomain($nin,$domain_id){
             if($nin !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("nin = '$nin' and (domain_id!=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of another domain based on its passport number
         */
        public function isPassportOfUserAssoiatedWithAnotherDomain($passport_number,$domain_id){
             if($passport_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("passport_number = '$passport_number' and (domain_id!=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of another domain based on its driving license number
         */
        public function isDrivingLicenseOfUserAssociatedWithAnotherDomain($driving_license_number,$domain_id){
             if($driving_license_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("driving_license_number = '$driving_license_number' and (domain_id!=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of another domain based on his other identification number
         */
        public function isOtherIdOfUserAssociatedWithAnotherDomain($others_identification_number,$domain_id){
             if($others_identification_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("others_identification_number = '$others_identification_number' and (domain_id!=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
         /**
         * This is the function that determines if a user is already a staff of another domain based on his email address
         */
        public function isTheEmailOfUserAssociatedWithAnotherDomain($email,$domain_id){
             if($email !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("email = '$email' and (domain_id!=$domain_id and type='staff')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is associated with the platform domain
         */
        public function isThisUserAssociatedWithThePlatform($model){
            
            $platform_domain = $this->getThePlatformDomainId();
             if($this->isBvnOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->bvn,$platform_domain)){
                return true;
            }else if($this->isNinOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->nin,$platform_domain)){
                return true;
            }else if($this->isPvcOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->pvc,$platform_domain)){
                return true;
            }else if($this->isPassportOfUserAssoiatedWithNonStaffUserOfPlatformDomain($model->passport_number,$platform_domain)){
                return true;
            }else if($this->isDrivingLicenseOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->driving_license_number,$platform_domain)){
                return true;
            }else if($this->isOtherIdOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->others_identification_number,$platform_domain)){
                return true;
            }else if($this->isTheEmailOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->email,$platform_domain)){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that retrieves the platform domain id
         */
        public function getThePlatformDomainId(){
            $model = new Resourcegroupcategory;
            return $model->getThePlatformDomainId();
        }
        
        
        
        
        /**
         * This is the function that determines if a user is already a staff of this domain based on its bvn
         */
        public function isBvnOfUserAssociatedWithNonStaffUserOfPlatformDomain($bvn,$domain_id){
             if($bvn !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("bvn = '$bvn' and (domain_id=$domain_id and type = 'others')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        /**
         * This is the function that determines if a user is already a stff of this domain based on its pvc number
         */
        public function isNinOfUserAssociatedWithNonStaffUserOfPlatformDomain($nin,$domain_id){
             if($nin !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("nin = '$nin' and (domain_id=$domain_id and type='others')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
          /**
         * This is the function that determines if a user is already a staff of this domain based on its nin number
         */
        public function isPvcOfUserAssociatedWithNonStaffUserOfPlatformDomain($pvc,$domain_id){
             if($pvc !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("pvc = '$pvc' and (domain_id=$domain_id and type='others')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of this domain based on its passport number
         */
        public function isPassportOfUserAssoiatedWithNonStaffUserOfPlatformDomain($passport_number,$domain_id){
             if($passport_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("passport_number = '$passport_number' and (domain_id=$domain_id and type='others')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
        /**
         * This is the function that determines if a user is already a staff of this domain based on its driving license number
         */
        public function isDrivingLicenseOfUserAssociatedWithNonStaffUserOfPlatformDomain($driving_license_number,$domain_id){
             if($driving_license_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("driving_license_number = '$driving_license_number' and (domain_id=$domain_id and type='others')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of this domain based on his other identification number
         */
        public function isOtherIdOfUserAssociatedWithNonStaffUserOfPlatformDomain($others_identification_number,$domain_id){
             if($others_identification_number !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("others_identification_number = '$others_identification_number' and (domain_id=$domain_id and type='others')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that determines if a user is already a staff of this domain based on his email address
         */
        public function isTheEmailOfUserAssociatedWithNonStaffUserOfPlatformDomain($email,$domain_id){
             if($email !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("email = '$email' and (domain_id=$domain_id and type='others')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
        }
        
        
        
         /**
         * This is the function that confirms if the transfer of non staff from platform to a domain is a success
         */
        public function isTheTransferOfThisPlatformNonStaffMemberToThisDomainASuccess($model,$domain_id){
            
            $platform_domain = $this->getThePlatformDomainId();
            
            if($this->isBvnOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->bvn,$platform_domain)){
                 $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'type'=>"staff"  
                                   
                               
		
                            ),
                     ("bvn='$model->bvn'"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
           
            }else if($this->isNinOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->nin,$platform_domain)){
                  $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'type'=>"staff"  
                                   
                               
		
                            ),
                     ("nin='$model->nin'"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
                
                
            }else if($this->isPvcOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->pvc,$platform_domain)){
                
                  $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'type'=>"staff", 
                                   
                               
		
                            ),
                     ("pvc='$model->pvc'"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
            }else if($this->isPassportOfUserAssoiatedWithNonStaffUserOfPlatformDomain($model->passport_number,$platform_domain)){
                
                 $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'type'=>"staff"  
                                   
                               
		
                            ),
                     ("passport_number='$model->passport_number'"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
                
                
            }else if($this->isDrivingLicenseOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->driving_license_number,$platform_domain)){
                  $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'type'=>"staff"  
                                   
                               
		
                            ),
                     ("driving_license_number='$model->driving_license_number'"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
                
            }else if($this->isOtherIdOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->others_identification_number,$platform_domain)){
                  $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'type'=>"staff"  
                                   
                               
		
                            ),
                     ("others_identification_number='$model->others_identification_number'"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
                
                
                
            }else if($this->isTheEmailOfUserAssociatedWithNonStaffUserOfPlatformDomain($model->email,$platform_domain)){
            
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'type'=>"staff"  
                                   
                               
		
                            ),
                     ("email='$model->email'"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
             }
            
           
        }
        
        
        
           /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        /**
         * This is the function that gets the location id of a user
         */
        public function getTheLocationIdOfThisUser($user_id){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            return $user['location_id'];
            
        }
        
        
        /**
         * This is the function that gets the name of the person that confirms a payment
         */
        public function paymentConfirmedBy($confirmed_by){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$confirmed_by);
            $user= User::model()->find($criteria1);
            
            return $user['name'];
            
        }
        
        
         /**
         * This is the function that updates a user information on verification
         */
        public function isUserRecordSuccessfullyUpdated($user_id,$name,$address,$residency_expiry_date,$mobile_number,$bvn,$nin,$pvc,$pension_pin,$passport_number,$passport_expiry_date,$driving_license_number,$license_expiry_date,$email,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$linkedin_profile,$instagram_profile,$website,$website_expiry_date,$picture){
             $pic = $this->moveTheImageToItsPathAndReturnTheFilenameName($user_id,$picture);
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('user',
                                  array(
                                    'name'=>$name,
                                   'home_address'=>$address,
                                    'residency_expiry_date'=>$residency_expiry_date,
                                    'mobile_number'=>$mobile_number,
                                    'bvn'=>$bvn,
                                    'nin'=>$nin,
                                    'pvc'=>$pvc,
                                    'pension_pin'=>$pension_pin,  
                                    'passport_number'=>$passport_number,
                                    'passport_expiry_date'=>$passport_expiry_date,
                                    'driving_license_number'=>$driving_license_number,
                                    'license_expiry_date'=>$license_expiry_date,
                                    'wechat_profile'=>$wechat_profile,
                                    'telegram_profile'=>$telegram_profile,
                                    'whatsapp_profile'=>$whatsapp_profile,
                                    'facebook_profile'=>$facebook_profile,
                                    'tweeter_handle'=>$tweeter_handle,
                                    'youtube_channel'=>$youtube_channel,
                                    'linkedin_profile'=>$linkedin_profile,
                                    'instagram_profile'=>$instagram_profile,
                                    'website'=>$website,
                                    'website_expiry_date'=>$website_expiry_date,
                                    'picture'=>$pic  
                                  
                                   
                            ),
                     ("id=$user_id"));
            
            //$result =1;
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        
           /**
         * This is the function that determines the type and size of icon file
         */
        public function isFileTypeSuitable(){
            
           if(isset($_FILES['picture']['name'])){
                $tmpName = $_FILES['picture']['tmp_name'];
                $iconFileName = $_FILES['picture']['name'];    
                $iconFileType = $_FILES['picture']['type'];
                $iconFileSize = $_FILES['picture']['size'];
            } 
          if(($iconFileType == 'image/jpg' or $iconFileType =='image/png' or $iconFileType == 'image/jpeg')){
              return true;
               
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that moves file to its destination
         */
        public function moveTheImageToItsPathAndReturnTheFilenameName($user_id,$icon_filename){
            
            if(isset($_FILES['picture']['name'])){
                        $tmpName = $_FILES['picture']['tmp_name'];
                        $iconName = $_FILES['picture']['name'];    
                        $iconType = $_FILES['picture']['type'];
                        $iconSize = $_FILES['picture']['size'];
                  
                   }
                   
                  if($this->noNewPictureFileProvided($user_id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                                  $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                
                                
                            }
                  
        }
        
        
      /**
         * This is the function to ascertain if a new picture was provided or not
         */
        public function noNewPictureFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= User::model()->find($criteria);
                
                if($icon['picture']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that gets the existing user picture
         */
        public function getTheExistingUserPicture($user_id){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            return $user['picture'];
        }   
        
         /**
         * This is the function to get the deafault user photo
         */
        public function getTheDefaultUserPhoto(){
           
               return "user_unavailable.png";
          
        }
        
        
        /**
         * This is the function that confirms if an email address is the verified one
         */
        public function isThisTheVerifiedEmailAddress($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['email'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that confirms if a facebook profile is the verified one
         */
        public function isThisTheVerifiedFacebookProfile($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['facebook_profile'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if a mobile number is the verified one
         */
        public function isThisTheVerifiedMobileNumber($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['mobile_number'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if a whatsapp profile is the verified one
         */
        public function isThisTheVerifiedWhatsAppProfile($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['whatsapp_profile'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if a wechat profile is the verified one
         */
        public function isThisTheVerifiedWeChatProfile($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['wechat_profile'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if a telegram profile is the verified one
         */
        public function isThisTheVerifiedTelegramProfile($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['telegram_profile'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if a youtube profile is the verified one
         */
        public function isThisTheVerifiedYoutubeProfile($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['youtube_channel'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if a user address is the verified one
         */
        public function isThisTheVerifiedAddess($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['home_address'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if a tweeter handle is the verified one
         */
        public function isThisTheVerifiedTweeterHandle($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['tweeter_handle'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if a linkedin profile is the verified one
         */
        public function isThisTheVerifiedLinkedInProfile($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['linkedin_profile'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if a website domain address is the verified one
         */
        public function isThisTheVerifiedWebsiteDomain($user_id,$initiating_message_address){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['website'],$initiating_message_address) == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if code user bvn matches with the suppled one
         */
        public function isTheUserVerifiedBvnAMatchToTheProvidedOne($user_id,$userbvn){
            $model = new UserVerificationOutcome;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['bvn'],$userbvn) == 0){
                if($model->isUserBvnVerified($user_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if code user nin matches with the suppled one
         */
        public function isTheUserVerifiedNinAMatchToTheProvidedOne($user_id,$usernin){
            $model = new UserVerificationOutcome;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['nin'],$usernin) == 0){
                if($model->isUserNinVerified($user_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if code user pvc matches with the suppled one
         */
        public function isTheUserVerifiedPvcAMatchToTheProvidedOne($user_id,$userpvc){
            $model = new UserVerificationOutcome;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['pvc'],$userpvc) == 0){
                if($model->isUserPvcVerified($user_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if code user passport matches with the suppled one
         */
        public function isTheUserVerifiedPasspprtAMatchToTheProvidedOne($user_id,$userpassport){
            $model = new UserVerificationOutcome;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['passport_number'],$userpassport) == 0){
                if($model->isUserPassportVerified($user_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if code user drivers license matches with the suppled one
         */
        public function isTheUserVerifiedDriverLicenseAMatchToTheProvidedOne($user_id,$userlicense){
            $model = new UserVerificationOutcome;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['driving_license_number'],$userlicense) == 0){
                if($model->isUserDriverLicenseVerified($user_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if code user mobile number matches with the suppled one
         */
        public function isTheUserVerifiedMobileNumberAMatchToTheProvidedOne($user_id,$usermobile){
            $model = new UserVerificationOutcome;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['mobile_number'],$usermobile) == 0){
                if($model->isUserMobileNumberVerified($user_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if code user pension pin matches with the suppled one
         */
        public function isTheUserVerifiedPensionPinAMatchToTheProvidedOne($user_id,$userpension){
            $model = new UserVerificationOutcome;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria1);
            
            if(strcasecmp($user['pension_pin'],$userpension) == 0){
                if($model->isUserPensionPinVerified($user_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if a user is a guest user
         */
        public function isThisUserAGuestUser($email){
            $model = new Resourcegroupcategory;
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='email=:email';
            $criteria1->params = array(':email'=>"$email");
            $user= User::model()->find($criteria1);
            
            if($model->isThisUserDomainAGuestDomain($user['domain_id'])){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that registers a password reset request
         */
        public function isPasswordResetRequestSuccessful($email){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('user',
                                  array(
                                    'has_password_reset_request'=>1,
                                    'date_password_was_request'=>new CDbExpression('NOW()')  
                                  
                            ),
                     ("email='$email'"));
        
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        
        /**
         * This is the function that determines if a user belongs to a domain
         */
        public function isThisUserInThisDomain($domain_id,$user_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("id = $user_id and domain_id=$domain_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                    
        }
}
