<?php

/**
 * This is the model class for table "physical_batch_holder".
 *
 * The followings are the available columns in table 'physical_batch_holder':
 * @property string $id
 * @property integer $batch_id
 * @property integer $user_id
 * @property integer $is_returned
 * @property integer $is_return_initiated
 * @property integer $is_return_accepted
 * @property integer $box_id
 * @property string $assigned_type
 * @property integer $maximum_holding_period_in_days
 * @property string $date_collected
 * @property string $date_returned
 * @property integer $assigned_by
 * @property integer $returned_by
 * @property integer $return_initiated_by
 * @property integer $return_accepted_by
 * @property integer $return_accepted_date
 * @property integer $return_initiated_date
 *
 * The followings are the available model relations:
 * @property Resources $batch
 */
class PhysicalBatchHolder extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'physical_batch_holder';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('batch_id, box_id', 'required'),
			array('batch_id, user_id, is_returned, is_return_initiated, is_return_accepted, box_id, maximum_holding_period_in_days, assigned_by, returned_by, return_initiated_by, return_accepted_by, return_accepted_date, return_initiated_date', 'numerical', 'integerOnly'=>true),
			array('assigned_type', 'length', 'max'=>12),
			array('date_collected, date_returned', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, batch_id, user_id, is_returned, is_return_initiated, is_return_accepted, box_id, assigned_type, maximum_holding_period_in_days, date_collected, date_returned, assigned_by, returned_by, return_initiated_by, return_accepted_by, return_accepted_date, return_initiated_date', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'batch' => array(self::BELONGS_TO, 'Resources', 'batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'batch_id' => 'Batch',
			'user_id' => 'User',
			'is_returned' => 'Is Returned',
			'is_return_initiated' => 'Is Return Initiated',
			'is_return_accepted' => 'Is Return Accepted',
			'box_id' => 'Box',
			'assigned_type' => 'Assigned Type',
			'maximum_holding_period_in_days' => 'Maximum Holding Period In Days',
			'date_collected' => 'Date Collected',
			'date_returned' => 'Date Returned',
			'assigned_by' => 'Assigned By',
			'returned_by' => 'Returned By',
			'return_initiated_by' => 'Return Initiated By',
			'return_accepted_by' => 'Return Accepted By',
			'return_accepted_date' => 'Return Accepted Date',
			'return_initiated_date' => 'Return Initiated Date',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('batch_id',$this->batch_id);
		$criteria->compare('user_id',$this->user_id);
		$criteria->compare('is_returned',$this->is_returned);
		$criteria->compare('is_return_initiated',$this->is_return_initiated);
		$criteria->compare('is_return_accepted',$this->is_return_accepted);
		$criteria->compare('box_id',$this->box_id);
		$criteria->compare('assigned_type',$this->assigned_type,true);
		$criteria->compare('maximum_holding_period_in_days',$this->maximum_holding_period_in_days);
		$criteria->compare('date_collected',$this->date_collected,true);
		$criteria->compare('date_returned',$this->date_returned,true);
		$criteria->compare('assigned_by',$this->assigned_by);
		$criteria->compare('returned_by',$this->returned_by);
		$criteria->compare('return_initiated_by',$this->return_initiated_by);
		$criteria->compare('return_accepted_by',$this->return_accepted_by);
		$criteria->compare('return_accepted_date',$this->return_accepted_date);
		$criteria->compare('return_initiated_date',$this->return_initiated_date);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return PhysicalBatchHolder the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
