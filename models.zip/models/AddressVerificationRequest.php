<?php

/**
 * This is the model class for table "address_verification_request".
 *
 * The followings are the available columns in table 'address_verification_request':
 * @property string $id
 * @property string $address_id
 * @property string $status
 * @property string $invoice_id
 * @property string $requestor_id
 * @property string $requestor_domain_id
 * @property string $date_requested
 * @property string $date_verified
 */
class AddressVerificationRequest extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'address_verification_request';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('address_id, status, invoice_id, requestor_id, requestor_domain_id', 'required'),
			array('address_id, invoice_id, requestor_id, requestor_domain_id', 'length', 'max'=>10),
			array('status', 'length', 'max'=>9),
			array('date_requested, date_verified', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, address_id, status, invoice_id, requestor_id, requestor_domain_id, date_requested, date_verified', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'address_id' => 'Address',
			'status' => 'Status',
			'invoice_id' => 'Invoice',
			'requestor_id' => 'Requestor',
			'requestor_domain_id' => 'Requestor Domain',
			'date_requested' => 'Date Requested',
			'date_verified' => 'Date Verified',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('address_id',$this->address_id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('invoice_id',$this->invoice_id,true);
		$criteria->compare('requestor_id',$this->requestor_id,true);
		$criteria->compare('requestor_domain_id',$this->requestor_domain_id,true);
		$criteria->compare('date_requested',$this->date_requested,true);
		$criteria->compare('date_verified',$this->date_verified,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AddressVerificationRequest the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
 * This is the function that determines if a request had been made before
 */
        public function isThisRequestNotAlreadyMade($address_id,$user_id,$domain_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('address_verification_request')
                    ->where("address_id = $address_id and requestor_id=$user_id and status='requested'");
                $result = $cmd->queryScalar();
                
                if($result==0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that freezes a verification request
         * 
         */
        public function isTheFreezingOfThisRequestASuccess($id){
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('address_verification_request',
                                  array(
                                    'is_freezed'=>1,
                                    'freezed_by'=>Yii::app()->user->id,
                                   'date_freezed'=>new CDbExpression('NOW()')
                                   
                               
		
                            ),
                     ("id=$id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        
         /**
         * This is the function that  verifies a verification request
         * 
         */
        public function isTheVerificationOfThisRequestASuccess($id){
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('address_verification_request',
                                  array(
                                    'status'=>"verified",
                                    'verified_by'=>Yii::app()->user->id,
                                    'date_verified'=>new CDbExpression('NOW()')  
                                   
                               
		
                            ),
                     ("id=$id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that  verifies a verification request
         * 
         */
        public function isNotVerificationOfThisRequestASuccess($id){
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('address_verification_request',
                                  array(
                                    'status'=>"not_verified",
                                    'verified_by'=>Yii::app()->user->id,
                                    'date_verified'=>new CDbExpression('NOW()')  
                                   
                               
		
                            ),
                     ("id=$id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        
        /**
         * This is the function that generates the verification code
         */
        public function generateTheVerificationCode($user_id,$domain_id){
            
            $model = new DomainLocations;
            //get the first 3 letters of the domain name
                $domain_first_three_letters = strtoupper($this->getThePurchasingDomainNameFirstThreeLetters($domain_id)); 
                
                //get the location name of this user
                $location_name = $model->getTheLocationOfThisUser($user_id);
           
                //get the first three letters of the location
                $location_first_three = strtoupper(substr($location_name,0,3));
                    //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
               
                $verification_code = "$random_number-$location_first_three$domain_first_three_letters$user_id$domain_id";
                
                return $verification_code; 
        }
        
        
        
         /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getThePurchasingDomainNameFirstThreeLetters($domain_id){
                
                $model = new Resourcegroupcategory;    
                //get the domain name
                $domainname = $model->getThisDomainName($domain_id);
                //obtain the first four letters
                $substring = substr($domainname,0,3);
                
                return $substring;
            }
        
         /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
}
