<?php

/**
 * This is the model class for table "invoice".
 *
 * The followings are the available columns in table 'invoice':
 * @property string $id
 * @property string $invoice_number
 * @property string $status
 * @property string $location_id
 * @property string $date_payment_confirmed
 */
class Invoice extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'invoice';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('location_id', 'required'),
			array('invoice_number', 'length', 'max'=>250),
			array('status, location_id', 'length', 'max'=>10),
			array('date_payment_confirmed', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, invoice_number, status, location_id, date_payment_confirmed', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'invoice_number' => 'Invoice Number',
			'status' => 'Status',
			'location_id' => 'Location',
			'date_payment_confirmed' => 'Date Payment Confirmed',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('invoice_number',$this->invoice_number,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('location_id',$this->location_id,true);
		$criteria->compare('date_payment_confirmed',$this->date_payment_confirmed,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Invoice the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that retrieves the pending invoice id of a user's location
         */
        public function getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id){
            $model = new User;
           //get the location of this user
            $location_id = $model->getTheLocationIdOfThisUser($user_id);
            
        if($this->isLocationWithPendingInvoice($location_id)){
            //get the pending invoice from this location
            $invoice_id = $this->getPendingInvoiceFromThisLocation($location_id);
            return $invoice_id;
           
        }else{
            
              return $this->generateANewInvoiceForThisLocation($location_id,$user_id,$domain_id,$domain_trans_id);
        }
            
    
        }
        
        
        /**
         * This is the function that gets the pending invoice for  a location
         */
        public function getPendingInvoiceFromThisLocation($location_id){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='location_id=:id and status=:status';
            $criteria1->params = array(':id'=>$location_id,':status'=>"pending");
            $invoice= Invoice::model()->find($criteria1);
            
            return $invoice['id'];
        }
        
        
        /**
         * This is the function that generate a new invoice for a location
         */
        public function generateANewInvoiceForThisLocation($location_id,$user_id,$domain_id,$domain_trans_id){
           $this->location_id = $location_id;
           $this->status = "pending";
           $this->invoice_number = $this->generateNewInvoiceNumberForLocation($location_id,$user_id,$domain_id);
           $this->date_initiated = new CDbExpression('NOW()');
           $this->domain_transaction_id = $domain_trans_id;
           if($this->save()){
               return $this->id;
           }else{
               return 0;
           }
        }
        
        
        /**
         * This is the function that generates an invoice number
         */
        public function generateNewInvoiceNumberForLocation($location_id,$user_id,$domain_id){
           //get the first 3 letters of the domain name
                $domain_first_three_letters = strtoupper($this->getThePurchasingDomainNameFirstThreeLetters($domain_id)); 
           
            //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
                //get todays date
                $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                
                $invoice_number = "$domain_first_three_letters$location_id$user_id$domain_id-$random_number";
                
                return $invoice_number; 
                 
        }
        
        /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getThePurchasingDomainNameFirstThreeLetters($domain_id){
                
                $model = new ResourceGroupCategory;    
                //get the domain name
                $domainname = $model->getThisDomainName($domain_id);
                //obtain the first four letters
                $substring = substr($domainname,0,3);
                
                return $substring;
            }
        
        
         /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
            
            /**
             * This is the function that confirms if a locatin has a pending invoice
             */
            public function isLocationWithPendingInvoice($location_id){
                
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('invoice')
                    ->where("location_id = $location_id and status='pending'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
            /**
             * This is the function that list all pending invoices 
             */
            public function getAllPendingInvoices(){
                $targets = [];
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                $criteria1->condition='status=:status';
                $criteria1->params = array(':status'=>"pending");
                $invoices= Invoice::model()->findAll($criteria1);
                
                foreach($invoices as $invoice){
                    $targets[] = $invoice['id'];
                }
                return $targets;
            
            }
            
            
            /**
             * This is the function that retreives the prevaling cut off date
             */
            public function getThePrevailingCutoffDate(){
                $model = new Settings;
                return $model->getThePrevailingCutoffDate();
            }
            
          
            
             /**
         * This is the function that sets the transaction date and invoice status
         */
        public function isTheSettingOfNewInvoiceStatusASuccess($invoice_id){
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('invoice',
                                  array(
                                    'status'=>"processed",
                                     'date_processed'=>new CDbExpression('NOW()') 
                                    
                            ),
                     ("id=$invoice_id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
          
    }
    
    
    /**
     * This is the function that determines if a invoice belongs to a domain
     */
    public function isThisBillForThisDomain($invoice_id,$domain){
        $model = new DomainLocations;
        $criteria1 = new CDbCriteria();
        $criteria1->select = '*';
        $criteria1->condition='id=:id';
        $criteria1->params = array(':id'=>$invoice_id);
        $invoice= Invoice::model()->find($criteria1);
        
        if($model->isThisInvoiceLocationForThisDomain($domain,$invoice['location_id'])){
            return true;
        }else{
            return false;
        }
        
    }
    
    
    /**
     * This is the function that determines if an invoice is valid processing
     */
    public function isTransactionValidForProcessing($transaction_cutoff_date,$date_initiated){
        
        $cutoff_date = getdate(strtotime($transaction_cutoff_date));
        $date_invoice_initiated = getdate(strtotime($date_initiated));
        
        if($this->isThisPendingInvoiceInitiatedBeforeTheCutoffDate($cutoff_date,$date_invoice_initiated)){
            return true;
        }else{
            return false;
        }
        
    }
    
    
    /**
     * This is the function that determines if an initiation date is lower than the cutoff date
     */
    public function isThisPendingInvoiceInitiatedBeforeTheCutoffDate($cutoff,$initiated){
         if(($cutoff['year'] - $initiated['year'])>0){
                return true;
            }else if(($cutoff['year'] - $initiated['year'])<0){
                return false;
            }else{
                if(($cutoff['mon'] - $initiated['mon'])>0){
                    return true;
                }else if(($cutoff['mon'] - $initiated['mon'])<0){
                    return false;
                }else{
                    if(($cutoff['mday'] - $initiated['mday'])>0){
                        return true;
                    }else if(($cutoff['mday'] - $initiated['mday'])==0){
                        return true;
                    }else{
                        return false;
                    }
                }
            }
    }
    
    
    /**
     * This is the function that determines if all valid invoices had been processed
     */
    public function haveAllValidInvoicesProcessed(){
        $model = new Settings;
        //get the prevailing cut off date
        $cutoff_date = $model->getThePrevailingCutoffDate();
        $counter = 0;
        //spool all pending invoices
         $criteria = new CDbCriteria();
         $criteria->select = '*';
         $criteria->condition='status=:status';
         $criteria->params = array(':status'=>"pending");
         $invoices= Invoice::model()->findAll($criteria);
         
         foreach($invoices as $invoice){
              if($this->isTransactionValidForProcessing($cutoff_date,$invoice['date_initiated'])){
                         $counter = $counter + 1;
                     }
         }
         
         if($counter == 0){
             return true;
         }else{
             return false;
         }
        
    }
    
    
    
     /**
         * This is the function that retrieves the pending invoice id of an event enlister's location
         */
        public function getThisEventEnlisterDomainPendingLocationInvoice($event_code,$domain_id,$domain_trans_id){
            $model = new User;
            
            //get the enlister of this event
            $user_id = $this->getTheEnlisterOfThisEvent($event_code);
           //get the location of this user
            $location_id = $model->getTheLocationIdOfThisUser($user_id);
            
        if($this->isLocationWithPendingInvoice($location_id)){
            //get the pending invoice from this location
            $invoice_id = $this->getPendingInvoiceFromThisLocation($location_id);
            return $invoice_id;
           
        }else{
            
              return $this->generateANewInvoiceForThisLocation($location_id,$user_id,$domain_id,$domain_trans_id);
        }
            
    
        }
        
        
        /**
         * This is the function that retrieves the pending invoice id of an event enlister's location
         */
        public function getThisEventEnlisterDomainPendingLocationInvoiceGivenEventId($event_id,$domain_id,$domain_trans_id){
            $model = new User;
            
            //get the enlister of this event
            $user_id = $this->getTheEnlisterOfThisEventGivenId($event_id);
           //get the location of this user
            $location_id = $model->getTheLocationIdOfThisUser($user_id);
            
        if($this->isLocationWithPendingInvoice($location_id)){
            //get the pending invoice from this location
            $invoice_id = $this->getPendingInvoiceFromThisLocation($location_id);
            return $invoice_id;
           
        }else{
            
              return $this->generateANewInvoiceForThisLocation($location_id,$user_id,$domain_id,$domain_trans_id);
        }
            
    
        }
        
        
        /**
         * This is the function that gets an enlister of an event
         */
        public function getTheEnlisterOfThisEvent($event_code){
            $model = new UserEnlistmentRequest;
            return $model->getTheEnlisterOfThisEvent($event_code);
        }
        
        
         /**
         * This is the function that gets an enlister of an event
         */
        public function getTheEnlisterOfThisEventGivenId($event_id){
            $model = new UserEnlistmentRequest;
            return $model->getTheEnlisterOfThisEventGivenId($event_id);
        }
}
