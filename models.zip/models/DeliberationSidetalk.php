<?php

/**
 * This is the model class for table "deliberation_sidetalk".
 *
 * The followings are the available columns in table 'deliberation_sidetalk':
 * @property integer $id
 * @property string $from
 * @property integer $to
 * @property integer $cc
 * @property integer $is_to_list_a_network
 * @property integer $is_cc_list_a_network
 * @property string $to_recepients_list
 * @property string $cc_recepients_list
 * @property string $subject
 * @property string $message
 * @property string $category
 * @property integer $parent_id
 * @property string $type
 * @property string $content_type
 * @property string $from_domain_id
 * @property string $to_domain_id
 * @property integer $deliberation_id
 * @property string $attachment
 * @property integer $is_read
 * @property integer $is_attachment_downloaded
 * @property string $code
 * @property integer $is_message_forwardable
 * @property string $date_sent
 * @property string $date_recieved
 * @property string $sender_name
 * @property string $sender_domain_name
 */
class DeliberationSidetalk extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'deliberation_sidetalk';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('from, content_type, from_domain_id, to_domain_id, deliberation_id', 'required'),
			array('to, cc, is_to_list_a_network, is_cc_list_a_network, parent_id, deliberation_id, is_read, is_attachment_downloaded, is_message_forwardable', 'numerical', 'integerOnly'=>true),
			array('from, from_domain_id, to_domain_id', 'length', 'max'=>10),
			array('to_recepients_list, cc_recepients_list, subject, attachment, sender_name, sender_domain_name', 'length', 'max'=>250),
			array('category', 'length', 'max'=>12),
			array('type', 'length', 'max'=>6),
			array('content_type', 'length', 'max'=>8),
			array('code', 'length', 'max'=>200),
			array('message, date_sent, date_recieved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, from, to, cc, is_to_list_a_network, is_cc_list_a_network, to_recepients_list, cc_recepients_list, subject, message, category, parent_id, type, content_type, from_domain_id, to_domain_id, deliberation_id, attachment, is_read, is_attachment_downloaded, code, is_message_forwardable, date_sent, date_recieved, sender_name, sender_domain_name', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'from' => 'From',
			'to' => 'To',
			'cc' => 'Cc',
			'is_to_list_a_network' => 'Is To List A Network',
			'is_cc_list_a_network' => 'Is Cc List A Network',
			'to_recepients_list' => 'To Recepients List',
			'cc_recepients_list' => 'Cc Recepients List',
			'subject' => 'Subject',
			'message' => 'Message',
			'category' => 'Category',
			'parent_id' => 'Parent',
			'type' => 'Type',
			'content_type' => 'Content Type',
			'from_domain_id' => 'From Domain',
			'to_domain_id' => 'To Domain',
			'deliberation_id' => 'Deliberation',
			'attachment' => 'Attachment',
			'is_read' => 'Is Read',
			'is_attachment_downloaded' => 'Is Attachment Downloaded',
			'code' => 'Code',
			'is_message_forwardable' => 'Is Message Forwardable',
			'date_sent' => 'Date Sent',
			'date_recieved' => 'Date Recieved',
			'sender_name' => 'Sender Name',
			'sender_domain_name' => 'Sender Domain Name',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('from',$this->from,true);
		$criteria->compare('to',$this->to);
		$criteria->compare('cc',$this->cc);
		$criteria->compare('is_to_list_a_network',$this->is_to_list_a_network);
		$criteria->compare('is_cc_list_a_network',$this->is_cc_list_a_network);
		$criteria->compare('to_recepients_list',$this->to_recepients_list,true);
		$criteria->compare('cc_recepients_list',$this->cc_recepients_list,true);
		$criteria->compare('subject',$this->subject,true);
		$criteria->compare('message',$this->message,true);
		$criteria->compare('category',$this->category,true);
		$criteria->compare('parent_id',$this->parent_id);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('content_type',$this->content_type,true);
		$criteria->compare('from_domain_id',$this->from_domain_id,true);
		$criteria->compare('to_domain_id',$this->to_domain_id,true);
		$criteria->compare('deliberation_id',$this->deliberation_id);
		$criteria->compare('attachment',$this->attachment,true);
		$criteria->compare('is_read',$this->is_read);
		$criteria->compare('is_attachment_downloaded',$this->is_attachment_downloaded);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('is_message_forwardable',$this->is_message_forwardable);
		$criteria->compare('date_sent',$this->date_sent,true);
		$criteria->compare('date_recieved',$this->date_recieved,true);
		$criteria->compare('sender_name',$this->sender_name,true);
		$criteria->compare('sender_domain_name',$this->sender_domain_name,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DeliberationSidetalk the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
              /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
         /**
         * This is the function that generates codes for a deliberation side talk
         */
        public function generateTheCodeForThisDeliberationSidetalk($deliberation_id){
                          
            $model = new MessageDeliberation;   
            return $model->getTheCodeOfThisDeliberation($deliberation_id);
        }
        
        
           /**
         * This is the function that sends a chat side talk deliberation message to a recipient
         */
        public function executesendingChatDeliberationSideTalkToThisMember($deliberation_id,$message_id,$recipient,$message,$code,$user_id,$domain_id,$filename,$content_type,$filesize,$sidetalk_recepients){
            $model = new User;
            
           $subject = $this->getTheSubjectOfTheOriginalMessage($message_id);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('deliberation_sidetalk',
                                  array(
                                    'from'=>$user_id,
                                    'to'=>$recipient,
                                   'subject'=>$subject,  
                                  'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('inbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'to_domain_id'=>$model->getTheDomainOfThisUser($recipient),
                                    'deliberation_id'=>$deliberation_id,
                                    'code'=>$code,
                                   'to_recepients_list'=>implode(',',$sidetalk_recepients),
                                   'is_message_forwardable'=>0,
                                   'attachment'=>$filename,
                                   'attachment_size'=> $filesize,
                                  'content_type'=>$content_type,
                                    'date_sent'=>new CDbExpression('NOW()'),
                                    'date_recieved'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$model->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id) 
                                  )
			
                        );
                if($result>0){
                    if($this->isSendingInformationalPrivateEmailASuccess($recipient,$user_id,$domain_id,"$subject")){
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }else{
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }
                    
                }else{
                    return 0;
                }
         
      
        }
        
        
           /**
         * This is the function that gets a domain name given its id
         */
        public function getTheDomainNameOfThisMemberDomainId($domain_id){
            $model = new Resourcegroupcategory;
            return $model->getTheDomainNameOfThisDomain($domain_id);
        }
        
        
         /**
         * This is the finction that retrieves the last side talk id of this user
         */
        public function getTheCurrentMessageIdOfThisReceipient($code){
            //retreiev all the messages from this user
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="code=:code";
            $criteria->params = array(':code'=>"$code");
            $messages= DeliberationSidetalk::model()->findAll($criteria);
             $recent = 0;
             foreach($messages as $mess){
                 if($mess['id']>$recent){
                     $recent = $mess['id'];
                 }
             }
             return $recent;
        }
        
        
         /**
         * This is the function that writes a chat deliberation sidetalk  message to the sender outbox
         */
        public function writeThisChatDeliberationSidetalkToTheSenderOutbox($deliberation_id,$message_id,$message,$code,$user_id,$domain_id,$filename,$content_type,$sidetalk_recepients){
            $subject = $this->getTheSubjectOfTheOriginalMessage($message_id);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('deliberation_sidetalk',
                                  array(
                                    'from'=>$user_id,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('outbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'deliberation_id'=>$deliberation_id,
                                    'code'=>$code,
                                    'to_recepients_list'=>implode(',',$sidetalk_recepients),
                                   'is_message_forwardable'=>0,
                                    'attachment'=>$filename,
                                     'content_type'=>$content_type,
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                     'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)  
                                  )
			
                        );
               
               if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
         /**
         * This is the function that gets the name of a sender
         */
        public function getTheNameOfThisMember($user_id){
            $model = new User;
            return $model->getTheNameOfThisMember($user_id);
        }
        
        
        
        /**
         * This is the function that moves a filename to its location path
         */
        public function moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type){
            
            if(isset($_FILES['sidetalk_filename']['name'])){
                        $tmpName = $_FILES['sidetalk_filename']['tmp_name'];
                        $iconName = $_FILES['sidetalk_filename']['name'];    
                        $iconType = $_FILES['sidetalk_filename']['type'];
                        $iconSize = $_FILES['sidetalk_filename']['size'];
                        
                        
                        if($iconName !== null) {
                        if($model->id === null){
                           if($filename != null){
                                $iconFileName = time().'_'.$filename;  
                            }else{
                                $iconFileName = $$filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== null){
                            if($content_type == 'document'){
                                $iconPath = Yii::app()->params['documents'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'image'){
                                $iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'audio'){
                                $iconPath = Yii::app()->params['audios'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'video'){
                                $iconPath = Yii::app()->params['videos'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }
                            	
                        }else{
                            $iconFileName = $filename;
                            return $iconFileName;
                        } // validate to save file
                        }
                     }else{
                         $iconFileName = $filename;
                         return $iconFileName;
                     }
                  
                   }else{
                       return null;
                   }
                    
                    
        }
        
        
        /**
         * This is the function that determines if an ssset or file type is acceptable
         */
        public function isFileTypeAndSizeAcceptable(){
           
          if(isset($_FILES['sidetalk_filename']['name'])){
                $tmpName = $_FILES['sidetalk_filename']['tmp_name'];
                $iconFileName = $_FILES['sidetalk_filename']['name'];    
                $iconFileType = $_FILES['sidetalk_filename']['type'];
                $iconFileSize = $_FILES['sidetalk_filename']['size'];
                
            if($iconFileType === 'image/png'){
                return true;
            }else if($iconFileType === 'image/jpg'){
                return true;
            }else if($iconFileType === 'image/jpeg'){
                return true;
                
            }else if($iconFileType === 'application/pdf'){
                return true;
            }else if($iconFileType === 'audio/mp3'){
                return true;
            }else if($iconFileType === 'video/mp4'){
                return true;
            }else{
                return false;
            }
          }else{
              return false;  
          } 
          
           
           
            
        }
        
        
           /**
         * This is the function that sends a reply chat of side talk deliberation message to a recipient
         */
        public function sendingareplyChatDeliberationSideTalkToThisMember($sidetalk_id,$deliberation_id,$message_id,$recipient,$message,$code,$user_id,$domain_id,$filename,$content_type,$sidetalk_recepients){
            $model = new User;
            
            $subject = $this->getTheSubjectOfTheOriginalMessage($message_id);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('deliberation_sidetalk',
                                  array(
                                    'from'=>$user_id,
                                    'to'=>$recipient,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('inbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'to_domain_id'=>$model->getTheDomainOfThisUser($recipient),
                                    'deliberation_id'=>$deliberation_id,
                                     'parent_id'=>$sidetalk_id,
                                    'code'=>$code,
                                     'to_recepients_list'=>implode(',',$sidetalk_recepients),
                                   'is_message_forwardable'=>0,
                                     'attachment'=>$filename,
                                     'content_type'=>$content_type,
                                    'date_sent'=>new CDbExpression('NOW()'),
                                    'date_recieved'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$model->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id) 
                                  )
			
                        );
                if($result>0){
                    if($this->isSendingInformationalPrivateEmailASuccess($recipient,$user_id,$domain_id,"$subject")){
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }else{
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }
                    
                }else{
                    return 0;
                }
      
        }
        
        
        
         /**
         * This is the function that writes a chat rely of a deliberation sidetalk  message to the sender outbox
         */
        public function writeThisReplyChatDeliberationSidetalkToTheSenderOutbox($sidetalk_id,$deliberation_id,$message_id,$message,$code,$user_id,$domain_id,$filename,$content_type,$sidetalk_recepients){
            $subject = $this->getTheSubjectOfTheOriginalMessage($message_id);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('deliberation_sidetalk',
                                  array(
                                    'from'=>$user_id,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('outbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'deliberation_id'=>$deliberation_id,
                                    'parent_id'=>$sidetalk_id,  
                                    'code'=>$code,
                                    'to_recepients_list'=>implode(',',$sidetalk_recepients),
                                   'is_message_forwardable'=>0,
                                    'attachment'=>$filename,
                                     'content_type'=>$content_type,
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                     'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)  
                                  )
			
                        );
               
               if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
          /**
         * This is the function that gets the subject of a deliberation original message
         */
        public function getTheSubjectOfTheOriginalMessage($message_id){
            $model = new Message;
            return $model->getTheSubjectOfTheOriginalMessage($message_id);
        }
        
          /**
         * This is the function that sends private email to a message recepient
         */
        public function isSendingInformationalPrivateEmailASuccess($to,$from,$from_domain_id,$subject){
            $model = new User;
            //get the email of this receiver as well as te from domain name
            $email = $model->getTheEmailAddressOfThisUser($to);
            $domain_name = $this->getTheDomainNameOfThisMemberDomainId($from_domain_id);
            
            return true;
        }
        
        
        /**
         * This is the function that confirms if a deliberation has sidetalks
         */
        public function isDeliberationWithSideTalks($deliberation_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('deliberation_sidetalk')
                    ->where("deliberation_id = $deliberation_id");
                $result = $cmd->queryScalar();
                
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        
        /**
         * This is the function that confirms if the removal of deliberation sidetalk is a success
         */
        public function isRemovalOfThisDeliberationSidetalksASuccess($deliberation){
            //get all side talks for this deliberation
            $sidetalks = $this->getAllTheSidetalksForThisDeliberation($deliberation);
            
            $counter = 0;
            foreach($sidetalks as $sidetalk){
                if($this->isTheRemovalOFThisSidetalkASuccess($sidetalk) == false){
                    $counter = $counter + 1;
                }
                
            }
            if($counter == 0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that removes sidetalks from deliberation
         */
        public function isTheRemovalOFThisSidetalkASuccess($sidetalk_id){
            $model=  DeliberationSidetalk::model()->findByPk($sidetalk_id);
            if($model === null){
                return false;
            }else if($model->delete()){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that gets all sidetalks for a deliberation
         */
        public function getAllTheSidetalksForThisDeliberation($deliberation_id){
            $sidetalks = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="deliberation_id=:delid";
            $criteria->params = array(':delid'=>$deliberation_id);
            $messages= DeliberationSidetalk::model()->findAll($criteria);
            
            foreach($messages as $mess){
                $sidetalks[] = $mess['id'];
            }
            return $sidetalks;
        }
        
        
        /**
         * This is the function that determines if a deliberation has a sidetalk
         */
        public function isTheDeliberationOnSideTalks($deliberation_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('deliberation_sidetalk')
                    ->where("deliberation_id = $deliberation_id");
                $result = $cmd->queryScalar();
                
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        
        
          /**
             * This is the function that retreives the code of a sidetalk message
             */
            public function getTheCodeOfThisSidetalkDeliberation($sidetalk_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition="id=:id";
                $criteria->params = array(':id'=>$sidetalk_id);
                $sidetalk= DeliberationSidetalk::model()->find($criteria);
                return $sidetalk['code'];
                
            }
            
            
            
            /**
             * This is the function that determines if a deliberstion sidetalk message is with children
             */
            public function isDeliberationSidetalkMessageWithChild($sidetalk_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('deliberation_sidetalk')
                    ->where("parent_id = $sidetalk_id");
                $result = $cmd->queryScalar();
                
               if($result>0){
                   return true;
               }else{
                   return false;
               }
            }
       
            
}
