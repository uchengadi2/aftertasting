<?php

/**
 * This is the model class for table "address".
 *
 * The followings are the available columns in table 'address':
 * @property string $id
 * @property string $house_number
 * @property string $street_id
 * @property string $structure_type
 * @property string $premises_layout
 * @property string $building_colour
 * @property string $building_room_layout
 * @property string $building_purpose
 * @property integer $is_compound_gated
 * @property string $compound_gate_colour
 * @property string $nearest_busstop
 * @property string $first_landmark
 * @property string $second_landmark
 * @property string $other_landmark
 * @property string $building_condition
 * @property string $building_fence_status
 * @property string $electricity_metering_type
 * @property string $compound_has_active_security_person
 * @property integer $is_verified
 */
class Address extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'address';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('street_id', 'required'),
			//array('is_compound_gated, is_verified', 'numerical', 'integerOnly'=>true),
			array('house_number', 'length', 'max'=>100),
			array('street_id', 'length', 'max'=>10),
			array('structure_type', 'length', 'max'=>20),
			array('premises_layout', 'length', 'max'=>28),
			array('building_colour, compound_gate_colour, nearest_busstop, first_landmark, second_landmark, other_landmark', 'length', 'max'=>250),
			array('building_room_layout', 'length', 'max'=>24),
			array('building_purpose, building_fence_status, electricity_metering_type,is_compound_gated, compound_has_active_security_person', 'length', 'max'=>16),
			array('building_condition', 'length', 'max'=>30),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, house_number, street_id, structure_type, premises_layout, building_colour, building_room_layout, building_purpose, is_compound_gated, compound_gate_colour, nearest_busstop, first_landmark, second_landmark, other_landmark, building_condition, building_fence_status, electricity_metering_type, compound_has_active_security_person, is_verified', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'house_number' => 'House Number',
			'street_id' => 'Street',
			'structure_type' => 'Structure Type',
			'premises_layout' => 'Premises Layout',
			'building_colour' => 'Building Colour',
			'building_room_layout' => 'Building Room Layout',
			'building_purpose' => 'Building Purpose',
			'is_compound_gated' => 'Is Compound Gated',
			'compound_gate_colour' => 'Compound Gate Colour',
			'nearest_busstop' => 'Nearest Busstop',
			'first_landmark' => 'First Landmark',
			'second_landmark' => 'Second Landmark',
			'other_landmark' => 'Other Landmark',
			'building_condition' => 'Building Condition',
			'building_fence_status' => 'Building Fence Status',
			'electricity_metering_type' => 'Electricity Metering Type',
			'compound_has_active_security_person' => 'Compound Has Active Security Person',
			'is_verified' => 'Is Verified',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('house_number',$this->house_number,true);
		$criteria->compare('street_id',$this->street_id,true);
		$criteria->compare('structure_type',$this->structure_type,true);
		$criteria->compare('premises_layout',$this->premises_layout,true);
		$criteria->compare('building_colour',$this->building_colour,true);
		$criteria->compare('building_room_layout',$this->building_room_layout,true);
		$criteria->compare('building_purpose',$this->building_purpose,true);
		$criteria->compare('is_compound_gated',$this->is_compound_gated);
		$criteria->compare('compound_gate_colour',$this->compound_gate_colour,true);
		$criteria->compare('nearest_busstop',$this->nearest_busstop,true);
		$criteria->compare('first_landmark',$this->first_landmark,true);
		$criteria->compare('second_landmark',$this->second_landmark,true);
		$criteria->compare('other_landmark',$this->other_landmark,true);
		$criteria->compare('building_condition',$this->building_condition,true);
		$criteria->compare('building_fence_status',$this->building_fence_status,true);
		$criteria->compare('electricity_metering_type',$this->electricity_metering_type,true);
		$criteria->compare('compound_has_active_security_person',$this->compound_has_active_security_person,true);
		$criteria->compare('is_verified',$this->is_verified);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Address the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that verifies if a house number is already existing on a street
         */
        public function isHouseNumberAlreadyAvailable($street_id,$house_number){
            
            //get all the addresses for this street
            $addresses = $this->getAllStreetAddresses($street_id);
            foreach($addresses as $add){
                if(strcasecmp("$add","$house_number") == 0){
                     return true;
                }
            }
            return false;
        }
        
        
        /**
         * This is the function that retrieves all streets addresses
         */
        public function getAllStreetAddresses($street_id){
            
            $all_address = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='street_id=:id';
            $criteria->params = array(':id'=>$street_id);
            $addresses= Address::model()->findAll($criteria);
            
            foreach($addresses as $add){
                $all_address[] =$add['house_number'];
            }
            return $all_address;
        }
        
   
         /**
         * This is the function that  preverifies an address
         * 
         */
        public function isTheVerificationOfThisAddressASuccess($id){
            $model = new User;
            $user_id = Yii::app()->user->id;
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('address',
                                  array(
                                    'is_verified'=>1,
                                    'verification_owner_type'=>"onus",  
                                     'verification_owner_domain_id'=>$domain_id,    
                                    'verified_by'=>Yii::app()->user->id,
                                    'date_verified'=>new CDbExpression('NOW()')  
                                   
                               
		
                            ),
                     ("id=$id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that will determine if domain is the owner of an address verification
         */
        public function isDomainTheOwnerOfThisAddressVerification($domain_id,$address_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$address_id);
            $address= Address::model()->find($criteria);
            
            if($address['verification_owner_domain_id'] == $domain_id){
                return true;
            }else{
                return false;
            }
        }
       
        
}
