<?php

/**
 * This is the model class for table "sidetalk_has_buckets".
 *
 * The followings are the available columns in table 'sidetalk_has_buckets':
 * @property integer $sidetalk_id
 * @property string $bucket_id
 * @property integer $is_bucket_assessed
 * @property string $date_accessed
 * @property integer $accessed_user_id
 */
class SidetalkHasBuckets extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'sidetalk_has_buckets';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('sidetalk_id, bucket_id', 'required'),
			array('sidetalk_id, is_bucket_assessed, accessed_user_id', 'numerical', 'integerOnly'=>true),
			array('bucket_id', 'length', 'max'=>10),
			array('date_accessed', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('sidetalk_id, bucket_id, is_bucket_assessed, date_accessed, accessed_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'sidetalk_id' => 'Sidetalk',
			'bucket_id' => 'Bucket',
			'is_bucket_assessed' => 'Is Bucket Assessed',
			'date_accessed' => 'Date Accessed',
			'accessed_user_id' => 'Accessed User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('sidetalk_id',$this->sidetalk_id);
		$criteria->compare('bucket_id',$this->bucket_id,true);
		$criteria->compare('is_bucket_assessed',$this->is_bucket_assessed);
		$criteria->compare('date_accessed',$this->date_accessed,true);
		$criteria->compare('accessed_user_id',$this->accessed_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return SidetalkHasBuckets the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function inserts assets to messages
         */
        public function attachTheAssetsInTheBucket($sidetalk_id,$buckets){
            $counter = 0;
            foreach($buckets as $buck){
                if($this->isTheInsertionOfThisBucketToMessageSuccessful($sidetalk_id,$buck)){
                    $counter = $counter + 1;
                }
            }
            return $counter;
        }
        
        
        /**
         * This is the function that determines if insertion of buckets to messages is a success
         */
        public function isTheInsertionOfThisBucketToMessageSuccessful($sidetalk_id,$bucket_id){
               
            if(!empty($bucket_id)){
             $cmd =Yii::app()->db->createCommand();
                $result= $cmd->insert('sidetalk_has_buckets',
                                        array(
                                           'sidetalk_id'=>$sidetalk_id,
                                           'bucket_id'=>$bucket_id,
                                          
                ));
            
             if($result>0){
               return true;
            }else{
               return false;
            }
                
            }else{
                return true;
            }
           
        
        }
}
