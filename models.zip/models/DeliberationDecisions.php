<?php

/**
 * This is the model class for table "deliberation_decisions".
 *
 * The followings are the available columns in table 'deliberation_decisions':
 * @property integer $id
 * @property string $from
 * @property integer $to
 * @property integer $cc
 * @property integer $is_to_list_a_network
 * @property integer $is_cc_list_a_network
 * @property string $to_recepients_list
 * @property string $cc_recepients_list
 * @property string $subject
 * @property string $message
 * @property string $category
 * @property integer $parent_id
 * @property string $type
 * @property string $content_type
 * @property string $from_domain_id
 * @property string $to_domain_id
 * @property integer $deliberation_id
 * @property string $attachment
 * @property double $attachment_size
 * @property integer $is_read
 * @property integer $is_attachment_downloaded
 * @property string $code
 * @property integer $is_message_forwardable
 * @property string $date_sent
 * @property string $date_recieved
 * @property string $sender_name
 * @property string $sender_domain_name
 */
class DeliberationDecisions extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'deliberation_decisions';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('from, content_type, from_domain_id, to_domain_id, deliberation_id', 'required'),
			array('to, cc, is_to_list_a_network, is_cc_list_a_network, parent_id, deliberation_id, is_read, is_attachment_downloaded, is_message_forwardable', 'numerical', 'integerOnly'=>true),
			array('attachment_size', 'numerical'),
			array('from, from_domain_id, to_domain_id', 'length', 'max'=>10),
			array('to_recepients_list, cc_recepients_list, subject, attachment, sender_name, sender_domain_name', 'length', 'max'=>250),
			array('category', 'length', 'max'=>12),
			array('type', 'length', 'max'=>6),
			array('content_type', 'length', 'max'=>8),
			array('code', 'length', 'max'=>200),
			array('message, date_sent, date_recieved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, from, to, cc, is_to_list_a_network, is_cc_list_a_network, to_recepients_list, cc_recepients_list, subject, message, category, parent_id, type, content_type, from_domain_id, to_domain_id, deliberation_id, attachment, attachment_size, is_read, is_attachment_downloaded, code, is_message_forwardable, date_sent, date_recieved, sender_name, sender_domain_name', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'from' => 'From',
			'to' => 'To',
			'cc' => 'Cc',
			'is_to_list_a_network' => 'Is To List A Network',
			'is_cc_list_a_network' => 'Is Cc List A Network',
			'to_recepients_list' => 'To Recepients List',
			'cc_recepients_list' => 'Cc Recepients List',
			'subject' => 'Subject',
			'message' => 'Message',
			'category' => 'Category',
			'parent_id' => 'Parent',
			'type' => 'Type',
			'content_type' => 'Content Type',
			'from_domain_id' => 'From Domain',
			'to_domain_id' => 'To Domain',
			'deliberation_id' => 'Deliberation',
			'attachment' => 'Attachment',
			'attachment_size' => 'Attachment Size',
			'is_read' => 'Is Read',
			'is_attachment_downloaded' => 'Is Attachment Downloaded',
			'code' => 'Code',
			'is_message_forwardable' => 'Is Message Forwardable',
			'date_sent' => 'Date Sent',
			'date_recieved' => 'Date Recieved',
			'sender_name' => 'Sender Name',
			'sender_domain_name' => 'Sender Domain Name',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('from',$this->from,true);
		$criteria->compare('to',$this->to);
		$criteria->compare('cc',$this->cc);
		$criteria->compare('is_to_list_a_network',$this->is_to_list_a_network);
		$criteria->compare('is_cc_list_a_network',$this->is_cc_list_a_network);
		$criteria->compare('to_recepients_list',$this->to_recepients_list,true);
		$criteria->compare('cc_recepients_list',$this->cc_recepients_list,true);
		$criteria->compare('subject',$this->subject,true);
		$criteria->compare('message',$this->message,true);
		$criteria->compare('category',$this->category,true);
		$criteria->compare('parent_id',$this->parent_id);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('content_type',$this->content_type,true);
		$criteria->compare('from_domain_id',$this->from_domain_id,true);
		$criteria->compare('to_domain_id',$this->to_domain_id,true);
		$criteria->compare('deliberation_id',$this->deliberation_id);
		$criteria->compare('attachment',$this->attachment,true);
		$criteria->compare('attachment_size',$this->attachment_size);
		$criteria->compare('is_read',$this->is_read);
		$criteria->compare('is_attachment_downloaded',$this->is_attachment_downloaded);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('is_message_forwardable',$this->is_message_forwardable);
		$criteria->compare('date_sent',$this->date_sent,true);
		$criteria->compare('date_recieved',$this->date_recieved,true);
		$criteria->compare('sender_name',$this->sender_name,true);
		$criteria->compare('sender_domain_name',$this->sender_domain_name,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DeliberationDecisions the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         
             /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
       /**
        * This is the function that confirms if a deliberation had been adopted
        */
        public function isDeliberationAdopted($deliberation_id,$group_id,$user_id){
            
             //get the number of members that contributed to this deliberation
            $deliberation_contributors = $this->getTheNumberOfMembersThatContributedToThisDeliberation($deliberation_id,$group_id,$user_id);
            
            //get the number of members that adopted the deliberation
            
            $deliberation_adoptors = $this->getTheNumberOfMembersThatAdoptedThisDeliberation($deliberation_id,$group_id,$user_id);
            
            //get the number of members that are requesting for amendment to the deliberation
            
            $amendment_seekers = $this->getTheNumberOfMembersThatAreRequestingAmendmentToTheDeliberation($deliberation_id,$group_id,$user_id);
            
            //get the numbers of members that are non commital to this deliberation
            
            $deliberation_noncommitals = $this->getTheNumberOfMembersThatAreNonCommitalToThisDeliberation($deliberation_id,$group_id,$user_id);
            
            
            
           if($group_id == 0){
                $total_colleague_user = $this->getTheTotalNumberOfThisUserColleagues($user_id);
                $adoption_rule=$this->getThePlatformAdoptionRuleForColleagues();
                $quorum_rule = $this->getThePlatformQuorumRuleForColleagues();
                if($deliberation_contributors/$total_colleague_user < $quorum_rule){
                    return false;
                }else{
                     if($amendment_seekers>0){
                        return false;
                    }else if($deliberation_noncommitals>0){
                        return false;
                    }else if($deliberation_adoptors/$total_colleague_user < $adoption_rule){
                        return false;
                    }else{
                        return true;
                    }
                }
                   
            }else{
                $total_group_user = $this->getTheTotalNumberOfThisGroupMembers($group_id);
                $adoption_rule = $this->getTheAdoptionRuleForThisNetworkGroup($group_id);
                $quorum_rule = $this->getTheQuorumRuleForThisNetworkGroup($group_id);
                if($deliberation_contributors/$total_group_user < $quorum_rule){
                    return false;
                }else{
                    if($deliberation_adoptors/$total_group_user<$adoption_rule){
                        return false;
                    }else{
                        return true;
                    }
                }
                
            }
           
   
            
        }
        
        
        /**
         * This is the function that gets the total number of a user colleague
         */
        public function getTheTotalNumberOfThisUserColleagues($user_id){
            $model = new MemberHasColleagues;
            return $model->getTheTotalNumberOfThisUserColleagues($user_id);
        }
        
        /**
         * This is the function that gets the total number of a group membership
         */
        public function getTheTotalNumberOfThisGroupMembers($group_id){
            $model = new NetworkHasMembers;
            return $model->getTheTotalNumberOfThisGroupMembers($group_id);
        }
        
        /**
         * This is the function that gets an adoption rule of a network group
         */
        public function getTheAdoptionRuleForThisNetworkGroup($group_id){
            $model = new Network;
            return $model->getTheAdoptionRuleForThisNetworkGroup($group_id);
        }
        
        
        /**
         * This is the function that gets an quorum rule of a network group
         */
        public function getTheQuorumRuleForThisNetworkGroup($group_id){
            $model = new Network;
            return $model->getTheQuorumRuleForThisNetworkGroup($group_id);
        }
        
        
        /**
         * This is the function that retrieves the total number that contributed to a deliberation
         */
        public function getTheNumberOfMembersThatContributedToThisDeliberation($deliberation_id,$group_id,$user_id){
            $model = new MessageDeliberation;
            return $model->getTheNumberOfMembersThatContributedToThisDeliberation($deliberation_id,$group_id,$user_id);
        }
        
         /**
         * This is the function that retrieves the total number that adopted a deliberation
         */
        public function getTheNumberOfMembersThatAdoptedThisDeliberation($deliberation_id,$group_id,$user_id){
            $model = new MessageDeliberation;
            return $model->getTheNumberOfMembersThatAdoptedThisDeliberation($deliberation_id,$group_id,$user_id);
        }
        
        
         /**
         * This is the function that retrieves the total number that seeks further amendment to a deliberation
         */
        public function getTheNumberOfMembersThatAreRequestingAmendmentToTheDeliberation($deliberation_id,$group_id,$user_id){
            $model = new MessageDeliberation;
            return $model->getTheNumberOfMembersThatAreRequestingAmendmentToTheDeliberation($deliberation_id,$group_id,$user_id);
        }
        
        
         /**
         * This is the function that retrieves the total number that are still noncommital to a deliberation
         */
        public function getTheNumberOfMembersThatAreNonCommitalToThisDeliberation($deliberation_id,$group_id,$user_id){
            $model = new MessageDeliberation;
            return $model->getTheNumberOfMembersThatAreNonCommitalToThisDeliberation($deliberation_id,$group_id,$user_id);
        }
        
        
        /**
         * This is the function that retrieves the adoption rule for colleagues
         */
        public function getThePlatformAdoptionRuleForColleagues(){
            return 1;
        }
        
        /**
         * This is the function that retrieves the quorum rule for colleagues
         */
        public function getThePlatformQuorumRuleForColleagues(){
            return 1;
        }
        
        
        /**
         * This is the function that confirms if a deliberation is already added to a decision
         */
        public function isDeliberationAlreadyInDecision($deliberation_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('deliberation_decisions')
                    ->where("deliberation_id = $deliberation_id");
                $result = $cmd->queryScalar();
             if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        /**
         * This is the function that determines if the addition of a deliberation to a decision is a success
         */
        public function isAddingThisDeliberationToTheDecisionBoardASuccess($deliberation_id,$group_id){
           //get a copy of this deliberation
            $model=  MessageDeliberation::model()->findByPk($deliberation_id);
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('deliberation_decisions',
                                  array(
                                    'from'=>$model->from,
                                    'subject'=>$model->subject,  
                                    'message'=>$model->message,
                                    'category'=>$model->category,
                                    'type'=>$model->type,
                                    'from_domain_id'=>$model->from_domain_id, 
                                    'message_id'=>$model->message_id,
                                     'parent_id'=> 0,
                                    'code'=>$model->code,
                                    'asset_id'=>$model->asset_id,   
                                    'attachment'=>$model->attachment,
                                    'attachment_size'=>$model->attachment_size, 
                                    'content_type'=>$model->content_type,    
                                   'is_message_forwardable'=>0,
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                    'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$model->sender_name,
                                     'sender_domain_name'=>$model->sender_domain_name    
                                  )
			
                        );
               if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
}
