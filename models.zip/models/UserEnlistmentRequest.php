<?php

/**
 * This is the model class for table "user_enlistment_request".
 *
 * The followings are the available columns in table 'user_enlistment_request':
 * @property string $id
 * @property string $user_id
 * @property string $type
 * @property string $invoice_id
 * @property string $enlister_domain_id
 * @property integer $domain_transaction_id
 * @property string $date_requested
 * @property string $date_enlisted
 * @property string $originating_enlistment_type_address
 * @property string $content
 */
class UserEnlistmentRequest extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user_enlistment_request';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('user_id, type, invoice_id, enlister_domain_id', 'required'),
			array('domain_transaction_id', 'numerical', 'integerOnly'=>true),
			array('user_id, invoice_id, enlister_domain_id', 'length', 'max'=>10),
			array('type', 'length', 'max'=>14),
			array('originating_enlistment_type_address', 'length', 'max'=>250),
			array('date_requested, date_enlisted, content', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, user_id, type, invoice_id, enlister_domain_id, domain_transaction_id, date_requested, date_enlisted, originating_enlistment_type_address, content', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'user_id' => 'User',
			'type' => 'Type',
			'invoice_id' => 'Invoice',
			'enlister_domain_id' => 'Enlister Domain',
			'domain_transaction_id' => 'Domain Transaction',
			'date_requested' => 'Date Requested',
			'date_enlisted' => 'Date Enlisted',
			'originating_enlistment_type_address' => 'Originating Enlistment Type Address',
			'content' => 'Content',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('invoice_id',$this->invoice_id,true);
		$criteria->compare('enlister_domain_id',$this->enlister_domain_id,true);
		$criteria->compare('domain_transaction_id',$this->domain_transaction_id);
		$criteria->compare('date_requested',$this->date_requested,true);
		$criteria->compare('date_enlisted',$this->date_enlisted,true);
		$criteria->compare('originating_enlistment_type_address',$this->originating_enlistment_type_address,true);
		$criteria->compare('content',$this->content,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return UserEnlistmentRequest the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that retrieves the code of the city for enlistmet
         */
        public function getTheCityCodeForThisEnlistment($enlistment_id){
            $model = new City;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$enlistment_id);
            $enlistment = UserEnlistmentRequest::model()->find($criteria);
            
            if($enlistment['city_id']==NULL){
                return 0;
            }else{
                return $model->getTheCodeForThisCity($enlistment['city_id']);
            }
            
            
        }
        
        
          /**
         * This is the function that determines the type and size of front vie image file
         */
        public function isFrontViewTypeAndSizeLegal(){
            
           if(isset($_FILES['product_frontview_image']['name'])){
                $tmpName = $_FILES['product_frontview_image']['tmp_name'];
                $imageFileName = $_FILES['product_frontview_image']['name'];    
                $imageFileType = $_FILES['product_frontview_image']['type'];
                $imageFileSize = $_FILES['product_frontview_image']['size'];
            } 
            
            if (isset($_FILES['product_frontview_image'])) {
                $filename = $_FILES['product_frontview_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
         /**
         * This is the function that determines the type and size of back view image file
         */
        public function isBackViewAndSizeLegal(){
            
           if(isset($_FILES['product_backview_image']['name'])){
                $tmpName = $_FILES['product_backview_image']['tmp_name'];
                $imageFileName = $_FILES['product_backview_image']['name'];    
                $imageFileType = $_FILES['product_backview_image']['type'];
                $imageFileSize = $_FILES['product_backview_image']['size'];
            } 
            
            if (isset($_FILES['product_backview_image'])) {
                $filename = $_FILES['product_backview_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
         /**
         * This is the function that determines the type and size of top view image file
         */
        public function isTopViewAndSizeLegal(){
            
           if(isset($_FILES['product_topview_image']['name'])){
                $tmpName = $_FILES['product_topview_image']['tmp_name'];
                $imageFileName = $_FILES['product_topview_image']['name'];    
                $imageFileType = $_FILES['product_topview_image']['type'];
                $imageFileSize = $_FILES['product_topview_image']['size'];
            } 
            
            if (isset($_FILES['product_topview_image'])) {
                $filename = $_FILES['product_topview_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
         /**
         * This is the function that determines the type and size of bottom view image file
         */
        public function isBottomViewAndSizeLegal(){
            
           if(isset($_FILES['product_bottomview_image']['name'])){
                $tmpName = $_FILES['product_bottomview_image']['tmp_name'];
                $imageFileName = $_FILES['product_bottomview_image']['name'];    
                $imageFileType = $_FILES['product_bottomview_image']['type'];
                $imageFileSize = $_FILES['product_bottomview_image']['size'];
            } 
            
            if (isset($_FILES['product_bottomview_image'])) {
                $filename = $_FILES['product_bottomview_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that determines the type and size of right side view image file
         */
        public function isRightViewAndSizeLegal(){
            
           if(isset($_FILES['product_rightview_image']['name'])){
                $tmpName = $_FILES['product_rightview_image']['tmp_name'];
                $imageFileName = $_FILES['product_rightview_image']['name'];    
                $imageFileType = $_FILES['product_rightview_image']['type'];
                $imageFileSize = $_FILES['product_rightview_image']['size'];
            } 
            
            if (isset($_FILES['product_rightview_image'])) {
                $filename = $_FILES['product_rightview_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of left side view image file
         */
        public function isLeftViewAndSizeLegal(){
            
           if(isset($_FILES['product_leftview_image']['name'])){
                $tmpName = $_FILES['product_leftview_image']['tmp_name'];
                $imageFileName = $_FILES['product_leftview_image']['name'];    
                $imageFileType = $_FILES['product_leftview_image']['type'];
                $imageFileSize = $_FILES['product_leftview_image']['size'];
            } 
            
            if (isset($_FILES['product_leftview_image'])) {
                $filename = $_FILES['product_leftview_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
         /**
         * This is the function that determines the type and size of interior view image file
         */
        public function isInteriorViewAndSizeLegal(){
            
           if(isset($_FILES['product_interior_image']['name'])){
                $tmpName = $_FILES['product_interior_image']['tmp_name'];
                $imageFileName = $_FILES['product_interior_image']['name'];    
                $imageFileType = $_FILES['product_interior_image']['type'];
                $imageFileSize = $_FILES['product_interior_image']['size'];
            } 
            
            if (isset($_FILES['product_interior_image'])) {
                $filename = $_FILES['product_interior_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
         /**
         * This is the function that determines the type and size of engine view image file
         */
        public function isEngineViewAndSizeLegal(){
            
           if(isset($_FILES['product_engine_image']['name'])){
                $tmpName = $_FILES['product_engine_image']['tmp_name'];
                $imageFileName = $_FILES['product_engine_image']['name'];    
                $imageFileType = $_FILES['product_engine_image']['type'];
                $imageFileSize = $_FILES['product_engine_image']['size'];
            } 
            
            if (isset($_FILES['product_engine_image'])) {
                $filename = $_FILES['product_engine_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of booth view image file
         */
        public function isBoothViewAndSizeLegal(){
            
           if(isset($_FILES['product_booth_image']['name'])){
                $tmpName = $_FILES['product_booth_image']['tmp_name'];
                $imageFileName = $_FILES['product_booth_image']['name'];    
                $imageFileType = $_FILES['product_booth_image']['type'];
                $imageFileSize = $_FILES['product_booth_image']['size'];
            } 
            
            if (isset($_FILES['product_booth_image'])) {
                $filename = $_FILES['product_booth_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of content view image file
         */
        public function isContentViewAndSizeLegal(){
            
           if(isset($_FILES['product_content_image']['name'])){
                $tmpName = $_FILES['product_content_image']['tmp_name'];
                $imageFileName = $_FILES['product_content_image']['name'];    
                $imageFileType = $_FILES['product_content_image']['type'];
                $imageFileSize = $_FILES['product_content_image']['size'];
            } 
            
            if (isset($_FILES['product_content_image'])) {
                $filename = $_FILES['product_content_image']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
     /**
         * This is the function that moves front view image to its directory
         */
        public function moveTheFrontviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_frontview_image']['name'])){
                        $tmpName = $_FILES['product_frontview_image']['tmp_name'];
                        $iconName = $_FILES['product_frontview_image']['name'];    
                        $iconType = $_FILES['product_frontview_image']['type'];
                        $iconSize = $_FILES['product_frontview_image']['size'];
                  
                   }
                    if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIconFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingIconFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
			
                        
                    }
                    		
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingIconFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIconNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_frontview_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheIconNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_frontview_image'] == 'user_unavailable.png' || $icon['product_frontview_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIconFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_frontview_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
          	/**
         * This is the function that moves back view image to its directory
         */
        public function moveTheBackviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_backview_image']['name'])){
                        $tmpName = $_FILES['product_backview_image']['tmp_name'];
                        $iconName = $_FILES['product_backview_image']['name'];    
                        $iconType = $_FILES['product_backview_image']['type'];
                        $iconSize = $_FILES['product_backview_image']['size'];
                  
                   }
                   
                   if($icon_filename == NULL){
                       $iconFileName = $icon_filename;
                       return $iconFileName;
                       
                   }else{
                       if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewBackViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingBackviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                       
                   }
                    
                    
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingBackviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheBackViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_backview_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheBackViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_backview_image'] == 'user_unavailable.png' || $icon['product_backview_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewBackViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_backview_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
           	/**
         * This is the function that moves top view image to its directory
         */
        public function moveTheTopviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_topview_image']['name'])){
                        $tmpName = $_FILES['product_topview_image']['tmp_name'];
                        $iconName = $_FILES['product_topview_image']['name'];    
                        $iconType = $_FILES['product_topview_image']['type'];
                        $iconSize = $_FILES['product_topview_image']['size'];
                  
                   }
                    if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewTopViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingTopviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                        
                    }
                    
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingTopviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheTopViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_topview_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheTopViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_topview_image'] == 'user_unavailable.png' || $icon['product_topview_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewTopViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_topview_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
            	/**
         * This is the function that moves bottom view image to its directory
         */
        public function moveTheBottomviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_bottomview_image']['name'])){
                        $tmpName = $_FILES['product_bottomview_image']['tmp_name'];
                        $iconName = $_FILES['product_bottomview_image']['name'];    
                        $iconType = $_FILES['product_bottomview_image']['type'];
                        $iconSize = $_FILES['product_bottomview_image']['size'];
                  
                   }
                    if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewBottomViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingBottomviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                        
                    }
                    
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingBottomviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheBottomViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_bottomview_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheBottomViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_bottomview_image'] == 'user_unavailable.png' || $icon['product_bottomview_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewBottomViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_bottomview_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
             	/**
         * This is the function that moves right side view image to its directory
         */
        public function moveTheRightviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_rightview_image']['name'])){
                        $tmpName = $_FILES['product_rightview_image']['tmp_name'];
                        $iconName = $_FILES['product_rightview_image']['name'];    
                        $iconType = $_FILES['product_rightview_image']['type'];
                        $iconSize = $_FILES['product_rightview_image']['size'];
                  
                   }
                    if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewRightViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingRightviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                        
                    }
                    
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingRightviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheRightViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_rightview_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheRightViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_rightview_image'] == 'user_unavailable.png' || $icon['product_rightview_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewRightViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_rightview_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
          
             	/**
         * This is the function that moves left side view image to its directory
         */
        public function moveTheLeftviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_leftview_image']['name'])){
                        $tmpName = $_FILES['product_leftview_image']['tmp_name'];
                        $iconName = $_FILES['product_leftview_image']['name'];    
                        $iconType = $_FILES['product_leftview_image']['type'];
                        $iconSize = $_FILES['product_leftview_image']['size'];
                  
                   }
                    if($icon_filename == NULL){
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewLeftViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingLeftviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                        
                    }
                    
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingLeftviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheLeftViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_leftview_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheLeftViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_leftview_image'] == 'user_unavailable.png' || $icon['product_leftview_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewLeftViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_leftview_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
             	/**
         * This is the function that moves interior view image to its directory
         */
        public function moveTheInteriorviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_interior_image']['name'])){
                        $tmpName = $_FILES['product_interior_image']['tmp_name'];
                        $iconName = $_FILES['product_interior_image']['name'];    
                        $iconType = $_FILES['product_interior_image']['type'];
                        $iconSize = $_FILES['product_interior_image']['size'];
                  
                   }
                   
                   if($icon_filename == NULL){
                       $iconFileName = $icon_filename;
                         return $iconFileName;
                       
                   }else{
                       if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewInteriorViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingInteriorviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                       
                   }
                    
                    
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingInteriorviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheInteriorViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_interior_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheInteriorViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_interior_image'] == 'user_unavailable.png' || $icon['product_interior_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewInteriorViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_interior_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
          
             	/**
         * This is the function that moves engine view image to its directory
         */
        public function moveTheEngineviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_engine_image']['name'])){
                        $tmpName = $_FILES['product_engine_image']['tmp_name'];
                        $iconName = $_FILES['product_engine_image']['name'];    
                        $iconType = $_FILES['product_engine_image']['type'];
                        $iconSize = $_FILES['product_engine_image']['size'];
                  
                   }
                    if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewEngineViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingEngineviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
			
                        
                    }
                    		
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingEngineviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheEngineViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
                $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_engine_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheEngineViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_engine_image'] == 'user_unavailable.png' || $icon['product_engine_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewEngineViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_engine_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
             
             	/**
         * This is the function that moves booth view image to its directory
         */
        public function moveTheBoothviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_booth_image']['name'])){
                        $tmpName = $_FILES['product_booth_image']['tmp_name'];
                        $iconName = $_FILES['product_booth_image']['name'];    
                        $iconType = $_FILES['product_booth_image']['type'];
                        $iconSize = $_FILES['product_booth_image']['size'];
                  
                   }
                   
                   if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                       
                       
                   }else{
                       if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewBoothViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingBoothviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                       
                   }
                    
                    
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingBoothviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheBoothViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_booth_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheBoothViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_booth_image'] == 'user_unavailable.png' || $icon['product_booth_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewBoothViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_booth_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
                	/**
         * This is the function that moves content view image to its directory
         */
        public function moveTheContentviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_content_image']['name'])){
                        $tmpName = $_FILES['product_content_image']['tmp_name'];
                        $iconName = $_FILES['product_content_image']['name'];    
                        $iconType = $_FILES['product_content_image']['type'];
                        $iconSize = $_FILES['product_content_image']['size'];
                  
                   }
                   
                   if($icon_filename == NULL){
                       $iconFileName = $icon_filename;
                         return $iconFileName;
                       
                       
                   }else{
                       if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewContentViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingContentviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                       
                   }
                    
                    
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingContentviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheContentViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_content_image'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheContentViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_content_image'] == 'user_unavailable.png' || $icon['product_content_image'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewContentViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['product_content_image']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the existing front view image
         */
      public function retrieveTheExistingFrontviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_frontview_image'];
            
        }
        
        
         /**
         * This is the function that retrieves the existing back view image
         */
      public function retrieveTheExistingBackviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_backview_image'];
            
        }
        
        
         /**
         * This is the function that retrieves the existing top view image
         */
      public function retrieveTheExistingTopviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_topview_image'];
            
        }
        
        
         /**
         * This is the function that retrieves the existing bottom view image
         */
      public function retrieveTheExistingBottomviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_bottomview_image'];
            
        }
        
        
         /**
         * This is the function that retrieves the existing right view image
         */
      public function retrieveTheExistingRightviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_rightview_image'];
            
        }
        
        
         /**
         * This is the function that retrieves the existing left view image
         */
      public function retrieveTheExistingLeftviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_leftview_image'];
            
        }
        
        
          /**
         * This is the function that retrieves the existing interior view image
         */
      public function retrieveTheExistingInteriorviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_interior_image'];
            
        }
        
        
           /**
         * This is the function that retrieves the existing engine view image
         */
      public function retrieveTheExistingEngineviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_engine_image'];
            
        }
        
        
          /**
         * This is the function that retrieves the existing booth view image
         */
      public function retrieveTheExistingBoothviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_booth_image'];
            
        }
        
        
          /**
         * This is the function that retrieves the existing content view image
         */
      public function retrieveTheExistingContentviewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['product_content_image'];
            
        }
        
        
        /**
         * This is the function that confirms if a code is a product feedback type
         */
        public function isAProductFeedbackUserEnlistmentItemtype($enlistment_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$enlistment_id);
                $item= UserEnlistmentRequest::model()->find($criteria);
                
                if($item['type'] == "product"){
                    if($item['item_type'] == "feedback"){
                        return true;
                    }
                }
                return false;
                    
            
        }
        
        
         /**
         * This is the function that confirms if a code is a product feedback type
         */
        public function isAProductEnagagementUserEnlistmentItemtype($enlistment_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$enlistment_id);
                $item= UserEnlistmentRequest::model()->find($criteria);
                
                if($item['type'] == "product"){
                    if($item['item_type'] == "engagement"){
                        return true;
                    }
                }
                return false;
                    
            
        }
        
        
         /**
         * This is the function that confirms if a code is a product after taste type
         */
        public function isAProductFeedbackEnagagementUserEnlistmentItemtype($enlistment_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$enlistment_id);
                $item= UserEnlistmentRequest::model()->find($criteria);
                
                if($item['type'] == "product"){
                    if($item['item_type'] == "aftertaste"){
                        return true;
                    }
                }
                return false;
                    
            
        }
        
        
          /**
         * This is the function that confirms if a code is a product authenticity type
         */
        public function isAProductAuthenticityUserEnlistmentItemtype($enlistment_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$enlistment_id);
                $item= UserEnlistmentRequest::model()->find($criteria);
                
                if($item['type'] == "product"){
                    if($item['item_type'] == "product"){
                        return true;
                    }
                }
                return false;
                    
            
        }
        
        
          /**
         * This is the function that confirms if a code is a message authenticity type
         */
        public function isAMessageAuthenticityUserEnlistmentItemtype($enlistment_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$enlistment_id);
                $item= UserEnlistmentRequest::model()->find($criteria);
                
               if($item['item_type'] == "messages"){
                        return true;
                    }
               
                return false;
                    
            
        }
        
        
        
         /**
         * This is the function that confirms if a code is an id card type
         */
        public function isAnIdCardItemType($enlistment_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$enlistment_id);
                $item= UserEnlistmentRequest::model()->find($criteria);
                
                if($item['type'] == "identification"){
                    if($item['item_type'] == "idcard"){
                        return true;
                    }
                }
                return false;
                    
            
        }
        
        
         /**
         * This is the function that confirms if a code is a business card type
         */
        public function isABusinessCardItemType($enlistment_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$enlistment_id);
                $item= UserEnlistmentRequest::model()->find($criteria);
                
                if($item['type'] == "identification"){
                    if($item['item_type'] == "businesscard"){
                        return true;
                    }
                }
                return false;
                    
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of user photo for an id card file
         */
        public function isUserPhotoViewTypeAndSizeLegal(){
            
           if(isset($_FILES['id_card_holder_photo']['name'])){
                $tmpName = $_FILES['id_card_holder_photo']['tmp_name'];
                $imageFileName = $_FILES['id_card_holder_photo']['name'];    
                $imageFileType = $_FILES['id_card_holder_photo']['type'];
                $imageFileSize = $_FILES['id_card_holder_photo']['size'];
            } 
            
            if (isset($_FILES['id_card_holder_photo'])) {
                $filename = $_FILES['id_card_holder_photo']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
         /**
         * This is the function that determines the type and size of id card front view file
         */
        public function isCardFrontViewTypeAndSizeLegal(){
            
           if(isset($_FILES['id_card_front_view']['name'])){
                $tmpName = $_FILES['id_card_front_view']['tmp_name'];
                $imageFileName = $_FILES['id_card_front_view']['name'];    
                $imageFileType = $_FILES['id_card_front_view']['type'];
                $imageFileSize = $_FILES['id_card_front_view']['size'];
            } 
            
            if (isset($_FILES['id_card_front_view'])) {
                $filename = $_FILES['id_card_front_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of id card back view file
         */
        public function isCardBackViewTypeAndSizeLegal(){
            
           if(isset($_FILES['id_card_back_view']['name'])){
                $tmpName = $_FILES['id_card_back_view']['tmp_name'];
                $imageFileName = $_FILES['id_card_back_view']['name'];    
                $imageFileType = $_FILES['id_card_back_view']['type'];
                $imageFileSize = $_FILES['id_card_back_view']['size'];
            } 
            
            if (isset($_FILES['id_card_back_view'])) {
                $filename = $_FILES['id_card_back_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
        
         /**
         * This is the function that determines the type and size of business card holder file
         */
        public function isCardOwnerPhotoViewTypeAndSizeLegal(){
            
           if(isset($_FILES['business_card_holder_photo']['name'])){
                $tmpName = $_FILES['business_card_holder_photo']['tmp_name'];
                $imageFileName = $_FILES['business_card_holder_photo']['name'];    
                $imageFileType = $_FILES['business_card_holder_photo']['type'];
                $imageFileSize = $_FILES['business_card_holder_photo']['size'];
            } 
            
            if (isset($_FILES['business_card_holder_photo'])) {
                $filename = $_FILES['business_card_holder_photo']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
          /**
         * This is the function that determines the type and size of business card front view image file
         */
        public function isBusinessCardFrontViewTypeAndSizeLegal(){
            
           if(isset($_FILES['business_card_front_view']['name'])){
                $tmpName = $_FILES['business_card_front_view']['tmp_name'];
                $imageFileName = $_FILES['business_card_front_view']['name'];    
                $imageFileType = $_FILES['business_card_front_view']['type'];
                $imageFileSize = $_FILES['business_card_front_view']['size'];
            } 
            
            if (isset($_FILES['business_card_front_view'])) {
                $filename = $_FILES['business_card_front_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
         /**
         * This is the function that determines the type and size of business card front view image file
         */
        public function isBusinessCardBackViewTypeAndSizeLegal(){
            
           if(isset($_FILES['business_card_back_view']['name'])){
                $tmpName = $_FILES['business_card_back_view']['tmp_name'];
                $imageFileName = $_FILES['business_card_back_view']['name'];    
                $imageFileType = $_FILES['business_card_back_view']['type'];
                $imageFileSize = $_FILES['business_card_back_view']['size'];
            } 
            
            if (isset($_FILES['business_card_back_view'])) {
                $filename = $_FILES['business_card_back_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
          if(($imageFileType == 'image/jpg' or $imageFileType =='image/png' or $imageFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
        
            }else{
                return false;
            }
            
        }
        
        
        
        
        
      /**
         * This is the function that moves id card holder photo  image to its directory
         */
        public function moveTheUserPhotoToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['id_card_holder_photo']['name'])){
                        $tmpName = $_FILES['id_card_holder_photo']['tmp_name'];
                        $iconName = $_FILES['id_card_holder_photo']['name'];    
                        $iconType = $_FILES['id_card_holder_photo']['type'];
                        $iconSize = $_FILES['id_card_holder_photo']['size'];
                  
                   }
                   
                   if($icon_filename == NULL){
                       $iconFileName = $icon_filename;
                         return $iconFileName;
                       
                   }else{
                       if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewCardholderUserPhotoViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingCardholderUserPhotoFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                       
                   }
                    
                    
					
                       
                               
        }
        
		
		
        /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingCardholderUserPhotoFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheCardholderPhotoNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['id_card_holder_photo'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheCardholderPhotoNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['id_card_holder_photo'] == 'user_unavailable.png' || $icon['id_card_holder_photo'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		

        /**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewCardholderUserPhotoViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['id_card_holder_photo']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
         /**
         * This is the function that moves id card front view  image to its directory
         */
        public function moveTheCardFrontviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['id_card_front_view']['name'])){
                        $tmpName = $_FILES['id_card_front_view']['tmp_name'];
                        $iconName = $_FILES['id_card_front_view']['name'];    
                        $iconType = $_FILES['id_card_front_view']['type'];
                        $iconSize = $_FILES['id_card_front_view']['size'];
                  
                   }
                    
                   if($icon_filename == NULL){
                       $iconFileName = $icon_filename;
                         return $iconFileName;
                       
                       
                   }else{
                       if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIdCardFrontViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingCardFrontviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                       
                   }
                    
					
                       
                               
        }
        
		
		
        /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingCardFrontviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIdCardFrontViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['id_card_front_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheIdCardFrontViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['id_card_front_view'] == 'user_unavailable.png' || $icon['id_card_front_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		

        /**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIdCardFrontViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['id_card_front_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
            /**
         * This is the function that moves id card back view  image to its directory
         */
        public function moveTheCardBackviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['id_card_back_view']['name'])){
                        $tmpName = $_FILES['id_card_back_view']['tmp_name'];
                        $iconName = $_FILES['id_card_back_view']['name'];    
                        $iconType = $_FILES['id_card_back_view']['type'];
                        $iconSize = $_FILES['id_card_back_view']['size'];
                  
                   }
                    
                   if($icon_filename == NULL){
                       $iconFileName = $icon_filename;
                         return $iconFileName;
                       
                   }else{
                       if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIdCardBackViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingIdCardBackviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                       
                   }
                    
					
                       
                               
        }
        
		
		
        /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingIdCardBackviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIdCardBackViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
                $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['id_card_back_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheIdCardBackViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['id_card_back_view'] == 'user_unavailable.png' || $icon['id_card_back_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		

        /**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIdCardBackViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['id_card_back_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
        /**
         * This is the function that moves business card holder photo  image to its directory
         */
        public function moveTheCardOwnerPhotoToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['business_card_holder_photo']['name'])){
                        $tmpName = $_FILES['business_card_holder_photo']['tmp_name'];
                        $iconName = $_FILES['business_card_holder_photo']['name'];    
                        $iconType = $_FILES['business_card_holder_photo']['type'];
                        $iconSize = $_FILES['business_card_holder_photo']['size'];
                  
                   }
                    if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewBusinessCardholderUserPhotoViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingBusinessCardholderUserPhotoFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                        
                        
                    }
                    
					
                       
                               
        }
        
		
		
        /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingBusinessCardholderUserPhotoFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheBusinessCardholderPhotoNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['business_card_holder_photo'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheBusinessCardholderPhotoNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['business_card_holder_photo'] == 'user_unavailable.png' || $icon['business_card_holder_photo'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		

        /**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewBusinessCardholderUserPhotoViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['business_card_holder_photo']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
         /**
         * This is the function that moves business card front view  image to its directory
         */
        public function moveTheBusinessCardFrontviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['business_card_front_view']['name'])){
                        $tmpName = $_FILES['business_card_front_view']['tmp_name'];
                        $iconName = $_FILES['business_card_front_view']['name'];    
                        $iconType = $_FILES['business_card_front_view']['type'];
                        $iconSize = $_FILES['business_card_front_view']['size'];
                  
                   }
                   
                   if($icon_filename == NULL){
                       $iconFileName = $icon_filename;
                         return $iconFileName;
                       
                       
                   }else{
                       if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewBusinessCardFrontViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingBusinessCardFrontviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                       
                   }
                    
                    
					
                       
                               
        }
        
		
		
        /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingBusinessCardFrontviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheBusinessCardFrontViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['business_card_front_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheBusinessCardFrontViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['business_card_front_view'] == 'user_unavailable.png' || $icon['business_card_front_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		

        /**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewBusinessCardFrontViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['business_card_front_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        /**
         * This is the function that moves business card back  view  image to its directory
         */
        public function moveTheBusinessCardBackviewToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['business_card_back_view']['name'])){
                        $tmpName = $_FILES['business_card_back_view']['tmp_name'];
                        $iconName = $_FILES['business_card_back_view']['name'];    
                        $iconType = $_FILES['business_card_back_view']['type'];
                        $iconSize = $_FILES['business_card_back_view']['size'];
                  
                   }
                    if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                        
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewBusinessCardBackViewFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                
                                if($this->removeTheExistingBusinessCardBackviewFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                        
                    }
                    
					
                       
                               
        }
        
		
		
        /**
         * This is the function that removes an existing image file
         */
        public function removeTheExistingBusinessCardBackviewFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheBusinessCardBackViewNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\images\\";
               $directoryPath = "../appspace_assets/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['business_card_back_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a image is the default
         */
        public function isTheBusinessCardBackViewNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['business_card_back_view'] == 'user_unavailable.png' || $icon['business_card_back_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		

        /**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewBusinessCardBackViewFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= UserEnlistmentRequest::model()->find($criteria);
                
                if($icon['business_card_back_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
           /**
         * This is the function that retrieves the existing id card holder passport view image
         */
      public function retrieveTheExistingIdentityCardholderImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['id_card_holder_photo'];
            
        }
        
        
            /**
         * This is the function that retrieves the existing id card front view image
         */
      public function retrieveTheExistingIdentityCardFrontViewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['id_card_front_view'];
            
        }
        
        
               /**
         * This is the function that retrieves the existing id card back view image
         */
      public function retrieveTheExistingIdentityCardBackViewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['id_card_back_view'];
            
        }
        
        
        
             /**
         * This is the function that retrieves the existing business card holder passport view image
         */
      public function retrieveTheExistingBusinessCardholderImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['business_card_holder_photo'];
            
        }
        
        
            /**
         * This is the function that retrieves the existing buiness card front view image
         */
      public function retrieveTheExistingBusinessCardFrontViewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['business_card_front_view'];
            
        }
        
        
               /**
         * This is the function that retrieves the existing id card back view image
         */
      public function retrieveTheExistingBusinessCardBackViewImage($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $image= UserEnlistmentRequest::model()->find($criteria);
                
                return $image['business_card_back_view'];
            
        }
        
        
        /**
         * This is the function that generates an events code
         */
        public function generateThisEventCode($domain_id,$platform,$item_type){
            $model = new EnlistmentVerificationCode;
            $random_number = $model->generateTheRandomNumber();
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $platform_code = $model->getThePlatformCode($platform);
                
            $item_type_code = $model->getThisEnlistmentItemTypeCode($item_type);
             //get the first 3 letters of the domain name
             $domain_first_three_letters = strtoupper($this->getTheDomainNameFirstThreeLetters($domain_id));
            $event_code = "$domain_first_three_letters$item_type_code$day$month$random_number$platform_code";
            return $event_code;
        }
        
         /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getTheDomainNameFirstThreeLetters($domain_id){
                $model = new ResourceGroupCategory;
                //get the domain name
                $domainname = $model->getTheDomainNameOfThisDomain($domain_id);
                        
                //obtain the first four letters
                $substring = substr($domainname,0,3);
                
                return $substring;
            }
            
            
            /**
         * This is the function that retrieves the enlis id of an event
         */
        public function getThisEventEnlistmentId($event_code){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='event_code=:code';
                $criteria->params = array(':code'=>"$event_code");
                $enlistment= UserEnlistmentRequest::model()->find($criteria);
                return $enlistment['id'];
        }
        
        
        /**
         * This is the function that confirms if a user is permitted to enroll delegates to an event
         */
        public function isPermittedToEnrollDelegatesForThisEvent($event_code,$user_id){
            $model = new User;
            $user_email = $model->getTheEmailAddressOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='event_code=:code';
            $criteria->params = array(':code'=>$event_code);
            $code = UserEnlistmentRequest::model()->find($criteria);
            
            if($this->isUserLegibleToEnrolDelegates($user_email,$code['id'])){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if a user is legible to consume a code
         */
        public function isUserLegibleToEnrolDelegates($user_email,$event_id){
            $targets = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$event_id);
             $event = UserEnlistmentRequest::model()->find($criteria); 
            
           
           if($event['event_delegate_enlisters'] == NULL){
                return true;
            }else if($event['event_delegate_enlisters'] == ""){
                return true;
            }else{
               $users = explode(",",$event['event_delegate_enlisters']);
                foreach($users as $user){
                    $targets[] = strtolower(ltrim(rtrim($user)));
                }
                if(in_array(strtolower($user_email),$targets)){
                    return true;
                }else{
                    return false;
            }
               
            }
           
            
        }
        
        
         /**
         * This is the function that confirms if an event code exist and it is available for delegate enrollment
         */
        public function isThisEventAvailableForDelegateEnrollment($event_code){
                if($this->isEventAlreadyEnlisted($event_code)){
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='event_code=:code';
                     $criteria->params = array(':code'=>"$event_code");
                     $event= UserEnlistmentRequest::model()->find($criteria);
                     
                     if($this->isEventDateStillAvailableForEnrollment($event['event_date'])){
                         if($event['event_status'] == "pending"){
                             return true;
                         }else if($event['event_status'] == "running"){
                             if($event['allow_delegate_enrollment_while_event_is_ongoing'] == 1){
                                 return true;
                             }else{
                                 return false;
                             }
                         }else{
                             return false;
                         }
                         
                     }else{
                         return false;
                     }
                
                    
                }else{
                    return false;
                }
               
        }
        
        
        
        /**
         * This is the function that confirms if an event code exist and it is available for delegate enrollment
         */
        public function isThisEventAvailableForDelegateEnrollmentGivenEventId($event_id){
                if($this->isEventAlreadyEnlistedGivenId($event_id)){
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='id=:id';
                     $criteria->params = array(':id'=>$event_id);
                     $event= UserEnlistmentRequest::model()->find($criteria);
                     
                     if($this->isEventDateStillAvailableForEnrollment($event['event_date'])){
                         if($event['event_status'] == "pending"){
                             return true;
                         }else if($event['event_status'] == "running"){
                             if($event['allow_delegate_enrollment_while_event_is_ongoing'] == 1){
                                 return true;
                             }else{
                                 return false;
                             }
                         }else{
                             return false;
                         }
                         
                     }else{
                         return false;
                     }
                
                    
                }else{
                    return false;
                }
               
        }
        
        
        /**
         * This is the function that confirms if an event exist
         */
        public function isEventAlreadyEnlisted($event_code){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_enlistment_request')
                    ->where("event_code = '$event_code'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that confirms if an event exist
         */
        public function isEventAlreadyEnlistedGivenId($event_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_enlistment_request')
                    ->where("id = $event_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that verifies if a verification is still valid
         */
        public function isEventDateStillAvailableForEnrollment($date_of_expiry){
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
           $expiry = getdate(strtotime($date_of_expiry));
            //getdate(date("Y-m-d H:i:s", strtotime($date_of_expiry))); 
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            
            if($expiry['year']-$year<0){
                return false;
            }else if($expiry['year']-$year==0){
                if($expiry['mon']-$month<0){
                    return false;
                }else if($expiry['mon']-$month >0){
                    return true;
                }else if($expiry['mon']-$month ==0){    
                   if($expiry['mday']-$day<0){
                       return false;
                   }else{
                       return true;
                   }
                }else{
                    return true;
                }
            }else{
                return true;
            }
            
           
        }
        
        
        /**
         * This is the function that retrieves an event code given its id
         */
        public function getThisEventCode($event_id){
               $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$event_id);
                $enlistment= UserEnlistmentRequest::model()->find($criteria);
                return $enlistment['event_code'];
        }
        
        /**
         * This is the function that confirms if delegate unenrollment is permitted for an event
         */
        public function isDelegateUnenrollmentAllowedForEvent($event_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$event_id);
                $event= UserEnlistmentRequest::model()->find($criteria);
                
                if($this->isEventDateStillAvailableForEnrollment($event['event_date'])){
                         if($event['event_status'] == "pending"){
                             return true;
                         }else if($event['event_status'] == "running"){
                             return false;
                         }else{
                             return false;
                         }
                         
                     }else{
                         return false;
                     }
        }
        
        
        /**
         * This is the function that determines if an event is with participants
         */
        public function isThisEventWithParticipants($event_code){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='event_code=:code';
                $criteria->params = array(':code'=>"$event_code");
                $event= UserEnlistmentRequest::model()->find($criteria);
                
                if($event['event_status'] == 'running'){
                    return true;
                }else if($event['event_status'] == 'closed'){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that confirms if self dlegate enrollment is permitted on an event
         * 
         */
        public function isSelfServiceEnrollmentSupportedForThisEvent($event_code){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='event_code=:code';
                $criteria->params = array(':code'=>"$event_code");
                $event= UserEnlistmentRequest::model()->find($criteria);
                
                if($event['allow_self_service_delegate_enrollment'] == 1){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that confirms if self dlegate enrollment is permitted on an event
         * 
         */
        public function isSelfServiceEnrollmentSupportedForThisEventGivenEventId($event_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>"$event_id");
                $event= UserEnlistmentRequest::model()->find($criteria);
                
                if($event['allow_self_service_delegate_enrollment'] == 1){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that gets the enlister of an event
         */
        public function getTheEnlisterOfThisEvent($event_code){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='event_code=:code';
            $criteria->params = array(':code'=>"$event_code");
            $event= UserEnlistmentRequest::model()->find($criteria);
            
            return $event['user_id'];
        }
        
        
        
        /**
         * This is the function that gets the enlister of an event
         */
        public function getTheEnlisterOfThisEventGivenId($event_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$event_id);
            $event= UserEnlistmentRequest::model()->find($criteria);
            
            return $event['user_id'];
        }
        
        
         /**
         * This is the function that gets the enlister of an event
         */
        public function getTheDomainIdOfTheEventOrganizer($event_code){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='event_code=:code';
            $criteria->params = array(':code'=>"$event_code");
            $event= UserEnlistmentRequest::model()->find($criteria);
            
            return $event['enlister_domain_id'];
        }
        
        
        
         /**
         * This is the function that gets the enlister of an event
         */
        public function getTheDomainIdOfTheEventOrganizerGivenEventId($event_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$event_id);
            $event= UserEnlistmentRequest::model()->find($criteria);
            
            return $event['enlister_domain_id'];
        }
        
        /**
         * This is the function that retrieves the date of a envent
         */
        public function getTheExpirationDateOfThisEvent($event_code){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='event_code=:code';
            $criteria->params = array(':code'=>"$event_code");
            $event= UserEnlistmentRequest::model()->find($criteria);
            
            return $event['event_date'];
        }
        
        
        
        /**
         * This is the function that retrieves the date of a envent
         */
        public function getTheExpirationDateOfThisEventGivenEventId($event_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$event_id);
            $event= UserEnlistmentRequest::model()->find($criteria);
            
            return $event['event_date'];
        }
        
        
         /**
         * This is the function that retrieves a project type
         */
        public function getThisProjectType($project_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$project_id);
            $project= UserEnlistmentRequest::model()->find($criteria);
            
            return $project['feedback_item_type'];
        }
        
        /**
         * This is the function that confirms if a domain location contains a project type
         */
        public function doesThisLocationHasProjectOfThisType($location_id,$project_type){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_enlistment_request')
                    ->where("location_id = $location_id and feedback_item_type= '$project_type'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that gets the name of a project or a user enlistment
         */
        public function getThisProjectName($project_id){
           $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$project_id);
            $project= UserEnlistmentRequest::model()->find($criteria);
            
            return $project['product_name'];
        }
        
       
}
