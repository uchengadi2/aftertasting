<?php

/**
 * This is the model class for table "message".
 *
 * The followings are the available columns in table 'message':
 * @property integer $id
 * @property string $from
 * @property integer $to
 * @property string $to_recepients_list
 * @property string $cc_recepients_list
 * @property string $subject
 * @property string $message
 * @property string $category
 * @property integer $parent_id
 * @property string $type
 * @property integer $from_domain_id
 * @property integer $to_domain_id
 * @property string $issues_and_values_id
 * @property string $attachment
 * @property integer $is_read
 * @property integer $is_attachment_downloaded
 * @property string $code
 * @property string $date_sent
 * @property string $date_recieved
 * @property integer $is_message_forwardable
 * @property integer $is_to_list_a_network
 * @property integer $is_cc_list_a_network
 * @property integer $cc
 */
class Message extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'message';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('from, issues_and_values_id', 'required'),
			array('to, parent_id, from_domain_id, to_domain_id, is_read, is_attachment_downloaded, is_message_forwardable, is_to_list_a_network, is_cc_list_a_network, cc', 'numerical', 'integerOnly'=>true),
			array('from, issues_and_values_id', 'length', 'max'=>10),
			array('to_recepients_list, cc_recepients_list, subject, attachment', 'length', 'max'=>250),
			array('category', 'length', 'max'=>12),
			array('type', 'length', 'max'=>6),
			array('code', 'length', 'max'=>200),
			array('message, date_sent, date_recieved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, from, to, to_recepients_list, cc_recepients_list, subject, message, category, parent_id, type, from_domain_id, to_domain_id, issues_and_values_id, attachment, is_read, is_attachment_downloaded, code, date_sent, date_recieved, is_message_forwardable, is_to_list_a_network, is_cc_list_a_network, cc', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'from' => 'From',
			'to' => 'To',
			'to_recepients_list' => 'To Recepients List',
			'cc_recepients_list' => 'Cc Recepients List',
			'subject' => 'Subject',
			'message' => 'Message',
			'category' => 'Category',
			'parent_id' => 'Parent',
			'type' => 'Type',
			'from_domain_id' => 'From Domain',
			'to_domain_id' => 'To Domain',
			'issues_and_values_id' => 'Issues And Values',
			'attachment' => 'Attachment',
			'is_read' => 'Is Read',
			'is_attachment_downloaded' => 'Is Attachment Downloaded',
			'code' => 'Code',
			'date_sent' => 'Date Sent',
			'date_recieved' => 'Date Recieved',
			'is_message_forwardable' => 'Is Message Forwardable',
			'is_to_list_a_network' => 'Is To List A Network',
			'is_cc_list_a_network' => 'Is Cc List A Network',
			'cc' => 'Cc',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('from',$this->from,true);
		$criteria->compare('to',$this->to);
		$criteria->compare('to_recepients_list',$this->to_recepients_list,true);
		$criteria->compare('cc_recepients_list',$this->cc_recepients_list,true);
		$criteria->compare('subject',$this->subject,true);
		$criteria->compare('message',$this->message,true);
		$criteria->compare('category',$this->category,true);
		$criteria->compare('parent_id',$this->parent_id);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('from_domain_id',$this->from_domain_id);
		$criteria->compare('to_domain_id',$this->to_domain_id);
		$criteria->compare('issues_and_values_id',$this->issues_and_values_id,true);
		$criteria->compare('attachment',$this->attachment,true);
		$criteria->compare('is_read',$this->is_read);
		$criteria->compare('is_attachment_downloaded',$this->is_attachment_downloaded);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('date_sent',$this->date_sent,true);
		$criteria->compare('date_recieved',$this->date_recieved,true);
		$criteria->compare('is_message_forwardable',$this->is_message_forwardable);
		$criteria->compare('is_to_list_a_network',$this->is_to_list_a_network);
		$criteria->compare('is_cc_list_a_network',$this->is_cc_list_a_network);
		$criteria->compare('cc',$this->cc);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Message the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that executes the sending of emails to recepients
         */
        public function executeTheSendingOfEmailToRecepient($model){
            $model = new User;
               $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message',
                                  array(
                                    'from'=>$model->from,
                                    'to'=>$model->to,
                                    'cc'=>$model->cc, 
                                    'is_to_list_a_network'=>$model->is_to_list_a_network,
                                    'is_cc_list_a_network'=>$model->is_cc_list_a_network,   
                                    'to_recepients_list'=>$model->to_recepients_list,   
                                    'cc_recepients_list'=>$model->cc_recepients_list, 
                                    'subject'=>$model->subject,
                                    'message'=>$model->message,
                                    'category'=>$model->category,
                                    'type'=>$model->type,
                                    'from_domain_id'=>$model->from_domain_id, 
                                    'to_domain_id'=>$model->to_domain_id,
                                    'issues_and_values_id'=>$model->issues_and_values_id,
                                    'code'=>$model->code,
                                   'is_message_forwardable'=>$model->is_message_forwardable,
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                    'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$model->getTheNameOfThisMember($model->from),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($model->from_domain_id)       
                                  )
			
                        );
                if($result>0){
                    if($this->isSendingInformationalPrivateEmailASuccess($model->to,$model->from,$model->from_domain_id,$model->subject)){
                        return $this->getTheCurrentMessageIdOfThisReceipient($model->code);
                    }else{
                        return $this->getTheCurrentMessageIdOfThisReceipient($model->code);
                    }
                    
                }else{
                    return 0;
                }
               
           
        }
        
        
        /**
         * This is the finction that retrieves the last mesage id of this user
         */
        public function getTheCurrentMessageIdOfThisReceipient($code){
            //retreiev all the messages from this user
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="code=:code";
            $criteria->params = array(':code'=>"$code");
            $messages= Message::model()->findAll($criteria);
             $recent = 0;
             foreach($messages as $mess){
                 if($mess['id']>$recent){
                     $recent = $mess['id'];
                 }
             }
             return $recent;
        }
        
        
        /**
         * This is the function that writes an email message to the sender's outbox
         */
        public function writeTheseEmailMessageToTheSenderOutbox($model,$buckets,$is_bucket_empty){
            $bucket_model = new MessageHasBuckets;
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message',
                                  array(
                                    'from'=>$model->from,
                                    'is_to_list_a_network'=>$model->is_to_list_a_network,
                                    'is_cc_list_a_network'=>$model->is_cc_list_a_network,   
                                    'to_recepients_list'=>$model->to_recepients_list,   
                                    'cc_recepients_list'=>$model->cc_recepients_list, 
                                    'subject'=>$model->subject,
                                    'message'=>$model->message,
                                    'category'=>$model->category,
                                    'type'=>strtolower("outbox"),
                                    'from_domain_id'=>$model->from_domain_id, 
                                    'to_domain_id'=>$model->to_domain_id,
                                    'issues_and_values_id'=>$model->issues_and_values_id,
                                    'code'=>$model->code,
                                    'is_message_forwardable'=>$model->is_message_forwardable,
                                    'date_sent'=>new CDbExpression('NOW()'),
                                     'date_recieved'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($model->from),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($model->from_domain_id)         
                                  )
			
                        );
                
                //write the buckets if any to the outbox   
                if($is_bucket_empty == false){
                    $bucket_model->attachTheAssetsInTheBucket($this->getTheCurrentMessageIdOfThisReceipient($model->code),$buckets);
                }
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that sends private email to a message recepient
         */
        public function isSendingInformationalPrivateEmailASuccess($to,$from,$from_domain_id,$subject){
            $model = new User;
            //get the email of this receiver as well as te from domain name
            $email = $model->getTheEmailAddressOfThisUser($to);
            $domain_name = $this->getTheDomainNameOfThisDomain($from_domain_id);
            
            return true;
        }
        
        /**
         * This is the function that gets the domain name of a domain
         */
        public function getTheDomainNameOfThisDomain($domain_id){
            $model = new Resourcegroupcategory;
            return $model->getTheDomainNameOfThisDomain($domain_id);
        } 
        
        
        /**
         * This is the function that executes the sending of announcement to recepients
         */
        public function executeTheSendingOfAnnouncementToRecepient($model){
            $model = new User;
               $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message',
                                  array(
                                    'from'=>$model->from,
                                    'to'=>$model->to,
                                    'cc'=>$model->cc, 
                                    'is_to_list_a_network'=>$model->is_to_list_a_network,
                                    'is_cc_list_a_network'=>$model->is_cc_list_a_network,   
                                    'to_recepients_list'=>$model->to_recepients_list,   
                                    'cc_recepients_list'=>$model->cc_recepients_list, 
                                    'subject'=>$model->subject,
                                    'message'=>$model->message,
                                    'category'=>$model->category,
                                    'type'=>$model->type,
                                    'from_domain_id'=>$model->from_domain_id, 
                                    'to_domain_id'=>$model->to_domain_id,
                                    'issues_and_values_id'=>$model->issues_and_values_id,
                                    'code'=>$model->code,
                                   'is_message_forwardable'=>$model->is_message_forwardable,
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                    'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$model->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)     
                                  )
			
                        );
                if($result>0){
                    if($this->isSendingInformationalPrivateEmailASuccess($model->to,$model->from,$model->from_domain_id,$model->subject)){
                        return $this->getTheCurrentMessageIdOfThisReceipient($model->code);
                    }else{
                        return $this->getTheCurrentMessageIdOfThisReceipient($model->code);
                    }
                    
                }else{
                    return 0;
                }
               
           
        }
        
        
        
        /**
         * This is the function that writes an announcement message to the sender's outbox
         */
        public function writeTheseAnnouncementMessageToTheSenderOutbox($model,$buckets,$is_bucket_empty){
            $bucket_model = new MessageHasBuckets;
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message',
                                  array(
                                    'from'=>$model->from,
                                    'is_to_list_a_network'=>$model->is_to_list_a_network,
                                    'is_cc_list_a_network'=>$model->is_cc_list_a_network,   
                                    'to_recepients_list'=>$model->to_recepients_list,   
                                    'cc_recepients_list'=>$model->cc_recepients_list, 
                                    'subject'=>$model->subject,
                                    'message'=>$model->message,
                                    'category'=>$model->category,
                                    'type'=>strtolower("outbox"),
                                    'from_domain_id'=>$model->from_domain_id, 
                                    'to_domain_id'=>$model->to_domain_id,
                                    'issues_and_values_id'=>$model->issues_and_values_id,
                                    'code'=>$model->code,
                                    'is_message_forwardable'=>$model->is_message_forwardable,
                                    'date_sent'=>new CDbExpression('NOW()'),
                                      'date_recieved'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($model->from),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($model->from_domain_id) 
                                  )
			
                        );
                
                //write the buckets if any to the outbox   
                if($is_bucket_empty == false){
                    $bucket_model->attachTheAssetsInTheBucket($this->getTheCurrentMessageIdOfThisReceipient($model->code),$buckets);
                }
                
               if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that forwards a message to a user's  email address
         */
        public function isTheForwardingOfThisEmailMessageASuccess($message_id,$user_id){
            $model = new User;
            //get the user's external email address
            $user_email = $model->getTheEmailAddressOfThisUser($user_id);
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="id=:id";
            $criteria->params = array(':id'=>$message_id);
            $message= Message::model()->find($criteria);
            
            //send the message to the email box
            if($this->isSendingThisMessageToTheEmailBoxASuccess($user_email,$message['message'],$message['subject'],$message['from'],$message['attachment'])){
                return true;
            }else{
                return false;
            }
            
            
            
        }
        
        
        /**
         * This is the function that sends email to a user
         */
        public function isSendingThisMessageToTheEmailBoxASuccess($user_email,$message,$subject,$from,$attachment){
            //send the email her;
            return true;
            
        }
        
        
        /**
         * This is the function that sends a chat message to a recipient
         */
        public function executesendingChatMessageToThisColleague($issue,$col,$message,$code,$user_id,$domain_id,$content_type,$filesize,$filename,$is_group){
            $model = new User;
            
            $subject = $this->getTheIssuesAndvaluesForThisMessage($issue);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message',
                                  array(
                                    'from'=>$user_id,
                                    'to'=>$col,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('inbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'to_domain_id'=>$model->getTheDomainOfThisUser($col),
                                    'issues_and_values_id'=>$issue,
                                    'code'=>$code,
                                     'attachment'=>$filename,
                                    'attachment_size'=>$filesize, 
                                    'content_type'=>$content_type,     
                                   'is_message_forwardable'=>0,
                                    'is_group_messaging'=>$is_group,  
                                    'date_sent'=>new CDbExpression('NOW()'),
                                     'date_recieved'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$model->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)   
                                  )
			
                        );
                if($result>0){
                    if($this->isSendingInformationalPrivateEmailASuccess($col,$user_id,$domain_id,"$subject")){
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }else{
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }
                    
                }else{
                    return 0;
                }
            
            return 0;
            
        }
        
        
        /**
         * This is the function that gets the issues and value name of an issue id
         */
        public function getTheIssuesAndvaluesForThisMessage($issue){
            $model = new IssuesAndValues;
            return $model->getTheIssuesAndvaluesForThisMessage($issue);
        }
        
        
        /**
         * This is the function that writes a chat message to the sender outbox
         */
        public function writeThisChatMessageToTheSenderOutbox($issue,$message,$code,$buckets,$is_bucket_empty,$user_id,$domain_id,$content_type,$filesize,$filename,$is_group){
            $bucket_model = new MessageHasBuckets;
            $subject = $this->getTheIssuesAndvaluesForThisMessage($issue);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message',
                                  array(
                                    'from'=>$user_id,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('outbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'issues_and_values_id'=>$issue,
                                    'code'=>$code,
                                     'attachment'=>$filename,
                                    'attachment_size'=>$filesize, 
                                    'content_type'=>$content_type,       
                                   'is_message_forwardable'=>0,
                                    'is_group_messaging'=>$is_group,    
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                     'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)  
                                  )
			
                        );
                 //write the buckets if any to the outbox   
                if($is_bucket_empty == false){
                    $bucket_model->attachTheAssetsInTheBucket($this->getTheCurrentMessageIDOfThisReceipient("$code"),$buckets);
                }
                
               if($result>0){
                    $this->getTheCurrentMessageIdOfThisReceipient("$code");
                }else{
                    return 0;
                }
            
        }
        
        
        /**
         * This is the function that gets a members domain is
         */
        public function getTheDomainOfThisUser($user_id){
            $model = new User;
            return $model->getTheDomainOfThisUser($user_id);
        }
        
        
         /**
         * This is the function that generates codes for a message
         */
        public function generateTheCodeForThisMessage($user_id,$domain_id,$issue,$category){
                          
            $model = new User;   
            //get the substring of the domain name
             $domain_name_sub = rtrim(strtoupper($this->getTheDomainNameFirstThreeLetters($domain_id)));
                
                //get the date of messaging
              $message_date = date("dmY",$this->getTheDateOfThisMessage());
                
                //generate a random number
               $random_number = $this->generateTheRandomNumber();
                
               //get the email of this user
                $email = $model->getTheEmailAddressOfThisUser($user_id);
                
              //get the message code
               $message_code = "$issue$category$message_date-$domain_name_sub-$random_number-$email";
               
              
                
               return $message_code;
        }
        
        
        /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getTheDomainNameFirstThreeLetters($domain_id){
               $model= new Resourcegroupcategory; 
               //get the domain name
                $domainname = $model->getTheDomainNameOfThisDomain($domain_id);
                //obtain the first four letters
                $substring = substr($domainname,0,3);
                
                return $substring;
            }
            
            
             /**
            * This is the function that fetches the order date for order number construction
            */
            public function getTheDateOfThisMessage(){
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                
               return $today;
            }
        
            
             /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
            
            
            /**
             * This is the function that retreives the code of a message
             */
            public function getTheCodeOfThisMessage($message_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition="id=:id";
                $criteria->params = array(':id'=>$message_id);
                $message= Message::model()->find($criteria);
                return $message['code'];
                
            }
            
            
            
            /**
         * This is the function that replies a chat message
         */
        public function replyingThisChatMessageToThisColleague($message_id,$issue,$col,$message,$code,$user_id,$domain_id,$filename,$content_type,$filesize,$is_group){
            
           $model = new User;
            
            $subject = $this->getTheIssuesAndvaluesForThisMessage($issue);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message',
                                  array(
                                    'from'=>$user_id,
                                    'to'=>$col,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('inbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'to_domain_id'=>$model->getTheDomainOfThisUser($col),
                                    'issues_and_values_id'=>$issue,
                                    'code'=>$code,
                                    'attachment'=>$filename,
                                    'attachment_size'=>$filesize, 
                                    'content_type'=>$content_type,  
                                    'parent_id'=> $message_id, 
                                   'is_message_forwardable'=>0,
                                    'is_group_messaging'=>$is_group,      
                                    'date_sent'=>new CDbExpression('NOW()'),
                                      'date_recieved'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)   
                                  )
			
                        );
                if($result>0){
                    if($this->isSendingInformationalPrivateEmailASuccess($col,$user_id,$domain_id,"$subject")){
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }else{
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }
                    
                }else{
                    return 0;
                }
               
           
        }
        
        
        /**
         * This is the function that writes a chat response message to the sender outbox
         */
        public function writeTheReplyToChatMessageToTheSenderOutbox($message_id,$issue,$message,$code,$buckets,$is_bucket_empty,$user_id,$domain_id,$filename,$content_type,$filesize,$is_group){
            $bucket_model = new MessageHasBuckets;
            $subject = $this->getTheIssuesAndvaluesForThisMessage($issue);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message',
                                  array(
                                    'from'=>$user_id,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('outbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'issues_and_values_id'=>$issue,
                                     'parent_id'=> $message_id,
                                    'code'=>$code,
                                     'attachment'=>$filename,
                                    'attachment_size'=>$filesize, 
                                    'content_type'=>$content_type, 
                                   'is_message_forwardable'=>0,
                                    'is_group_messaging'=>$is_group,      
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                    'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)    
                                  )
			
                        );
                 //write the buckets if any to the outbox   
                if($is_bucket_empty == false){
                    $bucket_model->attachTheAssetsInTheBucket($this->getTheCurrentMessageIDOfThisReceipient("$code"),$buckets);
                }
                
               if($result>0){
                    return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                }else{
                    return 0;
                }
            
        }
        
        /**
         * This is the function that gets the subject of a message
         */
        public function getTheSubjectOfTheOriginalMessage($message_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition="id=:id";
             $criteria->params = array(':id'=>$message_id);
             $message= Message::model()->find($criteria);
            
             return $message['subject'];
        }
        
        
          
        /**
         * This is the function that gets a domain name given its id
         */
        public function getTheDomainNameOfThisMemberDomainId($domain_id){
            $model = new Resourcegroupcategory;
            return $model->getTheDomainNameOfThisDomain($domain_id);
        }
        
        
         /**
         * This is the function that gets a name of a sender
          **/
        public function getTheNameOfThisMember($user_id){
            $model = new User;
            return $model->getTheNameOfThisMember($user_id);
        }
        
        
        /**
         * This is the function that gets the issue and value id of a message
         */
        public function getTheIssueAndValueIdOfThisMessage($message_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition="id=:id";
             $criteria->params = array(':id'=>$message_id);
             $message= Message::model()->find($criteria);
            
             return $message['issues_and_values_id'];
        }
        
        
        
          /**
         * This is the function that moves a filename to its location path
         */
        public function moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type){
            
            if($_FILES['filename']['name'] != ""){
                        $tmpName = $_FILES['filename']['tmp_name'];
                        $iconName = $_FILES['filename']['name'];    
                        $iconType = $_FILES['filename']['type'];
                        $iconSize = $_FILES['filename']['size'];
                  
                        if($iconName !== null) {
                        if($model->id === null){
                           if($filename != null){
                                $iconFileName = time().'_'.$filename;  
                            }else{
                                $iconFileName = $$filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== null){
                            if($content_type == 'document'){
                                $iconPath = Yii::app()->params['documents'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'image'){
                                $iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'audio'){
                                $iconPath = Yii::app()->params['audios'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'video'){
                                $iconPath = Yii::app()->params['videos'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }
                            	
                        }else{
                            $iconFileName = $filename;
                            return $iconFileName;
                        } // validate to save file
                        }
                     }else{
                         $iconFileName = $filename;
                         return $iconFileName;
                     }
                        
                        
                        
                        
                   }else{
                       return null;
                   }
                    
                    
        }
        
        
        /**
         * This is the function that determines if an ssset or file type is acceptable
         */
        public function isFileTypeAndSizeAcceptable(){
           
          if(isset($_FILES['filename']['name'])){
                $tmpName = $_FILES['filename']['tmp_name'];
                $iconFileName = $_FILES['filename']['name'];    
                $iconFileType = $_FILES['filename']['type'];
                $iconFileSize = $_FILES['filename']['size'];
                
            if($iconFileType === 'image/png'){
                return true;
            }else if($iconFileType === 'image/jpg'){
                return true;
            }else if($iconFileType === 'image/jpeg'){
                return true;
                
            }else if($iconFileType === 'application/pdf'){
                return true;
            }else if($iconFileType === 'audio/mp3'){
                return true;
            }else if($iconFileType === 'video/mp4'){
                return true;
            }else{
                return false;
            }
          }else{
              return false;  
          } 
          
           
           
            
        }
        
        
        /**
         * This is the function that effects the removal of a message
         */
        public function isTheRemovalOfThisMessageASuccess($message_id){
            $model = new MessageHasBuckets;
            if($model->isTheMessageBucketsSuccessfullyRemoved($message_id)){
                if($this->isThisMessageSuccessfullyRemoved($message_id)){
                    return true;
                }else{
                    return false;
                }
                    
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that removes a message
         */
        public function isThisMessageSuccessfullyRemoved($message_id){
            $model=Message::model()->findByPk($message_id);
            if($model === null){
                return false;
            }else if($model->delete()){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if a message i on deliberation
         */
        public function isTheMessageOnDeliberation($message_id){
            $model = new MessageDeliberation;
            return $model->isMessageWithDeliberations($message_id);
        }
        
        
        /**
         * This is the function that confirms if a message has an asset
         */
        public function isMessageWithAssets($message_id){
            $model = new MessageHasBuckets;
            return $model-> isMessageWithAssets($message_id);
        }
        
        
        /**
         * This is the function that determines if the removal of assets from message is successful
         */
        public function isRemovalOfAllAssetsFromMessageSuccessful($message_id){
            $model = new MessageHasBuckets;
            return $model->isRemovalOfAllAssetsFromMessageSuccessful($message_id);
        }
}
