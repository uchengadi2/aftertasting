<?php

class StorageDeviceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewStoragedevice','updateStoragedevice','DeleteOneStorageDevice',
                                    'ListPlatformStoragedevices','listDomainStoragedevices'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that adds new storage device to a storage room
         */
        public function actionAddNewStoragedevice(){
            
            $model = new StorageDevice;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->label = $_POST['label'];
            $model->device_number = $_POST['device_number'];
            $model->description = $_POST['description'];
            if(is_numeric($_POST['person_in_charge'])){
                $model->user_in_charge_id = $_POST['person_in_charge'];
            }else{
                $model->user_in_charge_id = $_POST['user_in_charge_id'];
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = $_POST['type'];
            }
            if(isset($_POST['others_name'])){
                $model->others_name = $_POST['others_name'];
            }
            
            if(is_numeric($_POST['storage_room'])){
                $model->room_id = $_POST['storage_room'];
            }else{
                $model->room_id = $_POST['room_id'];
            }
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            $room_name = $this->getTheNameOfThisStorageRoom($model->room_id);
            
            if($model->save()){
               $msg = "Successfully added '$model->label' storage device to this '$room_name' storage room";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->label' storage room could not be added to the '$room_name' storage room";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        
        
        /**
         * This is the function that gets the name of the storage room
         */
        public function getTheNameOfThisStorageRoom($room_id){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$room_id);
             $room = StorageRoom::model()->find($criteria); 
             
             return $room['name'];
            
        }
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        /**
         * This  is the function that gets the name of a domain
         */
        public function getTheNameOfThisDomain($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $domain = Resourcegroupcategory::model()->find($criteria);   
             
             return $domain['name'];
        }
        
        /**
         * This is the function that updates storage device information
         */
        public function actionupdateStoragedevice(){
            
            $_id = $_POST['id'];
            $model=  StorageDevice::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->label = $_POST['label'];
            $model->device_number = $_POST['device_number'];
            $model->description = $_POST['description'];
            if(is_numeric($_POST['person_in_charge'])){
                $model->user_in_charge_id = $_POST['person_in_charge'];
            }else{
                $model->user_in_charge_id = $_POST['user_in_charge_id'];
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = $_POST['type'];
            }
            if(isset($_POST['others_name'])){
                $model->others_name = $_POST['others_name'];
            }
            
            if(is_numeric($_POST['storage_room'])){
                $model->room_id = $_POST['storage_room'];
            }else{
                $model->room_id = $_POST['room_id'];
            }
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
            $room_name = $this->getTheNameOfThisStorageRoom($model->room_id);
            
            if($model->save()){
               $msg = "Successfully updated '$model->label' storage device in this '$room_name' storage room";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->label' storage room could not be updated in the '$room_name' storage room";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        
        /**
         * This is the function that deletes storage device from the platfor
         */
        public function actionDeleteOneStorageDevice(){
            
            $_id = $_POST['id'];
            //get the name of this location
            $device_label = $this->getStorageDeviceLabel($_id);
            $model= StorageDevice::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$device_label' storage device was successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$device_label' storage device could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
            
        }
        
        
        /**
         * This is the function that list all storage device in the platform
         */
        public function actionListPlatformStoragedevices(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
              // $criteria->condition='type!=:type';
              // $criteria->params = array(':type'=>'special_report');
            $devices =  StorageDevice::model()->findAll($criteria);
                 
            if($devices===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "device" => $devices
            
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that list all storage device in a domain
         */
        public function actionlistDomainStoragedevices(){
            
           $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid';
           $criteria->params = array(':domainid'=>$domain_id);
           $devices =  StorageDevice::model()->findAll($criteria);
                 
           if($devices===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "device" => $devices
            
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves a storage device label
         */
        public function getStorageDeviceLabel($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $device = StorageDevice::model()->find($criteria);   
             
             return $device['label'];
            
            
        }
}
