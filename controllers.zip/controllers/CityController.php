<?php

class CityController extends Controller
{
	
        private $_id;
        /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','ListAllTheStateCities'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'ListAllTheStateCities','ListAllTheCitiesInState','ListStateForCity',
                                    'ListAllTheCitiesInState'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','DeleteOneCity'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new City;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $model->name = $_POST['name'];
                $model->state_id = $_POST['state_id'];
                /** if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                 * 
                 */
                 if(isset($_POST['zip_code'])){
                   $model->zip_code = $_POST['zip_code']; 
                }
                $model->create_time = new CDbExpression('NOW()');
                //$model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New City Successfully Created';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Creation on a new city was unsuccessful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate()
	{
            
            //get the state id
            $state = $_POST['state_id'];
          
            
            $_id = $_POST['id'];
            $model=City::model()->findByPk($_id);
            $model->name = $_POST['name'];
             $model->state_id = $state;
            
            /** if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
             * 
             */
              if(isset($_POST['zip_code'])){
                   $model->zip_code = $_POST['zip_code']; 
                }
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
            if($model->save()){
                        //$data['success'] = 'true';
                        $msg = 'Update of this city information was successful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                    //$data['success'] = 'false';
                    $msg = 'Update of this city information was not successful';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                }
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneCity()
	{
		$_id = $_POST['id'];
            $model=City::model()->findByPk($_id);
            
            //get the name of this city
            $city_name = $this->getTheNameOfThisCity($_id);
            
            //get the name of the state/province where the city is located
            $state_name = $this->getTheStateName($_id);
            
            //get the  country of this city
            $country_name = $this->getTheCountryName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$city_name' city is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}

        /**
         * This is the function that gets the city name given its id
         */
        public function getTheNameOfThisCity($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $city = City::model()->find($criteria); 
            
            return $city['name'];
            
        }
        
        /**
         * This is the function that gets the state name
         */
        public function getTheStateName($city_id){
            //get the state id of this city
            $state_id = $this->getTheStateIdOfThisCity($city_id);
            
            //get the state name of this state
            $state_name = $this->getTheStateNameGivenItsId($state_id);
            
            return $state_name;
        }
        
        /**
         * This is the function that gets the state id of a city
         */
        public function getTheStateIdOfThisCity($city_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$city_id);
            $city = City::model()->find($criteria); 
            
            return $city['state_id'];
        }
        
        
        /**
         * This is the function that gets the name of a state
         */
        public function getTheStateNameGivenItsId($state_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$state_id);
            $state = State::model()->find($criteria); 
            
            return $state['name'];
        }
        
        /**
         * This is the function that gets the country name of a city
         */
        public function getTheCountryName($city_id){
            //get the state id of this city
            $state_id = $this->getTheStateIdOfThisCity($city_id);
            
            //get the country id of this state
            $country_id = $this->getCountryIdOfThisState($state_id);
            
            //get the name this country
            $country_name = $this->getTheCountryNameGivenItsId($country_id);
            
            return $country_name;
            
        }
        
        /**
         * This is the function that gets the country id of a state  
         */
        public function getCountryIdOfThisState($state_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$state_id);
            $state = State::model()->find($criteria); 
            
            return $state['country_id'];
            
        }
        
        
        /**
         * This is the function that gets the country name of a country given its id
         */
        public function getTheCountryNameGivenItsId($country_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$country_id);
            $country = Country::model()->find($criteria); 
            
            return $country['name'];
        }
        
	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('City');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new City('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['City']))
			$model->attributes=$_GET['City'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}
        
        
        /**
	 * Manages all models.
	 */
	public function actionListAllTheStateCities()
	{
		$city = City::model()->findAll();
                if($city===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"assigned" => $assigned,
                            "city" => $city)
                       );
                       
                }
	}
        
        /**
	 * List all the cities that belong to a particular state
	 */
	public function actionListAllTheCitiesInState()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='state_id=:id';
                $criteria->params = array(':id'=>$_id);
                $city= City::model()->findAll($criteria);
                if($city===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "city" => $city,
                                   
                    
                            ));
                       
                }
	}
        
        
         /**
	 * get a country name  given a country id
	 */
	public function actionListStateForCity()
	{
            $model = new Country;
             $state_id = $_REQUEST['state_id'];
             //$_id = 1;
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,country_id';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$state_id);
             $state = State::model()->find($criteria);  
             
             $country = $model->getTheNameOfThisCountry($state['country_id']);
             
             
               
                if($state===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "state" => $state,
                           "country"=>$country
                           )
                       );
                       
                } 
               
               
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return City the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=City::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param City $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='city-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
