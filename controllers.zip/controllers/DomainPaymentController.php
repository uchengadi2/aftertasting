<?php

class DomainPaymentController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','generatingpaymentadvicefordomains','ListAllPendingPayments','ListAllConfirmedPayments',
                                    'ListAllPartialPayments','ListAllDisputedPayments','paymentextrainfo','confirmingthispayment','confirmingthispartialpayment',
                                    'confirmingdisputedpaymentstatus','ListAllDomainPendingPayments','initiatingpaymentconfirmation','getbankerdetails',
                                    'ListAllDomainHistoryPayments'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that generates payment advice for all domains
         */
        public function actiongeneratingpaymentadvicefordomains(){
            
            $model = new DomainPayment;
            
            $error_count = 0;
            
            
            
            
        if($this->haveAllValidInvoicesProcessed()){
                
                //get all the domains
            $domains = $this->getAllTheDomains();
            
            foreach($domains as $domain){
                if($model->isTheGenerationOfThisDomainPaymentAdviceASuccess($domain)== false){
                    $error_count = $error_count + 1;
                }else if($this->isTheEndingOfdomainTransactionTreeASuccess($domain)){
                   continue;
                }
            }
            
            if($error_count==0){
                if($this->isTheZerorizationOfTheBillTableASuccess()){
                   header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The payment advice generation for all domains where successful"
                               )
                       );
                    
                }else{
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The payment advice generation for all domains where successful but the bills table could not be zerorised"
                               )
                       );
                    
                }
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The payment advice generation for '$error_count' domains where not successful"
                               )
                       );
            }
                
            }else{
                
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "some valid invoices are still awiting processing therefore this generation cannot commence."
                               )
                       );
                
            }
            
            
        }
        
        
        /**
         * This is the function that retrieves all domains
         */
        public function getAllTheDomains(){
            $model = new Resourcegroupcategory;
            return $model->retrieveAllDomains();
        }
        
        
        /**
         * This is the function that zeroroses the billing table
         */
        public function isTheZerorizationOfTheBillTableASuccess(){
            $model = new Billing;
            return $model->isTheZerorizationOfTheBillTableASuccess();
        }
        
        
        
        /**
         * This is the function that comfirms if all valid invoices had been processed
         */
        public function haveAllValidInvoicesProcessed(){
            $model = new Invoice;
            
            return $model->haveAllValidInvoicesProcessed();
        }
        
        
        /**
         * This is the function that list all pending payments
         */
        public function actionListAllPendingPayments(){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='status=:status';
            $criteria1->params = array(':status'=>"pending");
            $payments= DomainPayment::model()->findAll($criteria1);
            
            if($payments===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "payment" => $payments,
                           
                           
                           
                          
                       ));
                       
                }
        }
        
        
         /**
         * This is the function that list all confirmed and paid  payments
         */
        public function actionListAllConfirmedPayments(){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='status=:status and is_payment_confirmed=:confirmed';
            $criteria1->params = array(':status'=>"paid",':confirmed'=>1);
            $payments= DomainPayment::model()->findAll($criteria1);
            
            if($payments===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "payment" => $payments,
                           
                           
                           
                          
                       ));
                       
                }
        }
        
        
        
         /**
         * This is the function that list all confirmed and partially made payments
         */
        public function actionListAllPartialPayments(){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='status=:status and is_payment_confirmed=:confirmed';
            $criteria1->params = array(':status'=>"partially_paid",':confirmed'=>1);
            $payments= DomainPayment::model()->findAll($criteria1);
            
            if($payments===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "payment" => $payments,
                           
                           
                           
                          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that list all confirmed payments that are on dispute
         */
        public function actionListAllDisputedPayments(){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='status=:status and is_payment_confirmed=:confirmed';
            $criteria1->params = array(':status'=>"on_dispute",':confirmed'=>1);
            $payments= DomainPayment::model()->findAll($criteria1);
            
            if($payments===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "payment" => $payments,
                           
                    
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves some exta information about payment
         */
        public function actionpaymentextrainfo(){
            
            $id = $_REQUEST['id'];
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$id);
            $payment= DomainPayment::model()->find($criteria1);
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$payment['bank_id']);
            $bank= Banker::model()->find($criteria1);
            
            //get the name of the person that confirmed this payment
            $confirmed_by = $this->paymentConfirmedBy($payment['confirmed_by']);
            
            $domainname = $this->getThisDomainName($payment['owner_domain_id']);
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "domainname" => $domainname,
                           "confirmed_by"=>$confirmed_by,
                           "bank"=>$bank
                           
                    
                       ));
            
            
        }
        
        
        /**
         * This is the function that gets a domain name
         */
        public function getThisDomainName($owner_domain_id){
            $model = new Resourcegroupcategory;
            return $model->getTheDomainNameOfThisDomain($owner_domain_id);
        }
        
        
        /**
         * This is the function that confirms payments and status
         */
        public function actionconfirmingthispayment(){
            $model = new DomainPayment;
            $id = $_REQUEST['id'];
            $status = $_REQUEST['confirmed_status'];
            $total_amount_confirmed = $_REQUEST['total_amount_confirmed'];
            
            if($model->isPaymentConfirmationASuccess($id,$status,$total_amount_confirmed)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "This payment is successfully confirmed",
                           
                    
                       ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"The confirmation of this payment was not successful. Please contact customer service for assistance",
                           
                    
                       ));
            }
            
            
        }
        
        
        /**
         * This is the function that gets the name of the person that confirms a payment
         */
        public function paymentConfirmedBy($confirmed_by){
            $model = new User;
            return $model->paymentConfirmedBy($confirmed_by);
            
        }
        
        
        /**
         * This is the function that will confirm a partial payment additional pay
         */
        public function actionconfirmingthispartialpayment(){
            $model = new DomainPayment;
            
            $id = $_REQUEST['id'];
            $status = $_REQUEST['confirmed_status'];
            if(isset($_REQUEST['addiional_amount_paid'])){
                $addional_amount_confirmed = $_REQUEST['addiional_amount_paid'];
            }else{
                $addional_amount_confirmed = 0;
            }
            
            $paid_amount = $_REQUEST['total_amount_confirmed'];
            $total_amount_confirmed = $addional_amount_confirmed + $paid_amount;
            
            if($model->isThisPartialPaymentConfirmationASuccess($id,$status,$total_amount_confirmed)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "This payment is successfully confirmed",
                           
                    
                       ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"The confirmation of this payment was not successful. Please contact customer service for assistance",
                           
                    
                       ));
            }
            
            
        }
        
        
        /**
         * This is the function that confirm disputed payment status
         */
        public function actionconfirmingdisputedpaymentstatus(){
            
            $model = new DomainPayment;
            
            $id = $_REQUEST['id'];
            $status = $_REQUEST['confirmed_status'];
                       
            if($model->isThisDisputedPaymentNewStatusEffected($id,$status)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The new status of this disputed payment is successfully confirmed",
                           
                    
                       ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"The confirmation of this disputed payment was not successful. Please contact customer service for assistance",
                           
                    
                       ));
            }
            
        }
        
        
           
        /**
         * This is the function that list all domain pending payments
         */
        public function actionListAllDomainPendingPayments(){
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='status!=:status and owner_domain_id=:domainid';
            $criteria1->params = array(':status'=>"paid",':domainid'=>$domain_id);
            $payments= DomainPayment::model()->findAll($criteria1);
            
            if($payments===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "payment" => $payments,
                           
                           
                           
                          
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that initiates customers payment confirmation
         */
        public function actioninitiatingpaymentconfirmation(){
            $model = new DomainPayment;
            $payment_id = $_REQUEST['id'];
            $bank_id = $_REQUEST['bank'];
          
            if($model->isTheInitiationOfThisPaymentConfirmationASuccess($payment_id,$bank_id)){
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Thank you for the payment. We will confirm and get back to you shortly",
                           
                    
                       ));
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"There was an issue while trying to initiate this payment confirmation request. Please contact customer service for assistance",
                           
                    
                       ));
            }
            
            
        }
        
        
        /**
         * This is the function that retrieves some bank details
         */
        public function actiongetbankerdetails(){
            
            $bank_id = $_REQUEST['bank_id'];
            
            if($bank_id != null){
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='id=:id';
                 $criteria1->params = array(':id'=>$bank_id);
                 $bank= Banker::model()->find($criteria1);
            
             if($bank===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "bank" => $bank,
                           
                           
                           
                          
                       ));
                       
                }
            
                
            }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "bank" =>null,
                           
                           
                           
                          
                       ));
                       
            }
            
           
        }
        
        
         /**
             * This is the function that ends domain transaction tree
             */
            public function isTheEndingOfdomainTransactionTreeASuccess($domain){
                $model = new DomainTransactions;
                return $model->isTheEndingOfdomainTransactionTreeASuccess($domain);
            }
             
            
            
            /**
         * This is the function that list all domain history payments
         */
        public function actionListAllDomainHistoryPayments(){
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='status=:status and owner_domain_id=:domainid';
            $criteria1->params = array(':status'=>"paid",':domainid'=>$domain_id);
            $payments= DomainPayment::model()->findAll($criteria1);
            
            if($payments===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "payment" => $payments,
                           
                           
                           
                          
                       ));
                       
                }
            
            
        }
}
