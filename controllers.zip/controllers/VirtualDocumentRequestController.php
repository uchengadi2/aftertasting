<?php

class VirtualDocumentRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddRequestForThisVirtualDocument','ModifyRequestForThisVirtualDocument','RemoveThisVitualDocumentAtRequest',
                                    'Tester'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the functin tht add virtual batch request at request
         */
        public function actionAddRequestForThisVirtualDocument(){
            
            $model=new VirtualDocumentRequest;
            
           $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $model->virtual_document_id = $_POST['virtual_document_id'];
            $model->virtual_batch_id = $_POST['virtual_batch_id'];
            $model->virtual_box_id = $_POST['virtual_box_id'];
            $model->virtual_maximum_requesting_period_in_days = $_POST['virtual_maximum_requesting_period_in_days']; 
            $model->virtual_requesting_domain_id = $domain_id;
            $model->status = strtolower($_POST['status']);
           $model->virtual_requesting_user_id = $user_id;
           if(isset($_POST['virtual_group'])){
               $model->virtual_requesting_group_id = $_POST['virtual_group'];
               $model->virtual_is_group_request = 1;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 0;
           }else if(isset($_POST['virtual_subgroup'])){
               $model->virtual_requesting_subgroup_id = $_POST['virtual_subgroup'];
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 1;
               $model->virtual_is_single_user_request = 0;
           }else{
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 1;
           }
           $model->virtual_request_initiation_date = new CDbExpression('NOW()');
           $model->virtual_request_initiated_by = Yii::app()->user->id;
           $model->virtual_is_request_initiated = 1;
           if(isset($_POST['virtual_is_electronic_instrument_request_included'])){
                    $model->virtual_is_electronic_instrument_request_included = $_POST['virtual_is_electronic_instrument_request_included'];
                }else{
                    $model->virtual_is_electronic_instrument_request_included = 0;
                }
              if(isset($_POST['virtual_include_supporting_instrument'])){
                    $model->virtual_include_supporting_instrument = $_POST['virtual_include_supporting_instrument'];
                }else{
                    $model->virtual_include_supporting_instrument = 0;
                }  
           
           $document_name = $this->getThisDocumentName($model->virtual_document_id);
           
            if($this->isThisRequestInConformityWithPolicy($domain_id)){
                
                if($this->thereIsNoPendingRequestOfThisDocumentByThisUser($model->virtual_document_id,$model->virtual_request_initiated_by,$model->status)){
                     //initiate the request for this batch
                    if($model->save()){
                        
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request for virtual '$document_name' document  is successfully initiated"
                        ));
                    }else{
                         header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Request for the virtual '$document_name' document could not be initiated. Probably a validation error"
                        ));
                        
                    }
                    
                    
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Request for the virtual '$document_name' document could not be completed.There is an open request of same document that is awaiting activation"
                        ));
                }
                
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Your domain policy bars you from requesting for the '$document_name' document. Please contact your domain administrator"
                        ));
            }
            
            
        }
        
        
          /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
          /**
         * This is the function that gets a batch & file title
         */
        public function getThisDocumentName($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $document = Resources::model()->find($criteria); 
             
             return $document['name'];
            
        }
        
        
         /**
      * This is the function that determines if there is a pending request of this document by this user
      */
     public function thereIsNoPendingRequestOfThisDocumentByThisUser($document_id,$request_initiated_by, $status){
         if($this->hasThisUserMadeThisDocumentRequestBefore($document_id,$request_initiated_by,$status)){
             if($this->isThereAnyOpenRequestOfThisDocumentByThisUser($document_id,$request_initiated_by,$status)){
                 return false;
             }else{
                 return true;
             }
             
         }else{
             return true;
         }
         
     }
        
        
        /**
      * This is the function that determines if this user had made a similar request before
      */
     public function hasThisUserMadeThisDocumentRequestBefore($document_id,$request_initiated_by, $status){
         
          $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('virtual_document_request')
                    ->where("virtual_document_id = $document_id && virtual_request_initiated_by=$request_initiated_by");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
     /**
      * This is the function that determines if there is any open request of this document by this user
      */
     public function isThereAnyOpenRequestOfThisDocumentByThisUser($document_id,$request_initiated_by,$status){
         
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('virtual_document_request')
                    ->where("(virtual_document_id = $document_id && virtual_request_initiated_by=$request_initiated_by) &&(virtual_is_requested=0 && status='inactive')");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
         
     }
     
       /**
     * This is the function that determines if a document request is in conformity with the prevailing domain policy
     */
     public function isThisRequestInConformityWithPolicy($domain_id){
         
         return true;
     }
     
     
     /**
      * This is the function that modifies a virtual batch request
      */
     public function actionModifyRequestForThisVirtualDocument(){
         
         $id = $_POST['virtual_id'];
          $model=VirtualDocumentRequest::model()->findByPk($id);
          
          if($_POST['virtual_id'] != "" || $_POST['virtual_id'] != 0){
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $model->virtual_document_id = $_POST['virtual_document_id'];
            $model->virtual_batch_id = $_POST['virtual_batch_id'];
            $model->virtual_box_id = $_POST['virtual_box_id'];
            $model->virtual_maximum_requesting_period_in_days = $_POST['virtual_maximum_requesting_period_in_days']; 
            $model->virtual_requesting_domain_id = $domain_id;
            $model->status = strtolower($_POST['status']);
           $model->virtual_requesting_user_id = $user_id;
           if(isset($_POST['virtual_group'])){
               $model->virtual_requesting_group_id = $_POST['virtual_group'];
               $model->virtual_is_group_request = 1;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 0;
           }else if(isset($_POST['virtual_subgroup'])){
               $model->virtual_requesting_subgroup_id = $_POST['virtual_subgroup'];
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 1;
               $model->virtual_is_single_user_request = 0;
           }else{
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 1;
           }
           $model->virtual_request_initiation_date = new CDbExpression('NOW()');
           $model->virtual_request_initiated_by = Yii::app()->user->id;
           $model->virtual_is_request_initiated = 1;
           if(isset($_POST['virtual_is_electronic_instrument_request_included'])){
                    $model->virtual_is_electronic_instrument_request_included = $_POST['virtual_is_electronic_instrument_request_included'];
                }else{
                    $model->virtual_is_electronic_instrument_request_included = 0;
                }
            if(isset($_POST['virtual_include_supporting_instrument'])){
                    $model->virtual_include_supporting_instrument = $_POST['virtual_include_supporting_instrument'];
                }else{
                    $model->virtual_include_supporting_instrument = 0;
                }  
           $document_name = $this->getThisDocumentName($model->virtual_document_id);
           
           if($this->isThisRequestInConformityWithPolicy($domain_id)){
                  //modify this request for this batch
                    if($model->save()){
                        
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request for virtual '$document_name' document  is successfully modified"
                        ));
                    }else{
                         header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Request for the virtual '$document_name' document could not be modified. Probably a validation error"
                        ));
                        
                    }
                    
               
               
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Your domain policy bars you from requesting for the modification of  virtual '$document_name' document. Please contact your domain administrator"
                        ));
            }
              
          }else{
              $document_name = $this->getThisDocumentName($_POST['virtual_document_id']);
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "You do not have an open request of virtual '$document_name' document."
                        ));
          }
          
         
         
     }
     
     
      /**
         * This is the function that gets the id of a virtual id request
         */
        public function getTheIdOfThisVirtualDocumentOnRequest($document_id, $user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(virtual_document_id=:doc and virtual_requesting_user_id=:userid) and (status=:status and virtual_is_requested=:requested)';
             $criteria6->params = array(':doc'=>$document_id,':userid'=>$user_id,':status'=>"inactive",':requested'=>false);
             $holder = VirtualDocumentRequest::model()->find($criteria6);  
             
             if($holder['id'] == 0 || $holder['id'] == null ){
                return 0;
            }else{
                return $holder['id'];
            }
            
        }
     
        
        
     
    /**
     * This is the function that removes virtual documents from the request list
     */
     public function actionRemoveThisVitualDocumentAtRequest(){
         
         $document_id = $_REQUEST['document_id'];
        //get the id of the physical request
         $user_id = Yii::app()->user->id;
         $id = $this->getTheIdOfThisVirtualDocumentOnRequest($document_id,$user_id);
         
         $document_name = $this->getThisDocumentName( $document_id);
         
          $cmd =Yii::app()->db->createCommand();  
          $result = $cmd->delete('virtual_document_request', 'id=:id', array(':id'=>$id));
            
           if($result>0){
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"The '$document_name' virtual document had successfully been removed from the request list",
                       ));
           }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Could not remove The '$document_name' virtual document from the request list. Document probably not in the Request List",
                       ));
           }
         
         
     }
     
     
     /**
      * Testing function
      */
     public function actionTester(){
         
        $virtual_id = $this->getTheIdOfThisVirtualDocumentOnRequest($document_id=5, $user_id=1);
        
         header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "virtual_id" =>$virtual_id,
                       ));
         
         
         
     }
}
