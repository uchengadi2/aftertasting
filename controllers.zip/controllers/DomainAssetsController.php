<?php

class DomainAssetsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addNewDomainResourceAsset','DeleteThisDomainAssets','updateDomainResourceAsset',
                                    'retrieveDomainAssetResources','retrieveallassetsinthisbucket'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that adds new domain resource asset
         */
        public function actionaddNewDomainResourceAsset(){
            
            $model=new DomainAssets;

		$user_id = Yii::app()->user->id;
                
                $domain_id = $this->determineAUserDomainId($user_id);
                
                $model->name = $_POST['name'];
                $model->domain_id = $domain_id;
                $model->description = $_POST['description'];
                if($_POST['is_url'] == "url"){
                    $model->is_url = 1;
                  if(isset($_POST['url'])){
                    $model->url = strtolower($_POST['url']);
                    }
               }
               $model->type = strtolower($_POST['type']);
               $model->date_created = new CDbExpression('NOW()');
                $file_error_counter = 0;
                if($_POST['is_url'] == "file"){
                    $model->url = null;
                    $model->is_url = 0;
                   
                    if($_FILES['filename']['name'] != ""){
                        if($this->isFileTypeLegal($model->type)){
                        
                            $filename = $_FILES['filename']['name'];
                            $filesize = $_FILES['filename']['size'];
                        
                        }else{
                       
                            $file_error_counter = $file_error_counter + 1;
                         
                        }//end of the determine size and type statement
                    }else{
                        $filename = null;     
                        $filesize = 0;
             
                    }//end of the if icon is empty statement
                    
                    
                    
                }//end
                
                 if($this->isDomainWithAvailableSpace($domain_id,$filesize)){
                    if($file_error_counter ==0){
                    
                        if($model->validate()){
                           $model->filename = $this->moveTheFileToItsPathAndReturnTheFileName($model,$filename,$domain_id);
                           $model->filesize = $filesize;
                           
                            if($model->save()) {
                        
                                // $result['success'] = 'true';
                                $msg = 'New Resource Asset Created Successfully';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                                );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                     }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validaion Error: Check your file fields for correctness";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($file_error_counter > 0){
                        //get the platform assigned icon width and height
                           $msg = "Please check your file type for correctness";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
                        
                        
                    }else{
                         $msg = "Your domain does not have the available storage space for this asset. Request for additional storage space and try again";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                        
                    }
                
                
                
                
                
                
            
        }
        
        
         /**
         * This is the function that updates domain assets
         */
        public function actionupdateDomainResourceAsset(){
            
         $user_id = Yii::app()->user->id;
                
          $domain_id = $this->determineAUserDomainId($user_id);
            
            $_id = $_POST['id'];
            
            $model= DomainAssets::model()->findByPk($_id);
            
            $model->name = $_POST['name'];
                $model->domain_id = $domain_id;
                $model->description = $_POST['description'];
                
              if($_POST['is_url'] == "url"){
                    $model->is_url = 1;
                  if(isset($_POST['url'])){
                    $model->url = strtolower($_POST['url']);
                    }
               }
               
               $model->type = strtolower($_POST['type']);
                $model->date_updated = new CDbExpression('NOW()');
                  $file_error_counter = 0;
                if($_POST['is_url'] == "file"){
                    $model->url = null;
                    $model->is_url = 0;
                   
                    if($_FILES['filename']['name'] != ""){
                        if($this->isFileTypeLegal($model->type)){
                        
                            $filename = $_FILES['filename']['name'];
                            $filesize = $_FILES['filename']['size'];
                        
                        }else{
                       
                            $file_error_counter = $file_error_counter + 1;
                         
                        }//end of the determine size and type statement
                    }else{
                        $filename = $model->retrieveThePreviousFileame($_id);
                        $filesize = $model->retrieveThePreviousFilesize($_id);
             
                    }//end of the if icon is empty statement
                    
                    
                    
                }//end
                
                 if($this->isDomainWithAvailableSpace($domain_id,$filesize)){
                    if($file_error_counter ==0){
                    
                        if($model->validate()){
                           $model->filename = $this->moveTheFileToItsPathAndReturnTheFileName($model,$filename,$domain_id);
                           $model->filesize = $filesize;
                           
                            if($model->save()) {
                        
                                // $result['success'] = 'true';
                                $msg = 'New Resource Asset Created Successfully';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                                );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                     }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validaion Error: Check your file fields for correctness";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($file_error_counter > 0){
                        //get the platform assigned icon width and height
                           $msg = "Please check your file type for correctness";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
                        
                        
                    }else{
                         $msg = "Your domain does not have the available storage space for this asset. Request for additional storage space and try again";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                        
                    }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all domain assets for d domain
         */
        public function actionretrieveDomainAssetResources(){
            
           $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainId($user_id);
           
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid';
           $criteria->params = array(':domainid'=>$domain_id);
           $criteria->order = 'name';
           $assets = DomainAssets::model()->findAll($criteria);
                 
           if($assets===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "assets" => $assets
            
                       ));
                       
                }
           
           
            
        }
        
        
        
         /**
         * This is the function that deletes domain asset for a domain
         */
        public function actionDeleteThisDomainAssets(){
            
            $_id = $_POST['id'];
            //get the name of this domain asset
            $asset = $this->getThisDomainAssetName($_id);
            $model= DomainAssets::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$asset' domain asset was Successfully Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$asset' domain asset was Not Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
            
        }
        
        
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainId($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
         /**
         * This is the function that gets the name of a domain asset
         */
        public function getThisDomainAssetName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $asset = DomainAssets::model()->find($criteria);   
            
            return $asset['name'];
        }
	
        
        /**
         * This is the function that determines the type  file
         */
        public function isFileTypeLegal($type){
            
           $size = []; 
            if(isset($_FILES['icon']['name'])){
                $tmpName = $_FILES['filename']['tmp_name'];
                $fileName = $_FILES['filename']['name'];    
                $fileType = $_FILES['filename']['type'];
                $fileSize = $_FILES['filename']['size'];
            } 
                   
            if($type == 'document'){
                if($fileType =='application/pdf'){
                    return true;
                }else{
                    return false;
                }
                
            }else if($type == 'image'){
                if($fileType == 'image/png'){
                    return true;
                }else if($fileType == 'image/jpg'){
                    return true;
                }else{
                    return false;
                }
            }else if($type == 'audio'){
                if($fileType == 'audio/mp3'){
                    return true;
                }else{
                    return false;
                }
            }else if($type == 'video'){
                 if($fileType == 'video/mp4'){
                    return true;
                }else{
                    return false;
                }
            }
            
          
        }
        
        
        	/**
         * This is the function that moves file to its directory
         */
        public function moveTheFileToItsPathAndReturnTheFileName($model,$filename,$domain_id){
            
            if(isset($_FILES['filename']['name'])){
                        $tmpName = $_FILES['filename']['tmp_name'];
                        $assetName = $_FILES['filename']['name'];    
                        $assetType = $_FILES['filename']['type'];
                        $assetSize = $_FILES['filename']['size'];
                  
                   }
                    
                   //get the domain parameters
                   $domain_country = $this->getTheCountryOfThisDomain($domain_id);
                   $domain_reg_number = $this->getTheRegistrationNumberOfThisDomain($domain_id);
                   
                    if($assetName !== null) {
                       if($model->id === null){
                            if($filename !== null){
                                $assetFile = $domain_country.'_'.$domain_reg_number.'_'.time().'_'.$filename;  
                            }else{
                                $assetFile = $filename;  
                            }   
                          
                           // upload the icon file
                        if($assetName !== null){
                            	$assetPath = Yii::app()->params['assets'].$assetFile;
				move_uploaded_file($tmpName,  $assetPath);
                                        
                        
                                return $assetFile;
                        }else{
                            $assetFile = $filename;
                            return $assetFile;
                        } // validate to save file
                     }else{
                            if($this->noNewIconFileProvided($model->id,$filename)){
                                $assetFile = $filename; 
                                return $assetFile;
                            }else{
                              if($filename != null){ 
                                
                                  if($this->removeTheExistingFile($model->id)){
                                  $assetFile = $domain_country.'_'.$domain_reg_number.'_'.time().'_'.$filename;
                                 //$assetFile = time().$icon_filename;  
                                   $assetPath = Yii::app()->params['assets'].$assetFile;
                                   move_uploaded_file($tmpName,$assetPath);
                                   return $assetFile;
                                                              
                             }
                            }
                                
                                
                            }
                            
                                                                       
                            
                        }
                      
                     }else{
                         $assetFile = $filename;
                         return $assetFile;
                     }
					
                       
                               
        }
        
        
        /**
         * This is the function that determines if a domain has an available space
         * 
         */
        public function isDomainWithAvailableSpace($domain_id,$filesize){
            $model = new Resourcegroupcategory;
            return $model->isDomainWithAvailableSpace($domain_id,$filesize);
        }
      
        /**
         * This is the function that retrieves the country of a domain 
         */
        public function getTheCountryOfThisDomain($domain_id){
            $model = new Resourcegroupcategory;
            return $model->getTheCountryOfThisDomain($domain_id);
        }
        
        /**
         * This is the function that retrieves the registration number of a domain
         */
        public function getTheRegistrationNumberOfThisDomain($domain_id){
            $model = new Resourcegroupcategory;
            return $model->getTheRegistrationNumberOfThisDomain($domain_id);
        }
        
        /**
          * This is the function to ascertain if a new file was provided or not
         */
        public function noNewIconFileProvided($id,$filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $file= DomainAssets::model()->find($criteria);
                
                if($file['filename']==$filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
      /**
         * This is the function that removes an existing file
         */
        public function removeTheExistingFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheFileNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $file= DomainAssets::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               $directoryPath = "c:\\xampp\htdocs\appspace_assets\\assets\\";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$file['filename'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
      
        }
        
        
         /**
         * This is the function that determines if  an asset is the default
         */
        public function isTheFileNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $file= DomainAssets::model()->find($criteria);
                
                if($file['filename'] == null){
                    return false;
                }else{
                    return true;
                }
        }
        
        
        /**
         * This is the function that retrieves all assets for a bucket
         */
        public function actionretrieveallassetsinthisbucket(){
            
            $model = new BucketHasAssets();
            $bucket_id = $_REQUEST['bucket_id'];
            
            //get all the assets for this bucket
            $bucket_assets = $model->retrieveAllAssetsForThisBucket($bucket_id);
            
            $target = [];
            foreach($bucket_assets as $buck){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$buck);
                $asset = DomainAssets::model()->find($criteria); 
                
                $target[] = $asset;
            }
            
            
             if($bucket_assets===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "asset" => $target,
                                  
                                   
                    
                            ));
                       
                         }
            
        }
}
