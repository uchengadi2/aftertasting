<?php

class PhysicalBoxRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllOtherDomainBoxRequest','listAllOwnDomainBoxRequest',
                                    'listAllrequestforownboxesbyotherdomain','getTheBoxDetailRequest','RejectThisOwnPhysicalBoxRequest',
                                    'AcceptThisOwnPhysicalBoxRequest','CancelThisPhysicalBoxRequest','getTheBoxDetailAtConsumption',
                                    'RequestForThisPhysicalBox','CancelThisPhysicalBoxRequestAtConsumption','getTheBoxDetailAtRequest',
                                    'ModifyRequestForThisPhysicalBox','RemoveRequestItemFromThisPhysicalBox'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all own domain box and folder request by domain
         */
        public function actionlistAllOwnDomainBoxRequest(){
            
            $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='requesting_domain_id=:domainid and ((is_requested=:requested and is_sent =:sent) and is_request_cancelled=:cancelled)';
           $criteria->params = array(':domainid'=>$domain_id,':requested'=>false,':sent'=>false,':cancelled'=>false);
           $boxes = PhysicalBoxRequest::model()->findAll($criteria);
           
           $all_own_boxes = [];
           foreach($boxes as $box){
               if($this->isBoxOwnByThisDomain($box['box_id'],$domain_id)){
                   $all_own_boxes[] = $box['id'];
                   
                 }
           }
           
           $domain_boxes = [];
           
           foreach($all_own_boxes as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalBoxRequest::model()->find($criteria);
               
                $domain_boxes[] =  $own_doc;
           }
                 
           if($boxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box" => $domain_boxes
                        ));
                       
                }
            
        }
        
        /**
         * This is the function that list all other domain box request made by this domain 
         */
        public function actionlistAllOtherDomainBoxRequest(){
            
           $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='requesting_domain_id=:domainid and ((is_requested=:requested and is_sent =:sent) and is_request_cancelled=:cancelled)';
           $criteria->params = array(':domainid'=>$domain_id,':requested'=>false,':sent'=>false,':cancelled'=>false);
           $boxes = PhysicalBoxRequest::model()->findAll($criteria);
           
           $all_own_boxes = [];
           foreach($boxes as $box){
               if($this->isBoxOwnByThisDomain($box['box_id'],$domain_id)== false){
                   $all_own_boxes[] = $box['id'];
                   
                 }
           }
           
           $domain_boxes = [];
           
           foreach($all_own_boxes as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalBoxRequest::model()->find($criteria);
               
                $domain_boxes[] =  $own_doc;
           }
                 
           if($boxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box" => $domain_boxes
                        ));
                       
                }
        
        }
        
        
        /**
         * This is the function that list all own domain box and folder request made by other domains
         */
        public function actionlistAllrequestforownboxesbyotherdomain(){
            
            
           $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='requesting_domain_id!=:domainid and ((is_requested=:requested and is_sent =:sent) and is_request_cancelled=:cancelled)';
           $criteria->params = array(':domainid'=>$domain_id,':requested'=>false,':sent'=>false,':cancelled'=>false);
           $boxes = PhysicalBoxRequest::model()->findAll($criteria);
           
           $all_own_boxes = [];
           foreach($boxes as $box){
               if($this->isBoxOwnByThisDomain($box['box_id'],$domain_id)){
                   $all_own_boxes[] = $box['id'];
                   
                 }
           }
           
           $domain_boxes = [];
           
           foreach($all_own_boxes as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalBoxRequest::model()->find($criteria);
               
                $domain_boxes[] =  $own_doc;
           }
                 
           if($boxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box" => $domain_boxes
                        ));
                       
                }
            
            
        }
        
        
         /**
         * This is the function that deternines if a batch belongs to a domain
         */
       public function isBoxOwnByThisDomain($id,$domain_id){
           
           $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("id = $id && domain_id =$domain_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
       }
       
       
             
         /**
         * This is the function that retrieves details of a particular box & folder
         */
        public function actiongetTheBoxDetailRequest(){
            
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
                       
                      
             //get the box name
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$box_id);
             $box = Resourcegroup::model()->find($criteria2);  
             
                       
             //get the storage location
             $criteria5 = new CDbCriteria();
             $criteria5->select = '*';
             $criteria5->condition='id=:id';
             $criteria5->params = array(':id'=>$id);
             $request = PhysicalBoxRequest::model()->find($criteria5);  
             
             //get the  user id of the document holder
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id';
             $criteria6->params = array(':id'=>$request['requesting_group_id']);
             $requestinggroup = Group::model()->find($criteria6); 
             
             
             //get the  user id of the document holder
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id';
             $criteria6->params = array(':id'=>$request['requesting_subgroup_id']);
             $requestingsubgroup = SubGroup::model()->find($criteria6);  
             
             //get the name of this user
             $criteria7 = new CDbCriteria();
             $criteria7->select = '*';
             $criteria7->condition='id=:id';
             $criteria7->params = array(':id'=>$request['requesting_user_id']);
             $requestername = User::model()->find($criteria7);
             $requester_name = $requestername['firstname']. ' ' . $requestername['lastname'];
         
             //get the document name 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$request['requesting_domain_id']);
             $domain = Resourcegroupcategory::model()->find($criteria);  
             
                          
             if($box===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box"=>$box['name'],
                            "groupname"=> $requestinggroup['name'],
                           "subgroupname"=>$requestingsubgroup['name'],
                           "requestername"=>$requester_name,
                           "requesting_domainname"=>$domain['name']
                          
                    ));
                       
                }
            
        }
        
        
         /**
         * This is the function that retrieves details of a particular box & folder
         */
        public function actiongetTheBoxDetailAtConsumption(){
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
                    
            $box_id = $_POST['box_id'];
                   
             //get the box name
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$box_id);
             $box = Resourcegroup::model()->find($criteria2);  
             
             //get the name of this user
             $criteria7 = new CDbCriteria();
             $criteria7->select = '*';
             $criteria7->condition='id=:id';
             $criteria7->params = array(':id'=>$user_id);
             $requestername = User::model()->find($criteria7);
             $requester_name = $requestername['firstname']. ' ' . $requestername['lastname'];
         
             //get the domain name 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $domain = Resourcegroupcategory::model()->find($criteria);  
             
                          
             if($box===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box"=>$box['name'],
                            "requestername"=>$requester_name,
                           "requesting_domainname"=>$domain['name']
                          
                    ));
                       
                }
            
        }
        
        
         /**
         * This is the function that retrieves details of a particular box & folder
         */
        public function actiongetTheBoxDetailAtRequest(){
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
                    
            $box_id = $_POST['box_id'];
            if(isset($_POST['order_id'])){
                 $order_id = $_POST['order_id'];
                 //Get the maximum number of days(number of years) for this item in the cart folder
                //$cart_order_max_days = $this->getTheMaximumDaysForThisBoxRequest($box_id, $order_id);
            }
                            
             //get the box name
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$box_id);
             $box = Resourcegroup::model()->find($criteria2);  
             
             //get the name of this user
             $criteria7 = new CDbCriteria();
             $criteria7->select = '*';
             $criteria7->condition='id=:id';
             $criteria7->params = array(':id'=>$user_id);
             $requestername = User::model()->find($criteria7);
             $requester_name = $requestername['firstname']. ' ' . $requestername['lastname'];
         
             //get the domain name 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $domain = Resourcegroupcategory::model()->find($criteria);
             
             //get the maximum number of days for the electronic box & folder
             //$maximum_days = $this->getTheMaximumDaysForThisBoxRequest($box_id, $order_id);
             
           //get thd if the existing physical batch request initiated by this user            
            $physical_request_id = $this->getTheIdOfThisBoxOnRequest($box_id, $user_id);
            
                    
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id ';
             $criteria6->params = array(':id'=>$physical_request_id);
             $request = PhysicalBoxRequest::model()->find($criteria6); 
             
             if($request['is_single_user_request'] == true){
                 $name = $this->getTheNameOfTheThisRequestingUser($request['requesting_user_id']);
             }else if($request['is_group_request'] == true){
                 $name = $this->getTheNameOfThisGroup($request['requesting_group_id']);
             }else if($request['is_subgroup_request'] == true){
                 $name = $this->getTheNameOfThisSubgroup($request['requesting_subgroup_id']);
             }else{
                 $name = null;
             }
             
              //get the virtual request id
             
             $virtual_request_id = $this->getTheIdOfThisVirtualBoxOnRequest($box_id, $user_id);
             
              //retrieve the information for virtual request
             $criteria8 = new CDbCriteria();
             $criteria8->select = '*';
             $criteria8->condition='id=:id ';
             $criteria8->params = array(':id'=>$virtual_request_id);
             $virtual = VirtualBoxRequest::model()->find($criteria8); 
             
             if($virtual['virtual_is_single_user_request'] == true){
                 $virtual_name = $this->getTheNameOfTheThisRequestingUser($virtual['virtual_requesting_user_id']);
             }else if($virtual['virtual_is_group_request'] == true){
                 $virtual_name = $this->getTheNameOfThisGroup($virtual['virtual_requesting_group_id']);
             }else if($virtual['virtual_is_subgroup_request'] == true){
                 $virtual_name = $this->getTheNameOfThisSubgroup($virtual['virtual_requesting_subgroup_id']);
             }else{
                $virtual_name = null; 
             }
      
                          
             if($box===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box"=>$box['name'],
                            "requestername"=>$requester_name,
                           "requesting_domainname"=>$domain['name'],
                           "physical"=>$request['include_physical_instrument'],
                           "electronic"=>$request['is_electronic_instrument_request_included'],
                           "physical_id"=>$physical_request_id,
                           "is_single_user"=>$request['is_single_user_request'],
                           "is_group"=>$request['is_group_request'],
                           "is_subgroup"=>$request['is_subgroup_request'],
                           "the_single_user"=>$request['requesting_user_id'],
                           "the_group"=>$request['requesting_group_id'],
                           "the_subgroup"=>$request['requesting_subgroup_id'],
                           "name"=>$name,
                          "max_days"=>$request['maximum_requesting_period_in_days'],
                          "virtual_max_days"=>$virtual['virtual_maximum_requesting_period_in_days'],
                           "virtual_electronics"=>$virtual['virtual_is_electronic_instrument_request_included'],
                           "virtual_id"=>$virtual['id'],
                           "virtual_is_single_user"=>$virtual['virtual_is_single_user_request'],
                           "virtual_is_group"=>$virtual['virtual_is_group_request'],
                           "virtual_is_subgroup"=>$virtual['virtual_is_subgroup_request'],
                           "virtual_user_id"=>$virtual['virtual_requesting_user_id'],
                           "virtual_group_id"=>$virtual['virtual_requesting_group_id'],
                           "virtual_subgroup_id"=>$virtual['virtual_requesting_subgroup_id'],
                           "virtual_name"=>$virtual_name,
                                                 
                          
                    ));
                       
                }
            
        }
        
        
     
        /**
         * This is the function that gets the id of a virtual box & folder in a virtual request table 
         */
        public function getTheIdOfThisVirtualBoxOnRequest($box_id, $user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(virtual_box_id=:doc and virtual_requesting_user_id=:userid) and (status=:status and virtual_is_requested=:requested)';
             $criteria6->params = array(':doc'=>$box_id,':userid'=>$user_id,':status'=>"inactive",':requested'=>false);
             $holder = VirtualBoxRequest::model()->find($criteria6);  
             
             if($holder['id'] == 0 || $holder['id'] == null ){
                return 0;
            }else{
                return $holder['id'];
            }
        }
        
        
        
        /**
         * This is the function that retrieves the name of a requesting box user
         */
        public function getTheNameOfTheThisRequestingUser($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $result = User::model()->find($criteria);
             
             $name = $result['firstname'] . ' ' . $result['lastname'];
             
             return $name;
            
            
        }
        
        
        /**
         * This is the function that gets the of the requesting group
         */
        public function getTheNameOfThisGroup($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $result = Group::model()->find($criteria);
             
             return $result['name'];
            
            
        }
        
        
        /**
         * This is the function that gets the name of the requesting subgroup
         */
        public function getTheNameOfThisSubgroup($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $result = SubGroup::model()->find($criteria);
             
             return $result['name'];
            
        }
        /**
         * this is the function that retrieves the maximum days for an electronic box request
         */
        public function getTheMaximumDaysForThisBoxRequest($box_id, $order_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and toolbox_id=:boxid';
             $criteria->params = array(':orderid'=>$order_id, ':boxid'=>$box_id);
             $result = OrderHasToolboxes::model()->find($criteria);
             
             return $result['number_of_years'];
        }
        
        /**
         * This is the function that rejects a domains box request
         */
        public function actionRejectThisOwnPhysicalBoxRequest(){
            
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $requesting_user_id = $_POST['requesting_user_id'];
                        
            $box_name = $this->getThisBoxName($box_id);
            if($this->isThisBoxRequestInitiated($id)){
               if($this->isRejectionOfThisOwnBoxRequestSuccessful($id)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request for '$box_name' box & folder is rejected"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The request for '$box_name' box & folder could not be rejected"
                        ));
            } 
                
            }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "There is no pending request for '$box_name' physical box by this user"
                        )); 
            }
            
            
        }
        
        
        /**
         * This is the function that accepts a box domains request
         */
        public function actionAcceptThisOwnPhysicalBoxRequest(){
            
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_requesting_period_in_days']; 
            $requesting_domain_id = $_POST['requesting_domain_id'];
            $request_at = strtolower($_POST['request_at']);
            if(isset($_POST['is_single_user_request'])){
                    $requesting_user_id = $_POST['requesting_user_id'];
            }else if(isset($_POST['is_subgroup_request'])){
                 $requesting_user_id = $this->getTheSubgroupHeadIdOfThisSubgroup($_POST['requesting_subgroup_id']);
            }else if(isset($_POST['is_group_request'])){
                $requesting_user_id= $this->getTheGroupHeadIdOfThisGroup($_POST['requesting_group_id']);
            }
                      
            $box_name = $this->getThisBoxName($batch_id);
            if($this->isThisBoxRequestInitiated($id)){
                if($this->isConfirmationOfTheRequestOfThisBoxSuccessful($id)){
                    //initiate the assignment of the box to the requester
                    if($this->isAssignmentOfThisRequestedBoxToTheRequesterSuccessful($user_id,$domain_id,$box_id, $id,$requesting_user_id,$request_at,$max_period,$requesting_domain_id)){
                        
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request of '$box_name' box & folder  by this user is accepted and hence awaiting assignment confirmation"
                        ));
                    }else{
                         header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request for '$box_name' box & folder  by this user is accepted but assignment to the requester could not be initiated.Unavailability of box & folder could be a factor"
                        ));
                        
                    }
               
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The request for '$box_name' box & folder  to the requester could not be accepted"
                        ));
            }
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The request of '$box_name' box & folder  is not currently initiated by this user"
                        ));
                
            }
            
        }
        
        
        
         /**
         * this is the function that initiates the assignment of own physical batch to holder
         */
        public function isAssignmentOfThisRequestedBoxToTheRequesterSuccessful($user_id,$domain_id,$box_id, $id,$new_custodian,$request_at,$max_period,$requesting_domain_id){
           
           $box_name = $this->getThisBoxName($box_id);
           if($this->isPhysicalBoxAlreadyOnTransit($_id)){
               //only accept the document request without assigning to a new holder
               if($this->isConfirmationOfTheRequestOfThisBoxSuccessful($id)){
                   return false;
               }else{
                   return false;
               }
               
           }else{
               
             if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisBoxAssignmentInitiationSuccessful($box_id,$new_custodian,$max_period,$requesting_domain_id,$request_at)){
                     return true;
                    
                }else{
                    return false;
                }
                
            }else{
                if($this->isAssignmentOfThisBoxToACustodianSuccessful($box_id,$new_custodian,$max_period,$requesting_domain_id,$request_at)){
                    return true;
                }else{
                   return false;
                }
                
            }
           }
             
           
                 
          
        }
        
        
        
         /**
      * This is the function that initiates and confirms batch assignment to a holder
      */
     public function isAssignmentOfThisBoxToACustodianSuccessful($box_id,$new_custodian,$max_period,$requesting_domain_id,$request_at){
         
         if(strtolower("$request_at") == 'request'){
             $assign_type = 'from_store';
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->insert('physical_box_holder',
                                  array(
                                    'is_assignment_initiated'=>1, 
                                    'maximum_holding_period_in_days'=>$max_period,  
                                    'assignment_initiated_by'=>Yii::app()->user->id,  
                                    'assignment_initiation_date'=>new CDbExpression('NOW()'),
                                    'holder_domain_id'=> $requesting_domain_id, 
                                    'is_assignment_confirmed'=>1, 
                                    'assignment_confirmed_by'=>Yii::app()->user->id,  
                                    'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                                    'is_assigned'=>1,  
                                    'user_id'=>$new_custodian,
                                    'assigned_type'=>$assign_type,
                                    'box_id'=>$box_id,
                                    'is_returned'=>0    
                                              
                            )
              
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
            
         }else if(strtolower("$request_at") == 'consumption'){
             
             if($this->isPhysicalBoxAlreadyOnTransit($box_id)){
                  if($this->isConfirmationOfTheRequestOfThisBoxSuccessful($id)){
                   return false;
               }else{
                   return false;
               }
             }else{
                  $assign_type_2 = 'from_store';
                  $cmd =Yii::app()->db->createCommand();
                  $result = $cmd->insert('physical_box_holder',
                                  array(
                                    'is_assignment_initiated'=>1, 
                                    'maximum_holding_period_in_days'=>$max_period,  
                                    'assignment_initiated_by'=>Yii::app()->user->id,  
                                    'assignment_initiation_date'=>new CDbExpression('NOW()'),
                                    'holder_domain_id'=> $requesting_domain_id, 
                                    'is_assignment_confirmed'=>1, 
                                    'assignment_confirmed_by'=>Yii::app()->user->id,  
                                    'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                                    'is_assigned'=>1,  
                                    'user_id'=>$new_custodian,
                                    'assigned_type'=>$assign_type_2,
                                    'box_id'=>$box_id,
                                    'is_returned'=>0  
                                              
                            )
              
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
             }
             
         }
         
     }
        
    /**
      * This is the function that determines if the requested physical box is on transit
      */
     public function isPhysicalBoxAlreadyOnTransit($box_id){
         
          $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_box_holder')
                    ->where("box_id = $batch_id && is_returned !=1");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
     
         /**
      * This is the function that determines if initiator verifier is required by a domain
      */
     public function isInitiatorVerifierRequired($domain_id){
         
         if($this->isDomainVerifierPermittedOnThePlatform()){
             if($this->isDomainInitiatorExemptedFromVerification($domain_id)){
                 return false;
             }else{
                 return true;
             }
             
         }else{
            return false; 
         }
     }
     
      /**
      * This is the function that determines if domains initiators should be verified
      */
     public function isDomainVerifierPermittedOnThePlatform(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $settings = PlatformSettings::model()->find($criteria);
            
            if($settings['enable_domain_initiator_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
      /**
      * This is the fucntion that determines if domain is exempted from having a verifier 
      */
     public function isDomainInitiatorExemptedFromVerification($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$id,':status'=>'active');
            $policy = DomainPolicy::model()->find($criteria);
            
            if($policy['exempt_domain_initiator_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
                
      
        
      /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        /**
         * This is the function that gets a box & folder title
         */
        public function getThisBoxName($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $box = Resourcegroup::model()->find($criteria); 
             
             return $box['name'];
            
        }
        
        
          /**
         * This is the function that confirms if a use had already requested for a box & folder
         */
        public function isThisBoxRequestInitiated($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalBoxRequest::model()->find($criteria);  
             
             if($doc['is_request_initiated'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
        
         /**
         * This is the function that confirms if the rejection of this box request is successful
         */
        public function isRejectionOfThisOwnBoxRequestSuccessful($id){
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('physical_box_request',
                                  array(
                                    'is_request_accepted'=>0, 
                                    'request_accepted_by'=>Yii::app()->user->id,  
                                    'request_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_requested'=>0,   
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
            
        }
        
        
         /**
      * This is the function that cancels a particular other domain batch request
      */
     public function actionCancelThisPhysicalBoxRequest(){
         
         $id = $_REQUEST['id'];
         $box_id = $_REQUEST['box_id'];
         
        //get this box name or title
         
         $box_name = $this->getThisBoxName($box_id);
         
          if($this->isThisBoxRequestCancellable($id)){
              
              if($this->isThisPhysicalBoxRequestCancelled($id)){
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "This '$box_name' box & folder request is cancelled successfully "
                        )); 
         }else{
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$box_name' box & folder request is not cancelled"
                        )); 
         }
              
          }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$box_name' box & folder request could not be cancelled. Request may had been approved"
                        )); 
          }
          
         
         
     }
     
     
      /**
      * This is the function that cancells a document request
      */
     public function isThisPhysicalBoxRequestCancelled($id){
         
         $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_box_request',
                                  array(
                                    'is_request_cancelled'=>1, 
                                    'request_cancelled_by'=>Yii::app()->user->id,  
                                    'request_cancelled_date'=>new CDbExpression('NOW()')
                                      
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
     
     
        
         /**
      * This is the function that retrieves the head of a subgroup
      */
     public function getTheSubgroupHeadIdOfThisSubgroup($subgroup_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$subgroup_id);
             $subgroup = SubGroup::model()->find($criteria);   
             
             return $subgroup['subgroup_head_id'];
         
         
     }
     
     
      /**
      * This is the function that retrieves the group head id of this group
      */
     public function getTheGroupHeadIdOfThisGroup($group_id){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$group_id);
             $group = Group::model()->find($criteria);   
             
             return $group['group_head_id'];
         
         
     }
     
     
      /**
         * This is the function that determines if an own physical batch request is successfully confirmed
         */
        public function isConfirmationOfTheRequestOfThisBoxSuccessful($id){
            
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_box_request',
                                  array(
                                    'is_request_accepted'=>1, 
                                    'request_accepted_by'=>Yii::app()->user->id,  
                                    'request_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_requested'=>1,   
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
            
        }
        
        
         /**
      * This is the function that determines if physical document assignment initiation is successful
      */
     public function isThisBoxAssignmentInitiationSuccessful($box_id,$new_custodian,$max_period,$requesting_domain_id,$request_at){
         
         if(strtolower("$request_at") == 'request'){
             $assign_type = 'from_store';
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->insert('physical_box_holder',
                                  array(
                                    'is_assignment_initiated'=>1, 
                                    'maximum_holding_period_in_days'=>$max_period,  
                                    'assignment_initiated_by'=>Yii::app()->user->id,  
                                    'assignment_initiation_date'=>new CDbExpression('NOW()'),
                                    'holder_domain_id'=> $requesting_domain_id, 
                                    'user_id'=>$new_custodian,
                                    'assigned_type'=>$assign_type,
                                    'box_id'=>$box_id,
                                    'is_returned'=>0    
                                              
                            )
              
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
            
         }else if(strtolower("$request_at") == 'consumption'){
             
             if($this->isPhysicalBoxAlreadyOnTransit($box_id)){
                  if($this->isConfirmationOfTheRequestOfThisBoxSuccessful($id)){
                   return false;
               }else{
                   return false;
               }
             }else{
                  $assign_type_2 = 'from_store';
                  $cmd =Yii::app()->db->createCommand();
                  $result = $cmd->insert('physical_box_holder',
                                  array(
                                    'is_assignment_initiated'=>1, 
                                    'maximum_holding_period_in_days'=>$max_period,  
                                    'assignment_initiated_by'=>Yii::app()->user->id,  
                                    'assignment_initiation_date'=>new CDbExpression('NOW()'),
                                    'holder_domain_id'=> $requesting_domain_id, 
                                    'user_id'=>$new_custodian,
                                    'assigned_type'=>$assign_type_2,
                                    'box_id'=>$box_id,
                                    'is_returned'=>0   
                                              
                            )
              
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
             }
             
         }
 
     }
        
     
     /**
      * This is the function that request for a physical box
      */
     public function actionRequestForThisPhysicalBox(){
         
         $model=new PhysicalBoxRequest;   
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $model->box_id = $_POST['box_id'];
            $model->maximum_requesting_period_in_days = $_POST['maximum_requesting_period_in_days']; 
            $model->requesting_domain_id = $domain_id;
            $model->request_at = strtolower($_POST['request_at']);
           $model->requesting_user_id = $user_id;
           if(isset($_POST['group'])){
               $model->requesting_group_id = $_POST['group'];
               $model->is_group_request = 1;
               $model->is_subgroup_request = 0;
               $model->is_single_user_request = 0;
           }else if(isset($_POST['subgroup'])){
               $model->requesting_subgroup_id = $_POST['subgroup'];
               $model->is_group_request = 0;
               $model->is_subgroup_request = 1;
               $model->is_single_user_request = 0;
           }else{
               $model->is_group_request = 0;
               $model->is_subgroup_request = 0;
               $model->is_single_user_request = 1;
           }
           $model->request_initiation_date = new CDbExpression('NOW()');
           $model->request_initiated_by = Yii::app()->user->id;
           $model->is_request_initiated = 1;
           if(strtolower($_POST['request_at']) == 'request'){
               if(isset($_POST['include_physical_instrument'])){
                    $model->include_physical_instrument = $_POST['include_physical_instrument'];
               }else{
                    $model->include_physical_instrument = 0;
                }
                if(isset($_POST['is_electronic_instrument_request_included'])){
                    $model->is_electronic_instrument_request_included = $_POST['is_electronic_instrument_request_included'];
                }else{
                    $model->is_electronic_instrument_request_included = 0;
                }
               
           }else if(strtolower($_POST['request_at']) == 'consumption'){
               $model->include_physical_instrument = 1;
               $model->is_electronic_instrument_request_included = 0;
           } 
          
                      
            $box_name = $this->getThisBoxName($model->box_id);
            if($this->isThisRequestInConformityWithPolicy($domain_id)){
                if($this->thereIsNoPendingRequestOfThisBoxByThisUser($model->box_id,$model->request_initiated_by)){
                    //initiate the request for this document
                    if($model->save()){
                        
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request for '$box_name' box & folder  is successfully initiated"
                        ));
                    }else{
                         header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Request for the '$box_name' box & folder could not be initiated. Probably a validation error"
                        ));
                        
                    }
                    
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Request for the '$box_name' box & folder could not be initiated as there is an open request of same box & folder that is undergoing approval"
                        ));
                }
                    
               
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Your domain policy bars you from requesting for the '$box_name' box & folder. Please contact your domain administrator"
                        ));
            }
     }
     
     
      /**
      * This is the function that determines if there is an existing open request of a document by a user
      */
     public function thereIsNoPendingRequestOfThisBoxByThisUser($box_id,$request_initiated_by){
         
         if($this->hasThisUserMadeThisBoxRequestBefore($box_id,$request_initiated_by)){
             if($this->isThereAnyOpenRequestOfThisBoxByThisUser($box_id,$request_initiated_by)){
                 return false;
             }else{
                 return true;
             }
             
         }else{
             return true;
         }
         
     }
     
     
     /**
      * This is the function that determines if this user had made a similar request before
      */
     public function hasThisUserMadeThisBoxRequestBefore($box_id,$request_initiated_by){
         
          $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_box_request')
                    ->where("box_id = $box_id && request_initiated_by=$request_initiated_by");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
     /**
      * This is the function that determines if there is any open request of this government by this user
      */
     public function isThereAnyOpenRequestOfThisBoxByThisUser($box_id,$request_initiated_by){
         
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_box_request')
                    ->where("(box_id = $box_id && request_initiated_by=$request_initiated_by) &&(is_requested=0 && is_sent=0) and is_request_cancelled=0");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
         
     }
     
      /**
     * This is the function that determines if a document request is in conformity with the prevailing domain policy
     */
     public function isThisRequestInConformityWithPolicy($domain_id){
         
         return true;
     }
     
     
     /**
      * This is the function that cancels a physical box request at consumption
      */
     public function actionCancelThisPhysicalBoxRequestAtConsumption(){
         
         $box_id = $_POST['box_id'];
         
         $user_id = Yii::app()->user->id;
         
         $domain_id = $this->getTheDomainIdOfThisUser($user_id);
         
         //get the id of the physical box request that should be cancelled
         
         $id  = $this->getTheIdOfThisBoxOnRequest($box_id,$user_id);
         
         $box_name = $this->getThisBoxName($box_id);
         
         if($this->isThisBoxRequestCancellable($id)){
             if($this->isThisPhysicalBoxRequestCancelled($id)){
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "This '$box_name' box & folder request is cancelled successfully "
                        )); 
         }else{
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$box_name' box & folder request is not cancelled"
                        )); 
         }
             
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$box_name' box & folder request could not be cancelled. Request may had been approved or had already been cancelled"
                        )); 
         } 
         
     }
     
     
      /**
      * This is the function that gets the id of the  box on request
      */
     public function getTheIdOfThisBoxOnRequest($box_id,$user_id){
         
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(box_id=:doc and requesting_user_id=:userid) and (is_sent=:sent and is_requested=:requested) and is_request_cancelled=:cancelled';
             $criteria6->params = array(':doc'=>$box_id,':userid'=>$user_id,':sent'=>false,':requested'=>false,':cancelled'=>false);
             $holder = PhysicalBoxRequest::model()->find($criteria6);  
             
            if($holder['id'] == 0 || $holder['id'] == null ){
                return 0;
            }else{
                return $holder['id'];
            }
         
     }
     
     
     /**
      * This is the function that determines if a batch request is cancellable
      */
     public function isThisBoxRequestCancellable($id){
         if($id == 0){
            return false;
         }else{
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id';
             $criteria6->params = array(':id'=>$id);
             $request = PhysicalBoxRequest::model()->find($criteria6);  
             
             if($request['is_sent'] == true || $request['is_requested'] == true || $request['is_request_cancelled']== true){
                 return false;
             }else{
                 return true;
             }
         }
             
         
     }
     
     /**
      * This is the function that modifies request for physical box in a request list
      */
     public function actionModifyRequestForThisPhysicalBox(){
         
          $id = $_POST['id'];
          $model=PhysicalBoxRequest::model()->findByPk($id);
          
          if($id != 0){
              
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $model->box_id = $_POST['box_id'];
            $model->maximum_requesting_period_in_days = $_POST['maximum_requesting_period_in_days']; 
            $model->requesting_domain_id = $domain_id;
            $model->request_at = strtolower($_POST['request_at']);
           $model->requesting_user_id = $user_id;
           if(isset($_POST['group'])){
               $model->requesting_group_id = $_POST['group'];
               $model->is_group_request = 1;
               $model->is_subgroup_request = 0;
               $model->is_single_user_request = 0;
           }else if(isset($_POST['subgroup'])){
               $model->requesting_subgroup_id = $_POST['subgroup'];
               $model->is_group_request = 0;
               $model->is_subgroup_request = 1;
               $model->is_single_user_request = 0;
           }else{
               $model->is_group_request = 0;
               $model->is_subgroup_request = 0;
               $model->is_single_user_request = 1;
           }
           $model->request_initiation_date = new CDbExpression('NOW()');
           $model->request_initiated_by = Yii::app()->user->id;
           $model->is_request_initiated = 1;
           if(strtolower($_POST['request_at']) == 'request'){
               if(isset($_POST['include_physical_instrument'])){
                    $model->include_physical_instrument = $_POST['include_physical_instrument'];
               }else{
                    $model->include_physical_instrument = 0;
                }
                if(isset($_POST['is_electronic_instrument_request_included'])){
                    $model->is_electronic_instrument_request_included = $_POST['is_electronic_instrument_request_included'];
                }else{
                    $model->is_electronic_instrument_request_included = 0;
                }
               
           }else if(strtolower($_POST['request_at']) == 'consumption'){
               $model->include_physical_instrument = 1;
               $model->is_electronic_instrument_request_included = 0;
           } 
                      
            $box_name = $this->getThisBoxName($model->box_id);
            if($this->isThisRequestInConformityWithPolicy($domain_id)){
                  //modify this request for this batch
                    if($model->save()){
                        
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request for '$box_name' box & folder  is successfully modified"
                        ));
                    }else{
                         header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Request for the '$box_name' box & folder could not be modified. Probably a validation error"
                        ));
                        
                    }
                    
               
               
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Your domain policy bars you from requesting for the modification of  '$box_name' box & folder. Please contact your domain administrator"
                        ));
            }
          }else{
            $box_name = $this->getThisBoxName($_POST['box_id']);
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "You do not have any open physical '$box_name' box & folder request for modification."
                        )); 
          }
          
            
         
          
     }
     
     
     /**
      * This is the function that removes an a physical box item from a request list 
      */
     public function actionRemoveRequestItemFromThisPhysicalBox(){
         $box_id = $_REQUEST['box_id'];
         $user_id = Yii::app()->user->id;
         
         //get the id of the item in the physical request list
         $id = $this->getTheIdOfThisBoxOnRequest($box_id, $user_id);
         
          $boxname = $this->getThisBoxName($box_id);
         
         if($id > 0){
              $cmd =Yii::app()->db->createCommand();  
         $result = $cmd->delete('physical_box_request', "id=:boxid", array(':boxid'=>$id));
         
        
         
         if($result>0){
                   
                    $msg = "'$boxname' item is successfully removed from the physical box & folder requesl list";
                     echo CJSON::encode(array(
                          "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
                    
                }else{
                    $msg = "Removal of '$boxname' item from the physical box & folder request list was not successful ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                }
             
         }else{
             $msg = "Removal of '$boxname' is aborted as there is no such item in the pjysical box & folder rrequest list. ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
         }
         
        
         
     }
      
}
