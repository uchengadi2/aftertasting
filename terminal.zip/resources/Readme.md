# ext-theme-neptune-93f95e1b-305f-4727-9b5a-d164cddc7576/resources

This folder contains static resources (typically an `"images"` folder as well).
