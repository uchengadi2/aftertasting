<?php

class ResourcegroupController extends Controller
{
	
        private $_id = [];
        public $excluded_days = [];
        /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'. 'listallresourcegroups','ListAllToolsInThisToolbox','ListAllTasksInThisToolbox','ListAllDomainsToolboxes','ListAllDomainsInThisPlatform'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'listresourcegroupforcategoryassigment', 'listresourcegroupforcategoryassignmentupdate', 'ListResourcegroupForGroupAssigment',
                                 'ListResourceGroupForSubgroupAssignmentUpdate', 'ListResourcegroupForSubgroupAssigment', 'ListResourcegroupForCategoryScheduling', 
                                    'ListResourceGroupForGroupAssignmentUpdate', 'ListResourceGroupForSubgroupAssignmentUpdate', 'ListResourcesForResourcegroupAssigmentUpdate',
                                    'ListResourcegroupForCategoryBulkScheduling', 'ListResourcegroupForGroupBulkScheduling', 'ListResourcegroupForSubgroupBulkScheduling',
                                    'ListResourcegroupForUserBulkScheduling', 'ListResourceGroupForUserAssignmentUpdate', 'ListResourceForResourcegroupBulkScheduling',
                                    'AssignResourcegroupToGroup', 'AssignResourcegroupToCategory','AssignResourcegroupToSubgroup', 'AssignResourcegroupToUser',
                                    'AssignResourceToResourcegroup', 'ScheduleSingleResourcegroupToCategory', 'ScheduleBulkResourcegroupToCategory',
                                    'ScheduleBulkResourcegroupToCategory', 'ScheduleSingleResourcegroupToGroup', 'ScheduleSingleResourcegroupToUser', 'ScheduleSingleResourcegroupToSubgroup',
                                    'ScheduleSingleResourceToResourcegroup', 'ScheduleSingleUserToSubgroup', 'ScheduleBulkResourcegroupToGroup','ScheduleBulkResourcegroupToSubgroup',
                                    'ScheduleBulkResourcegroupToUser', 'ScheduleBulkResourceToResourcegroup','ListAllResourcegroupsInCategory', 'ListAllResourcesInResourcegroup',
                                    'ListAllResourcegroupsInAGroup','ListAllResourcegroupsInASubgroup','listallresourcegroupsforthisuser','ListResourcegroupForCategoryForSingleScheduling',
                                    'ListResourcegroupForUserForSingleScheduling', 'ListResourcegroupForSubgroupForSingleScheduling','ListResourcegroupForGroupForSingleScheduling',
                                    'ListResourcesForResourcegroupForSingleScheduling', 'ListAllResourcegroupForThisUser', 'ListAllOnScheduledResourcesInResourcegroup', 'ListResourcegroupForGroupForSingleAssignment',
                                    'ListResourceForResourcegroupForSingleAssignment', 'ListResourcegroupForUserForSingleAssignment', 'ListResourcegroupForCategoryForSingleAssignment', 'ListResourcegroupForSubgroupForSingleAssignment',
                                    'AssignSingleResourcegroupToGroup', 'AssignNewSingleResourcegroupToGroup', 'DeleteOneAssignedResourcegroup', 'AssignSingleResourcegroupToSubgroup', 'AssignNewSingleResourcegroupToSubgroup',
                                    'DeleteOneAssignedSubgroupToResourcegroup','AssignSingleResourcegroupToUser','deleteoneassignedresourcegrouptouser', 'AssignNewSingleResourcegroupToUser','deleteoneassignedresourcegrouptocategory',
                                    'AssignNewSingleResourceToResourcegroup','AssignSingleResourceToResourcegroup', 'DeleteOneAssignedResourceToResourcegroup',
                                    'AssignSingleResourcegroupToCategory', 'AssignNewSingleResourcegroupToCategory', 'ListAllResourcegroupsInCategoryForAssignment', 'ListAllResourcegroupsInCategoryForSubgroupAssignment',
                                    'ListAllResourcegroupsInCategoryForGroupAssignment', 'ListAllResourcegroupsInCategoryForUserAssignment','partnertoolboxesbyvisibility',
                                    'ListAllReservedToolboxesForNetworksInDomain','ListAllReservedToolboxesInThisDomain','toolboxdetailinfo','retrieveAllReservedToolboxesForNetworkInDomain','ListAllDomainPartners',
                                    'ListAllToolsInThisToolbox','ListAllTasksInThisToolbox','getThePreferredCurrencyOfADomain','ListAllDomainsToolboxes','AllToolboxesBelongingToADomain','AllToolboxesAssignedToDomain',
                                    'ListAllToolbxesConsumedByThisDomain','retrievePrivateToolboxesAssignedToThisDomain','isThisPeriodWithinSchedule','ListAllUsersTaskFavourites','ListAllTasksAssignedToAUser',
                                    'justTesting','RetrieveAllUserTaskForChaining','ListAllSimilarTasksAcrossUserToolboxes','isThereStillAnyAvailableSpaceForThisDomain','isProgramWithMediaServiceWithinThisContext',
                                    'isProgramWithMediaServiceWithinThisContext','isThisContextInAnySlotInThisSession','isContextInThisSlot','rejectTheVerificationTheStorageOfThisBoxOrFolder','rejectTheCheckingTheStorageOfThisBoxOrFolder',
                                    'rejectTheConfirmTheStorageOfThisBoxOrFolder','verifyTheStorageOfThisBoxOrFolder','checkTheStorageOfThisBoxOrFolder','confirmTheStorageOfThisBoxOrFolder','Tester',
                                    'retrieveTheClustersThatArePermittedToRequestForBoxes','retrieveTheNeighbourhoodsThatArePermittedToRequestForBoxes','retrieveDocumentTpesThatDeterminesTheBatchToAcceptInABox',
                                    'retrieveDocumentCategoriesThatDeterminesTheBatchToAcceptInABox','retrieveClustersWithThePermissionToConsumeBoxes','retrieveNeighbourhoodsWithThePermissionToConsumeBoxes',
                                    'AddPermittedNeighbourhoodsForBoxesOnBox','AddPermittedClustersForBoxesOnBox','AddDocumentTypesThatAreAcceptableToBatchesInBoxesOnBox','AddDocumentCategoriesThatAreAcceptableToBatchesInBoxesOnBox',
                                    'AddNeighbourhoodsWithPermissionToCollectBoxesOnBox','AddClustersWithPermissionToCollectBoxesOnBox','retrieveProcessorsWhoseBatchesCouldBeAcceptedByThisBox','retrieveNeighbourhoodsWhoseMemberBatchesCouldBeAcceptedByThisBox',
                                    'retrieveClustersWhoseMemberBatchesCouldBeAcceptedByThisBox','AddProcessorsWhoseBatchesWillBeAcceptedInThisBox','AddNeighbourhoodsWhosememberBatchesWillBeAcceptedInThisBox',
                                    'AddCusterssWhosememberBatchesWillBeAcceptedInThisBox','retrieveTheBlacklistsDirectlyApplicableToThisBox','retrieveTheWhitelistlistsDirectlyApplicableToThisBox','AddBlacklistThatWillBeApplicableToThisBox',
                                    'AddWhitelistThatWillBeApplicableToThisBox'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('listallresourcegroups','deleteoneresourcegroup','listresourcegroupforcategoryassigment', 'ListResourcegroupForGroupAssigment', 
                                    'ListResourceGroupForGroupAssignmentUpdate', 'ListResourcegroupForCategorySchedulingUpdate'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
           //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the platform base currency
            $base_currency = $this->getThePlatformBaseCurrency();
            
            
                $model=new Resourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

                $model->name = $_POST['name'];
                 if(isset($_POST['box_number'])){
                   $model->box_number = $_POST['box_number'];
               }
                $model->visibility= strtolower($_POST['visibility']);
               if(isset($_POST['description'])){
                    $model->description = $_POST['description'];
                }
                
               if(isset($_POST['price'])){
                    if($base_currency == $preferred_currency){
                         $model->price = $_POST['price'];
                    }else{
                        //retrieve the exchange rate of the preferred currency
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $dollar_value = ((double)$_POST['price'])/((double)$exchange_rate);
                        $model->price = $dollar_value;
                    }
                
                }
             
                if(isset($_POST['min_subscription_required'])){
                    $model->min_subscription_required = $_POST['min_subscription_required'];
                }else{
                    $model->min_subscription_required = 1;
                }
                if(isset($_POST['min_discountable_number'])){
                    $model->min_discountable_number = $_POST['min_discountable_number'];
                }else{
                    $model->min_discountable_number = 0;
                }
                if(isset($_POST['enforce_min_discountable_number'])){
                    $model->enforce_min_discountable_number = $_POST['enforce_min_discountable_number'];
                }else{
                    $model->enforce_min_discountable_number = 0;
                }
                if(isset($_POST['discount_rate'])){
                     $model->discount_rate = $_POST['discount_rate'];
                }
               if(isset($_POST['duplicate'])){
                    $model->duplicate = $_POST['duplicate'];
               }
               if(isset($_POST['reconstruct_toolbox'])){
                    $model->reconstruct_toolbox = $_POST['reconstruct_toolbox'];
               }
               if(isset($_POST['cumulative_component_price'])){
                   $model->cumulative_component_price = $_POST['cumulative_component_price'];
               }
               if(isset($_POST['price_preference'])){
                   $model->price_preference = $_POST['price_preference'];
               }
               if(isset($_POST['discount_proof'])){
                   $model->discount_proof = $_POST['discount_proof'];
               }
               if(isset($_POST['storage_location'])){
                   $model->storage_location = $_POST['storage_location'];
               }
               if(isset($_POST['storage_room'])){
                   $model->storage_room = $_POST['storage_room'];
               }
               if(isset($_POST['rack_number'])){
                   $model->rack_number = $_POST['rack_number'];
               }
               if(isset($_POST['rack_row_number'])){
                   $model->rack_row_number = $_POST['rack_row_number'];
               }
                if(isset($_POST['rack_column_number'])){
                   $model->rack_column_number = $_POST['rack_column_number'];
               }
            $model->closed_status = strtolower('indifferent');
            $model->max_file_at_closure = $_POST['max_file_at_closure'];
            $model->min_file_at_closure = $_POST['min_file_at_closure'];
             if(isset($_POST['is_closeable'])){
                $model->is_closeable = $_POST['is_closeable'];
            }else{
                $model->is_closeable = 0;
                        
            }
            if(isset($_POST['could_be_reopened'])){
                $model->could_be_reopened = $_POST['could_be_reopened'];
            }else{
                $model->could_be_reopened = 0;
                        
            }
            if(isset($_POST['could_be_reopened_when_max_number_not_reached'])){
                $model->could_be_reopened_when_max_number_not_reached = $_POST['could_be_reopened_when_max_number_not_reached'];
            }else{
                $model->could_be_reopened_when_max_number_not_reached = 0;
                        
            }
            if(isset($_POST['overide_external_influence_on_parameters'])){
                $model->overide_external_influence_on_parameters = $_POST['overide_external_influence_on_parameters'];
            }else{
                $model->overide_external_influence_on_parameters = 0;
                        
            }
            if(isset($_POST['accept_only_unique_batches'])){
                $model->accept_only_unique_batches = $_POST['accept_only_unique_batches'];
            }else{
                $model->accept_only_unique_batches = 0;
                        
            }
             if(isset($_POST['batches_from_these_document_types'])){
                $model->batches_from_these_document_types = $_POST['batches_from_these_document_types'];
            }else{
                $model->batches_from_these_document_types = 0;
                        
            }
             if(isset($_POST['batches_from_these_document_categories'])){
                $model->batches_from_these_document_categories = $_POST['batches_from_these_document_categories'];
            }else{
                $model->batches_from_these_document_categories = 0;
                        
            }
            if(isset($_POST['batches_from_own_domain'])){
                $model->batches_from_own_domain = $_POST['batches_from_own_domain'];
            }else{
                $model->batches_from_own_domain = 0;
                        
            }
            if(isset($_POST['batches_from_these_processors'])){
                $model->batches_from_these_processors = $_POST['batches_from_these_processors'];
            }else{
                $model->batches_from_these_processors = 0;
                        
            }
            if(isset($_POST['batches_from_these_domain_neighbourhoods'])){
                $model->batches_from_these_domain_neighbourhoods = $_POST['batches_from_these_domain_neighbourhoods'];
            }else{
                $model->batches_from_these_domain_neighbourhoods = 0;
                        
            }
            if(isset($_POST['batches_from_these_clusters'])){
                $model->batches_from_these_clusters = $_POST['batches_from_these_clusters'];
            }else{
                $model->batches_from_these_clusters = 0;
                        
            }
             if(isset($_POST['consummable_at_request'])){
                $model->consummable_at_request = $_POST['consummable_at_request'];
            }else{
                $model->consummable_at_request = 0;
                        
            }
             if(isset($_POST['consummable_by_hood_members'])){
                $model->consummable_by_hood_members = $_POST['consummable_by_hood_members'];
            }else{
                $model->consummable_by_hood_members = 0;
                        
            }
             if(isset($_POST['consummable_by_hood_cluster_members'])){
                $model->consummable_by_hood_cluster_members = $_POST['consummable_by_hood_cluster_members'];
            }else{
                $model->consummable_by_hood_cluster_members = 0;
                        
            }
             if(isset($_POST['could_be_requested_by_all'])){
                $model->could_be_requested_by_all = $_POST['could_be_requested_by_all'];
            }else{
                $model->could_be_requested_by_all = 0;
                        
            }
             if(isset($_POST['could_be_requested_by_hood_members'])){
                $model->could_be_requested_by_hood_members = $_POST['could_be_requested_by_hood_members'];
            }else{
                $model->could_be_requested_by_hood_members = 0;
                        
            }
            if(isset($_POST['could_be_requested_by_hood_cluster_members'])){
                $model->could_be_requested_by_hood_cluster_members = $_POST['could_be_requested_by_hood_cluster_members'];
            }else{
                $model->could_be_requested_by_hood_cluster_members = 0;
                        
            }
             if(isset($_POST['default_to_domain_conflict_resolution_preference'])){
                $model->default_to_domain_conflict_resolution_preference = $_POST['default_to_domain_conflict_resolution_preference'];
            }else{
                $model->default_to_domain_conflict_resolution_preference = 0;
                        
            }
            if(isset($_POST['prefer_whitelist_over_blacklist'])){
                $model->prefer_whitelist_over_blacklist = $_POST['prefer_whitelist_over_blacklist'];
            }else{
                $model->prefer_whitelist_over_blacklist = 0;
                        
            }
            if(isset($_POST['prefer_blacklist_over_whitelist'])){
                $model->prefer_blacklist_over_whitelist = $_POST['prefer_blacklist_over_whitelist'];
            }else{
                $model->prefer_blacklist_over_whitelist = 0;
                        
            }
            if(isset($_POST['effect_blacklist_on_box'])){
                $model->effect_blacklist_on_box = $_POST['effect_blacklist_on_box'];
            }else{
                $model->effect_blacklist_on_box = 0;
                        
            }
            if(isset($_POST['effect_whitelist_on_box'])){
                $model->effect_whitelist_on_box = $_POST['effect_whitelist_on_box'];
            }else{
                $model->effect_whitelist_on_box = 0;
                        
            }
            $model->purpose =strtolower($_POST['purpose']);
               $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                $model->domain_id = $domain_id;
                $model->is_document_initiated_or_updated = 1;
                $model->is_storage_confirmed_by_domain_verifier = 0;
                $model->is_storage_checked_by_platform_checker = 0;
                $model->is_storage_verified_by_platform_verifier = 0;
                $model->is_box_in_storage = 0;
                
                if($this->isDomainSpaceAvailableForThisToolbox($model->domain_id,$model->visibility)){
                       
                     $icon_error_counter = 0;
               
                //$icon = $_FILES['icon']['name'];
                //$this->createOrUpdateAGroupForResource($model, $icon=null);
                //working with the icon file
                if($_FILES['icon']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal($domain_id)){
                        
                       $icon_filename = $_FILES['icon']['name'];
                       $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $this->provideResourcegroupIconWhenUnavailable($model);
                   $icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           $model->icon_size = $icon_size;
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' folder was created successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' folder  was not created successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your icon file type or size as icon must be of width '$platform_width'px and height '$platform_height'px. Icon type is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
                            
                }else{
                    $msg = "This domain has run out of space capacity, you either delete some resources or contact the Customer Service Centre for some additional spaces";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() != 0,
                             "msg" => $msg)
                       );
                }
                
	}

        
        /**
         * This is the function that confirms if a domain has available space for a toolbox
         */
        public function isDomainSpaceAvailableForThisToolbox($domain_id,$visibility){
            if($this->isDomainPublicToolboxesExemptedFromSpaceCalculations($domain_id)){
                if($this->isThisAPublicToolbox($visibility)){
                    return true;
                  
                }else{
                    if($this->doesDomainStillHaveSpaceForThisToolbox($domain_id,$visibility)){
                        return true;
                       
                    }else{
                        return false;
                       
                    }
                }
            }else{
                if($this->doesDomainStillHaveSpaceForThisToolbox($domain_id,$visibility)){
                        return true;
                    
                    }else{
                        return false;
                        
                    }
            }
            
            
        }
        
        
        /**
         * This is the function that determines if a toolbox visibility is public
         */
        public function isThisAPublicToolbox($visibility){
            
            if($visibility == 'public'){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that determines if a domain public toolbox is exempted from space calculation
         */
        public function isDomainPublicToolboxesExemptedFromSpaceCalculations($domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $policy= DomainPolicy::model()->find($criteria);
            
            if($policy['exempt_public_toolboxes_in_space_calculation'] == 1){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that determines if a domain still has space for additional toolbox resource
         */
        public function doesDomainStillHaveSpaceForThisToolbox($domain_id,$visibility){
            
            if($visibility == 'private'){
                if($this->doesPlatformPolicyRequirePrivateToolboxesToBePartOfSpaceCalculation()){
                    if($this->doesDomainStillHasSomeRemainingSpace($domain_id)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return true;
                }
            }else if($visibility == 'restricted_public'){
                if($this->doesPlatformPolicyRequireRestrictedPublicToolboxesToBePartOfSpaceCalculation()){
                    if($this->doesDomainStillHasSomeRemainingSpace($domain_id)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return true;
                }
            }else if($visibility == 'private & public'){
                if($this->doesPlatformPolicyRequirePrivateAndPublicToolboxesToBePartOfSpaceCalculation()){
                    if($this->doesDomainStillHasSomeRemainingSpace($domain_id)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return true;
                }
            }else if($visibility == 'private & restricted_public'){
                if($this->doesPlatformPolicyRequirePrivateAndRestrictedPublicToolboxesToBePartOfSpaceCalculation()){
                    if($this->doesDomainStillHasSomeRemainingSpace($domain_id)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return true;
                }
            }else if($visibility == 'reserved'){
                if($this->doesPlatformPolicyRequireReservedToolboxesToBePartOfSpaceCalculation()){
                    if($this->doesDomainStillHasSomeRemainingSpace($domain_id)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return true;
                }
            }else if($visibility == 'public'){
                //confirm if the domain's public toolboxes are exempted from space calculation
                if($this->isDomainPublicToolboxesExemptedFromSpaceCalculations($domain_id)){
                    return true;
                }else{
                 if($this->doesPlatformPolicyRequirePublicToolboxesToBePartOfSpaceCalculation()){
                    if($this->doesDomainStillHasSomeRemainingSpace($domain_id)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return true;
                }
                }
            }
        }
        
        
        /**
         * This is the function that confirms if private toolboxes are part of space calculation
         */
        public function doesPlatformPolicyRequirePrivateToolboxesToBePartOfSpaceCalculation(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
           // $criteria->params = array(':id'=>$domain_id);
            $settings= PlatformSettings::model()->find($criteria);
            
            if($settings['include_private_toolboxes_in_space_calculation'] == 1){
                return true;
            }else{
                return false;
            }
            
        }
        
        
         /**
         * This is the function that confirms if restricted public toolboxes are part of space calculation
         */
        public function doesPlatformPolicyRequireRestrictedPublicToolboxesToBePartOfSpaceCalculation(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
           // $criteria->params = array(':id'=>$domain_id);
            $settings= PlatformSettings::model()->find($criteria);
            
            if($settings['include_restricted_public_toolboxes_in_space_calculation'] == 1){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that confirms if private & public toolboxes are part of space calculation
         */
        public function doesPlatformPolicyRequirePrivateAndPublicToolboxesToBePartOfSpaceCalculation(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
           // $criteria->params = array(':id'=>$domain_id);
            $settings= PlatformSettings::model()->find($criteria);
            
            if($settings['include_private_and_public_toolboxes_in_space_calculation'] == 1){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that confirms if private & resricted public toolboxes are part of space calculation
         */
        public function doesPlatformPolicyRequirePrivateAndRestrictedPublicToolboxesToBePartOfSpaceCalculation(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
           // $criteria->params = array(':id'=>$domain_id);
            $settings= PlatformSettings::model()->find($criteria);
            
            if($settings['include_private_restricted_toolboxes_in_space_calculation'] == 1){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that confirms if reserved toolboxes are part of space calculation
         */
        public function doesPlatformPolicyRequireReservedToolboxesToBePartOfSpaceCalculation(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
           // $criteria->params = array(':id'=>$domain_id);
            $settings= PlatformSettings::model()->find($criteria);
            
            if($settings['include_reserved_toolboxes_in_space_calculation'] == 1){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that confirms if public toolboxes are part of space calculation
         */
        public function doesPlatformPolicyRequirePublicToolboxesToBePartOfSpaceCalculation(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
           // $criteria->params = array(':id'=>$domain_id);
            $settings= PlatformSettings::model()->find($criteria);
            
            if($settings['include_public_toolboxes_in_space_calculation'] == 1){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines if a domain still has some remaining space for storage
         */
        public function doesDomainStillHasSomeRemainingSpace($domain_id){
            
            //get the total space allocated to this domain
            $total_domain_space = $this->getDomainsTotalAllocatedSpace($domain_id);
            if($this->isThereStillAnyAvailableSpaceForThisDomain($domain_id,$total_domain_space)){
                return true;
               
            }else{
                return false;
                
            }
            
        }
        
        
        /**
         * This is the function that gets a domain's allocated space
         */
        public function getDomainsTotalAllocatedSpace($domain_id){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $policy= DomainPolicy::model()->find($criteria);
            
            return $policy['total_domain_capacity_in_gigabytes'];
            
            
        }
        
        
        /**
         * This is the function that determines if there is still available space for a domain
         */
        public function isThereStillAnyAvailableSpaceForThisDomain($domain_id,$total_domain_space){
            //establish a  mega byte to gigabyte convert parameter
            $convert_to_gigabyte_value = 1000000000;

            //get domain's utilized space
            $domain_utilized_space =(double)$this->getThisDomainUtilizedSpace($domain_id);
            if(((double)$total_domain_space - ($domain_utilized_space/$convert_to_gigabyte_value))>0){
                return true;
                
            }else{
                return false;
               
            }
        }
        
        /**
         * This is the function that gets a domain's total utilized spaced
         */
        public function getThisDomainUtilizedSpace($domain_id){
        //get the total size of all video and zip contents belonging to this domain
            $all_domain_video_size = 0;
            $all_domain_zip_size = 0;
            $all_domain_image_size = 0;
            $domain_tools = [];
            $all_domain_tasks = [];
            $unique_domain_tools;
             $all_tools = [];
            
          //get all domain toolboxes that could be included in space calculation
         $domain_toolboxes_for_calculation = $this->getAllDomainToolboxesThatCouldBeIncludedInSpaceCalculation($domain_id);
         
         foreach($domain_toolboxes_for_calculation as $toolbox){
             //get the image/icon size
             $all_domain_image_size = $all_domain_image_size + $this->getTheToolboxImageSize($toolbox);
            
             //get all the tools in this toolbox
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='resourcegroup_id=:id';
                 $criteria->params = array(':id'=>$toolbox);
                 $tools= ResourceHasResourcegroups::model()->findAll($criteria);
                
                foreach($tools as $tool){
                    $domain_tools[] = $tool['resource_id'];
                  
                }
                
                
             
         }
         //make the value of domain tools array unique
         $unique_domain_tools = array_unique($domain_tools);
         
         foreach($unique_domain_tools as $tool){
             //get the image/icon size
             $all_domain_image_size = $all_domain_image_size + $this->getTheToolImageSize($tool);
               //get all the tools in this toolbox
            
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='parent_id=:id';
                 $criteria1->params = array(':id'=>$tool);
                 $tasks= Resources::model()->findAll($criteria1);
                
                foreach($tasks as $task){
                    $all_domain_tasks[] = $task['id'];
                  
                }
                
         }
         //get the size occupied by each of these tasks
           foreach($all_domain_tasks as $task){
                $all_domain_video_size = $all_domain_video_size + $this->getTheVideoContentSizeOfThisTask($task);
                $all_domain_zip_size = $all_domain_zip_size + $this->getTheZipFileContentSizeOfThisTask($task);
                $all_domain_image_size = $all_domain_image_size + $this->getTheTaskImageSize($task);
                $all_domain_image_size = $all_domain_image_size + $this->getThePosterImageSize($task);
            }
            $total_utilized_space = $all_domain_video_size + $all_domain_zip_size + $all_domain_image_size;
            
            return $total_utilized_space;
            
            
        }
        
        
        /**
         * This is the function that gets the size of a toolbox icon/image
         */
        public function getTheToolboxImageSize($toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$toolbox_id);
                 $image= Resourcegroup::model()->find($criteria);
                 
                 return $image['icon_size'];
            
        }
        
        
        /**
         * This is the function that gets  a tool's image size
         */
        public function getTheToolImageSize($tool_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$tool_id);
                 $image= Resources::model()->find($criteria);
                 
                 return $image['icon_size'];
            
        }
        
        
        /**
         * This is the function that gets the video size of a task
         */
        public function getTheVideoContentSizeOfThisTask($task_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$task_id);
                 $image= Resources::model()->find($criteria);
                 
                 return $image['video_size'];
            
        }
        
        /**
         * This is the function that gets the file size of the demo/zipped file of a task
         */
        public function getTheZipFileContentSizeOfThisTask($task_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$task_id);
                 $image= Resources::model()->find($criteria);
                 
                 return $image['demo_size'];
            
        }
        
        
        /**
         * This is the function that gets the imageicon size of a task
         * 
         */
        public function getTheTaskImageSize($task_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$task_id);
                 $image= Resources::model()->find($criteria);
                 
                 return $image['icon_size'];
            
        }
        
        
        /**
         * This is the function that gets the icon/image size of a task 
         */
        public function getThePosterImageSize($task_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$task_id);
                 $image= Resources::model()->find($criteria);
                 
                 return $image['poster_size'];
        }
        
        /**
         * This is the function that gets all domain toolboxes that could be used for space calculation 
         */
        public function getAllDomainToolboxesThatCouldBeIncludedInSpaceCalculation($domain_id){
            
            //get all the toolboxes owned by this domain
            $domain_toolboxes = $this->getAllToolboxesOwnByThisDomain($domain_id);
            
            $all_toolboxes = [];
            foreach($domain_toolboxes as $toolbox_id){
                //get the toolbox visibility
                $visibility = $this->getThisToolboxVisibility($toolbox_id);
                if($this->doesToolboxWithThisVisibilityContributeToThisDomainSpaceCalculation($domain_id,$visibility)){
                    $all_toolboxes[] = $toolbox_id;
                }
            }
            return $all_toolboxes;
        }
        
        
        
        /**
         * This is the function that gets all toolboxes own by this domain
         */
        public function getAllToolboxesOwnByThisDomain($domain_id){
            
            $domain_toolboxes = [];     
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='domain_id=:id';
                 $criteria->params = array(':id'=>$domain_id);
                 $toolboxes= Resourcegroup::model()->findAll($criteria);
                
                foreach($toolboxes as $toolbox){
                    $domain_toolboxes[] = $toolbox['id'];
                  
                }
            return $domain_toolboxes;
        }
        
        
        /**
         * This is the function that gets this toolbox visibility
         */
        public function getThisToolboxVisibility($toolbox_id){
                
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$toolbox_id);
                 $toolbox= Resourcegroup::model()->find($criteria);
                 
                 return $toolbox['visibility'];
        }
        
        /**
         * This is the function that determines if a visibility type adds to a domain's space calculation
         */
        public function doesToolboxWithThisVisibilityContributeToThisDomainSpaceCalculation($domain_id,$visibility){
            if($visibility == 'private'){
                if($this->doesPlatformPolicyRequirePrivateToolboxesToBePartOfSpaceCalculation()){
                   return true;
                }else{
                    return false;
                }
            }else if($visibility == 'restricted_public'){
                if($this->doesPlatformPolicyRequireRestrictedPublicToolboxesToBePartOfSpaceCalculation()){
                   return true;
                }else{
                    return false;
                }
            }else if($visibility == 'private & public'){
                if($this->doesPlatformPolicyRequirePrivateAndPublicToolboxesToBePartOfSpaceCalculation()){
                   return true;
                }else{
                    return false;
                }
            }else if($visibility == 'private & restricted_public'){
                if($this->doesPlatformPolicyRequirePrivateAndRestrictedPublicToolboxesToBePartOfSpaceCalculation()){
                   return true;
                }else{
                    return false;
                }
            }else if($visibility == 'reserved'){
                if($this->doesPlatformPolicyRequireReservedToolboxesToBePartOfSpaceCalculation()){
                   return true;
                }else{
                    return false;
                }
            }else if($visibility == 'public'){
                //confirm if the domain's public toolboxes are exempted from space calculation
                if($this->isDomainPublicToolboxesExemptedFromSpaceCalculations($domain_id)){
                    return false;
                }else{
                 if($this->doesPlatformPolicyRequirePublicToolboxesToBePartOfSpaceCalculation()){
                    return true;
                }else{
                    return false;
                }
                }
            }
            
        }
        
        
	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate()
	{
            
            //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the platform base currency
            $base_currency = $this->getThePlatformBaseCurrency();
            // Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                $model=Resourcegroup::model()->findByPk($_id);
		$model->name = $_POST['name'];
                if(isset($_POST['box_number'])){
                   $model->box_number = $_POST['box_number'];
               }
                 $model->visibility = $_POST['visibility'];
                if(isset($_POST['description'])){
                    $model->description = $_POST['description'];
                }
                if(isset($_POST['price'])){
                    if($base_currency == $preferred_currency){
                         $model->price = $_POST['price'];
                    }else{
                        //retrieve the exchange rate of the preferred currency
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $dollar_value = ((double)$_POST['price'])/((double)$exchange_rate);
                        $model->price = $dollar_value;
                    }
                
                }
                if(isset($_POST['min_subscription_required'])){
                    $model->min_subscription_required = $_POST['min_subscription_required'];
                }else{
                    $model->min_subscription_required = 1;
                }
                if(isset($_POST['min_discountable_number'])){
                    $model->min_discountable_number = $_POST['min_discountable_number'];
                }else{
                    $model->min_discountable_number = 0;
                }
                if(isset($_POST['enforce_min_discountable_number'])){
                    $model->enforce_min_discountable_number = $_POST['enforce_min_discountable_number'];
                }else{
                    $model->enforce_min_discountable_number = 0;
                }
                if(isset($_POST['discount_rate'])){
                     $model->discount_rate = $_POST['discount_rate'];
                }
            
               if(isset($_POST['duplicate'])){
                    $model->duplicate = $_POST['duplicate'];
               }else{
                   $model->duplicate=0;
               }
               if(isset($_POST['reconstruct_toolbox'])){
                    $model->reconstruct_toolbox = $_POST['reconstruct_toolbox'];
               }else{
                   $model->reconstruct_toolbox = 0;
               }
               if(isset($_POST['cumulative_component_price'])){
                   $model->cumulative_component_price = $_POST['cumulative_component_price'];
               }else{
                   $model->cumulative_component_price = 0;
               }
               if(isset($_POST['discount_proof'])){
                   $model->discount_proof = $_POST['discount_proof'];
               }else{
                   $model->discount_proof = 0;
               } 
               if(isset($_POST['price_preference'])){
                   $model->price_preference = $_POST['price_preference'];
               }else{
                   $model->price_preference = 0;
               }
               if(isset($_POST['storage_location'])){
                   $model->storage_location = $_POST['storage_location'];
               }
               if(isset($_POST['storage_room'])){
                   $model->storage_room = $_POST['storage_room'];
               }
               if(isset($_POST['rack_number'])){
                   $model->rack_number = $_POST['rack_number'];
               }
              
            $model->closed_status = $this->getTheClosedStatusOfThisBox($_id);
            $model->max_file_at_closure = $_POST['max_file_at_closure'];
            $model->min_file_at_closure = $_POST['min_file_at_closure'];
             if(isset($_POST['is_closeable'])){
                $model->is_closeable = $_POST['is_closeable'];
            }else{
                $model->is_closeable = 0;
                        
            }
            if(isset($_POST['could_be_reopened'])){
                $model->could_be_reopened = $_POST['could_be_reopened'];
            }else{
                $model->could_be_reopened = 0;
                        
            }
            if(isset($_POST['could_be_reopened_when_max_number_not_reached'])){
                $model->could_be_reopened_when_max_number_not_reached = $_POST['could_be_reopened_when_max_number_not_reached'];
            }else{
                $model->could_be_reopened_when_max_number_not_reached = 0;
                        
            }
            if(isset($_POST['overide_external_influence_on_parameters'])){
                $model->overide_external_influence_on_parameters = $_POST['overide_external_influence_on_parameters'];
            }else{
                $model->overide_external_influence_on_parameters = 0;
                        
            }
            if(isset($_POST['accept_only_unique_batches'])){
                $model->accept_only_unique_batches = $_POST['accept_only_unique_batches'];
            }else{
                $model->accept_only_unique_batches = 0;
                        
            }
             if(isset($_POST['batches_from_these_document_types'])){
                $model->batches_from_these_document_types = $_POST['batches_from_these_document_types'];
            }else{
                $model->batches_from_these_document_types = 0;
                        
            }
             if(isset($_POST['batches_from_these_document_categories'])){
                $model->batches_from_these_document_categories = $_POST['batches_from_these_document_categories'];
            }else{
                $model->batches_from_these_document_categories = 0;
                        
            }
            if(isset($_POST['batches_from_own_domain'])){
                $model->batches_from_own_domain = $_POST['batches_from_own_domain'];
            }else{
                $model->batches_from_own_domain = 0;
                        
            }
            if(isset($_POST['batches_from_these_processors'])){
                $model->batches_from_these_processors = $_POST['batches_from_these_processors'];
            }else{
                $model->batches_from_these_processors = 0;
                        
            }
            if(isset($_POST['batches_from_these_domain_neighbourhoods'])){
                $model->batches_from_these_domain_neighbourhoods = $_POST['batches_from_these_domain_neighbourhoods'];
            }else{
                $model->batches_from_these_domain_neighbourhoods = 0;
                        
            }
            if(isset($_POST['batches_from_these_clusters'])){
                $model->batches_from_these_clusters = $_POST['batches_from_these_clusters'];
            }else{
                $model->batches_from_these_clusters = 0;
                        
            }
             if(isset($_POST['consummable_at_request'])){
                $model->consummable_at_request = $_POST['consummable_at_request'];
            }else{
                $model->consummable_at_request = 0;
                        
            }
             if(isset($_POST['consummable_by_hood_members'])){
                $model->consummable_by_hood_members = $_POST['consummable_by_hood_members'];
            }else{
                $model->consummable_by_hood_members = 0;
                        
            }
             if(isset($_POST['consummable_by_hood_cluster_members'])){
                $model->consummable_by_hood_cluster_members = $_POST['consummable_by_hood_cluster_members'];
            }else{
                $model->consummable_by_hood_cluster_members = 0;
                        
            }
             if(isset($_POST['could_be_requested_by_all'])){
                $model->could_be_requested_by_all = $_POST['could_be_requested_by_all'];
            }else{
                $model->could_be_requested_by_all = 0;
                        
            }
             if(isset($_POST['could_be_requested_by_hood_members'])){
                $model->could_be_requested_by_hood_members = $_POST['could_be_requested_by_hood_members'];
            }else{
                $model->could_be_requested_by_hood_members = 0;
                        
            }
            if(isset($_POST['could_be_requested_by_hood_cluster_members'])){
                $model->could_be_requested_by_hood_cluster_members = $_POST['could_be_requested_by_hood_cluster_members'];
            }else{
                $model->could_be_requested_by_hood_cluster_members = 0;
                        
            }
            if(isset($_POST['default_to_domain_conflict_resolution_preference'])){
                $model->default_to_domain_conflict_resolution_preference = $_POST['default_to_domain_conflict_resolution_preference'];
            }else{
                $model->default_to_domain_conflict_resolution_preference = 0;
                        
            }
           if(isset($_POST['prefer_whitelist_over_blacklist'])){
                $model->prefer_whitelist_over_blacklist = $_POST['prefer_whitelist_over_blacklist'];
            }else{
                $model->prefer_whitelist_over_blacklist = 0;
                        
            }
            if(isset($_POST['prefer_blacklist_over_whitelist'])){
                $model->prefer_blacklist_over_whitelist = $_POST['prefer_blacklist_over_whitelist'];
            }else{
                $model->prefer_blacklist_over_whitelist = 0;
                        
            }
            if(isset($_POST['effect_blacklist_on_box'])){
                $model->effect_blacklist_on_box = $_POST['effect_blacklist_on_box'];
            }else{
                $model->effect_blacklist_on_box = 0;
                        
            }
            if(isset($_POST['effect_whitelist_on_box'])){
                $model->effect_whitelist_on_box = $_POST['effect_whitelist_on_box'];
            }else{
                $model->effect_whitelist_on_box = 0;
                        
            }
            $model->purpose =strtolower($_POST['purpose']);
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                $model->domain_id = $domain_id;
                $model->is_document_initiated_or_updated = 1;
                $model->is_storage_confirmed_by_domain_verifier = 0;
                $model->is_storage_checked_by_platform_checker = 0;
                $model->is_storage_verified_by_platform_verifier = 0;
                $model->is_box_in_storage = 0;
                 
                 //get the toolbox name
                 $toolbox_name = $this->getTheToolboxName($_id);
              if($this->isDomainSpaceAvailableForThisToolbox($model->domain_id,$model->visibility)){
                  
                  $icon_error_counter = 0;          
                //$icon = $_FILES['icon']['name'];
                //$this->createOrUpdateAGroupForResource($model, $icon=null);
                
                if($_FILES['icon']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal($domain_id)){
                        
                       $icon_filename = $_FILES['icon']['name'];
                       $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    //$model->icon = $this->retrieveThePreviousIconName($_id);
                    $icon_filename = $this->retrieveThePreviousIconName($_id);
                    $icon_size = $this->retrieveThePrreviousIconSize($_id);
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           $model->icon_size = $icon_size;
                           
                       if($model->save()) {
                        
                                $msg = "'$toolbox_name' folder information was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$toolbox_name' folder information update was not successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your icon file type or size as icon must be of width '$platform_width'px and height '$platform_height'px. Icon type is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
                  
              }else{
                  $msg = "This domain has run out of space capacity, you either delete some resources or contact the Customer Service Centre for some additional spaces";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() != 0,
                             "msg" => $msg)
                       );
              }    
                
                
	}

        /**
         * This is the function that will save the original domain id of a toolbox
         */
        public function saveTheOriginalDomainOwner($toolboxid){
            $cmd =Yii::app()->db->createCommand();   
            
            if($this->isOriginal($toolboxid)){
                $result = $cmd->update('resourcegroup',
                       array('original_toolbox_id'=>$toolboxid),
                       "id = $toolboxid"
                );
            
            if($result>0){
                return true;
            }else{
                return false;
            } 
                
            }
            return false;
           
            
            
        }
        
        /**
         * This is the function that gets the closed status of a  box
         */
        public function getTheClosedStatusOfThisBox($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $box= Resourcegroup::model()->find($criteria);
            
            return $box['closed_status'];
            
        }
        
        /**
         * This is the function that determines if a toolbox is not a duplicate
         */
        public function isOriginal($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $duplicate= Resourcegroup::model()->find($criteria);
            
            if($duplicate['is_duplicate'] == 0){
                return true;
            }else{
                return false;
            }
        }
        
	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneResourceGroup()
	{
            //delete a resource group
            $_id = $_POST['id'];
            $model=Resourcegroup::model()->findByPk($_id);
            
            //get the group name 
            $groupname = $this->getTheToolboxName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$groupname' was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
             }
	}

        
        /**
         * This is the function that will get the name of the toolbox/resourcegroup
         */
        public function getTheToolboxName($toolbox_id){
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolbox_id);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
        }
        
        
        
	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Resourcegroup');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionListAllResourceGroups_old()
	{
		
            $userid = Yii::app()->user->id;
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") ||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin") ){
            $group = Resourcegroup::model()->findAll();
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                }
            }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") ||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin")){
                //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id of the usertype
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
                
                //obtain all the users that created or updated a resourcegroup
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $allresourcegroup= Resourcegroup::model()->findAll($criteria5);
                
                $group = [];
                
                foreach($allresourcegroup as $resourcegroup){
                    //test the usertype of the user that created or updated the resourcegroup
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$resourcegroup->create_user_id, ':userid'=>$resourcegroup->update_user_id);
                    $usertype= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertype->usertype_id){
                            $criteria7 = new CDbCriteria();
                            $criteria7->select = '*';
                            $criteria7->condition='create_user_id=:id OR update_user_id=:userid';
                            $criteria7->params = array(':id'=>$resourcegroup->create_user_id, ':userid'=>$resourcegroup->update_user_id);
                            $allgroup= Resourcegroup::model()->findAll($criteria7);
                            
                            $group = array_merge($group, $allgroup);
                        
                        
                        
                    }
                    
                    
                }
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                } 
                
                
                
            }else{
                //spool all the resourcegroup that was created or updated by the user
                $criteria2 = new CDbCriteria();
                $criteria2->select = '*';
                $criteria2->condition='create_user_id=:id OR update_user_id=:userid';
                $criteria2->params = array(':id'=>$userid, ':userid'=>$userid);
                $group= Resourcegroup::model()->findAll($criteria2);
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                } 
                
            } 
	}
        
        
        
        /**
	 * Manages all models.
	 */
	public function actionListAllResourceGroups()
	{
		
            $userid = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")){
                $group = Resourcegroup::model()->findAll();
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                }
                
            }else{
                 //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:domainid and (visibility=:visibility or visibility=:visible)'; 
                $criteria->params = array(':domainid'=>$domain_id, ':visibility'=>"private",':visible'=>"private & restricted_public");
                $group= Resourcegroup::model()->findAll($criteria);
           
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                }
                
            }
            
            
	}
        
        
         /**
	 * Manages all models.
	 */
	public function actionListAllDomainsToolboxes()
	{
		
            $userid = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
             //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
               // $criteria->condition='domain_id=:domainid and visibility=:visibility'; 
                //$criteria->params = array(':domainid'=>$domain_id, ':visibility'=>"private");
                $group= Resourcegroup::model()->findAll($criteria);
           
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                }
            
	}
        
        
        
        /**
	 * Manages all models.
	 */
	public function actionAllToolboxesBelongingToADomain()
	{
		
            $userid = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")){
                //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
               //$criteria->condition='domain_id=:domainid'; 
                //$criteria->params = array(':domainid'=>$domain_id);
                $group= Resourcegroup::model()->findAll($criteria);
           
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                }
                
            }else{
                //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
               $criteria->condition='domain_id=:domainid'; 
                $criteria->params = array(':domainid'=>$domain_id);
                $group= Resourcegroup::model()->findAll($criteria);
           
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                }
                
            } 
            
            
	}
        
        
        /**
	 * Manages all models.
	 */
	public function actionAllToolboxesAssignedToDomain()
	{
		
            $userid = Yii::app()->user->id;
            
             if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformResourcesAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformResourceSupport")){ 
                 
                  //$domain_id = $this->determineAUserDomainIdGiven($userid);
            
            
            //retrieve all toolboxes assigned to this domain
            $all_toolboxes = [];
            $toolboxes = $this->retrieveAllToolboxesAssignedToAllDomain();
            
            foreach($toolboxes as $toolbox){
                
                 //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id'; 
                $criteria->params = array(':id'=>$toolbox);
                $group= Resourcegroup::model()->find($criteria);
                
                $all_toolboxes[] = $group;
                
            }
            
            
            
           
                if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($all_toolboxes);
                       
                }
                 
             }else{
                  $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            
            //retrieve all toolboxes assigned to this domain
            $all_toolboxes = [];
            $toolboxes = $this->retrieveAllToolboxesAssignedToThisDomain($domain_id);
            
            foreach($toolboxes as $toolbox){
                
                 //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id'; 
                $criteria->params = array(':id'=>$toolbox);
                $group= Resourcegroup::model()->find($criteria);
                
                $all_toolboxes[] = $group;
                
            }
            
            
            
           
                if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($all_toolboxes);
                       
                }
                 
             }
            
           
            
	}
        
        /**
         * This is the function that retrieves the ative toolboxes assigned to a domain
         */
        public function retrieveAllToolboxesAssignedToThisDomain($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='category_id=:id and toolbox_status=:status';
             $criteria->params = array(':id'=>$domain_id,':status'=>"active");
             $toolboxes = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
             
             $all_toolboxes = [];
             foreach($toolboxes as $toolbox){
                 $all_toolboxes[] = $toolbox['resourcegroup_id'];
             }
            
            return $all_toolboxes;
        }
        
        
        /**
         * This is the function that retrieves all toolboxes assigned to all domain
         */
        public function retrieveAllToolboxesAssignedToAllDomain(){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='toolbox_status=:status';
             $criteria->params = array(':status'=>"active");
             $toolboxes = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
             
             $all_toolboxes = [];
             foreach($toolboxes as $toolbox){
                 $all_toolboxes[] = $toolbox['resourcegroup_id'];
             }
            
            return $all_toolboxes;
            
        }
        
        
        /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup category assignment table
         */
        public function actionListResourceGroupForCategoryAssigment()
	{
		
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $result = ResourceGroup::model()->findAll($criteria);   
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"total" => $total,
                            "data" => $result)
                       );
                }  
         }     
         
         /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * resourcegroup category assignment update
          */
         public function actionListResourceGroupForCategoryAssignmentUpdate_old()
	{
		
              $_id = $_REQUEST['category_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = ResourceGroup::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'category_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='category_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria2);
            
                        
             $criteria8 = new CDbCriteria();
             $criteria8->select = 'id, name';
             $category = ResourceGroupCategory::model()->findAll($criteria8);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "category" => $category  
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin")){
                         
             $criteria9 = new CDbCriteria();
             $criteria9->select = 'category_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria9->condition='category_id=:id';
             $criteria9->params = array(':id'=>$_id);
             $selected = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria9);
            
                        
             $criteria10 = new CDbCriteria();
             $criteria10->select = 'id, name';
             $category = ResourceGroupCategory::model()->findAll($criteria10);   
                


                //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resourcegroup
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resourcegroup= Resourcegroup::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resourcegroup as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resourcegroup::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id';
                    $criteria13->params = array(':id'=>$resid);
                    $result2= Resourcegroup::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $domain_result,
                            "category" =>$category,
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'category_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria12->condition='category_id=:id';
             $criteria12->params = array(':id'=>$_id);
             $selected = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria12);
            
                        
             $criteria13 = new CDbCriteria();
             $criteria13->select = 'id, name';
             $category = ResourceGroupCategory::model()->findAll($criteria13);   
               
               
               $criteria11 = new CDbCriteria();
               $criteria11->select = '*';
               $criteria11->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria11->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= Resourcegroup::model()->findAll($criteria11);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "category" => $category  
                       ));
                       
                } 
               
               
           }  
	}
        
        
        
        /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * resourcegroup category assignment update
          */
         public function actionListResourceGroupForCategoryAssignmentUpdate()
	{
		
              $_id = $_REQUEST['category_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
            
            $domain_id = $this->determineAUserDomainIdGiven($userid);
                       
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $criteria->condition='domain_id=:id and (visibility=:visibility or visibility=:visible)';
             $criteria->params = array(':id'=>$_id,':visibility'=>"private",':visible'=>"private & restricted_public");
             $result = ResourceGroup::model()->findAll($criteria);   
          
             //retrieve the open order by this user belonging to this domain
             $order_id = $this->getDomainOpenOrder($_id);
             
             //fetch all items in this cart
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='order_id=:id';
             $criteria2->params = array(':id'=>$order_id);
             $selected = OrderHasToolboxes::model()->findAll($criteria2);
                        
             $criteria8 = new CDbCriteria();
             $criteria8->select = 'id, name';
             $category = ResourceGroupCategory::model()->findAll($criteria8);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "category" => $category  
                       ));
                       
                }
                
           
         
	}
        
        
        
        
        /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * group assignment
         */
        public function actionListResourcegroupForGroupAssigment()
	{
		
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $result = ResourceGroup::model()->findAll($criteria);   
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"total" => $total,
                            "data" => $result)
                       );
                }  
         }  
         
         
         
         /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * resourcegroup category assignment update
          */
         public function actionListResourceGroupForGroupAssignmentUpdate_old()
	{
		
               $_id = $_REQUEST['group_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = ResourceGroup::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'group_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='group_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = GroupHasResourcegroup::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $group = Group::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "group" => $group
                          // "resourcegroups"=>$resourcegroups
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")){
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'group_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='group_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = GroupHasResourcegroup::model()->findAll($criteria4);
            
                        
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, name';
             $group = Group::model()->findAll($criteria5);   
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated a resourcegroup
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resourcegroup= Resourcegroup::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resourcegroup as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resourcegroup::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria11 = new CDbCriteria();
                    $criteria11->select = '*';
                    $criteria11->condition='id=:id';
                    $criteria11->params = array(':id'=>$resid);
                    $result2= Resourcegroup::model()->findAll($criteria11);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $domain_result,
                            "group" => $group
                          // "resourcegroups"=>$resourcegroups
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'group_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria12->condition='group_id=:id';
             $criteria12->params = array(':id'=>$_id);
             $selected = GroupHasResourcegroup::model()->findAll($criteria12);
            
                        
             $criteria13 = new CDbCriteria();
             $criteria13->select = 'id, name';
             $group = Group::model()->findAll($criteria13);   
               
               
               $criteria14 = new CDbCriteria();
               $criteria14->select = '*';
               $criteria14->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= Resourcegroup::model()->findAll($criteria14);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "group" => $group
                          // "resourcegroups"=>$resourcegroups
                           
                       ));
                       
                } 
               
               
           }  
	}
         
        
        
        
        /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * resourcegroup category assignment update
          */
         public function actionListResourceGroupForGroupAssignmentUpdate()
	{
		
               $_id = $_REQUEST['group_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;  
            
           // $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            //get the domain of this group
            $domain_id = $this->getTheDomainOfThisGroup($_id);
             
            $toolboxes = $this->retrieveAllToolboxesAssignedToThisDomain($domain_id);
            
            $all_toolboxes = [];
            foreach($toolboxes as $toolbox){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name,select_value';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox);
                $result = ResourceGroup::model()->find($criteria); 
                
                $all_toolboxes[] = $result;
                
            }
             
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'group_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='group_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = GroupHasResourcegroup::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $group = Group::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $all_toolboxes,
                            "group" => $group
                          // "resourcegroups"=>$resourcegroups
                       ));
                       
                }
                
           
	}
              
        
             
         
         /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * subgroup assignment 
          */
         public function actionListResourceGroupForSubgroupAssignmentUpdate_old()
	{
		
            $_id = $_REQUEST['subgroup_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = ResourceGroup::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'subgroup_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='subgroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = SubgroupHasResourcegroup::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "subgroup" => $subgroup  
                          // "resourcegroups"=>$resourcegroups
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")){
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'subgroup_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='subgroup_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = SubgroupHasResourcegroup::model()->findAll($criteria4);
            
                        
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria5);   
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated a resourcegroup
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resourcegroup= Resourcegroup::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resourcegroup as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resourcegroup::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria11 = new CDbCriteria();
                    $criteria11->select = '*';
                    $criteria11->condition='id=:id';
                    $criteria11->params = array(':id'=>$resid);
                    $result2= Resourcegroup::model()->findAll($criteria11);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $domain_result,
                            "subgroup" => $subgroup  
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'subgroup_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria12->condition='subgroup_id=:id';
             $criteria12->params = array(':id'=>$_id);
             $selected = SubgroupHasResourcegroup::model()->findAll($criteria12);
            
                        
             $criteria13 = new CDbCriteria();
             $criteria13->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria13);   
               
               
               $criteria14 = new CDbCriteria();
               $criteria14->select = '*';
               $criteria14->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= Resourcegroup::model()->findAll($criteria14);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "subgroup" => $subgroup  
                          // "resourcegroups"=>$resourcegroups
                           
                       ));
                       
                } 
               
               
           }  
	}
        
        
        
        /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * subgroup assignment 
          */
         public function actionListResourceGroupForSubgroupAssignmentUpdate()
	{
		
            $_id = $_REQUEST['subgroup_id'];
           //  $_id = 1;
           
             $userid = Yii::app()->user->id;   
             //$domain_id = $this->determineAUserDomainIdGiven($userid);
             
             //get the domain of this subgroup
             $domain_id = $this->getTheDomainOfThisSubgroup($_id);
             
             //retrieve all toolboxes assigned to a domain
             $toolboxes = $this->retrieveAllToolboxesAssignedToThisDomain($domain_id);
             
             $all_toolboxes = [];
             
             foreach($toolboxes as $toolbox){
                 $criteria = new CDbCriteria();
                 $criteria->select = 'id, name,select_value';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$toolbox);
                 $result = ResourceGroup::model()->find($criteria); 
                 $all_toolboxes[] = $result;
             }
             
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='subgroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = SubgroupHasResourcegroup::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $all_toolboxes,
                            "subgroup" => $subgroup  
                          // "resourcegroups"=>$resourcegroups
                       ));
                       
                }
                
           
	}
        
        /**
         * This is the function that gets the domain id of a subgroup
         
        public function getTheDomainOfThisSubgroup($subgroup_id){
            
            //get the group of the subgroup
            $group_id = $this->getTheGroupOfThisSubgroup($subgroup_id);
        }
         * 
         */
        
        
        
        
        /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * group assignment
         */
        public function actionListResourcegroupForSubgroupAssigment()
	{
		
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $result = ResourceGroup::model()->findAll($criteria);   
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"total" => $total,
                            "data" => $result)
                       );
                }  
         } 
         
         
         
         /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup category assignment table
         */
        public function actionListResourcesForResourcegroupAssigmentUpdate_old()
	{
		
             $_id = $_REQUEST['resourcegroup_id'];
            //$_id = 1;
             
                      
           
           $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $criteria->condition='parent_id is NULL';
             $result = Resources::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'resource_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='resourcegroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ResourceHasResourcegroups::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $group = Resourcegroup::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "resourcegroup" => $group  
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")){
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'resource_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='resourcegroup_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = ResourceHasResourcegroups::model()->findAll($criteria4);
            
                        
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, name';
             $group = Resourcegroup::model()->findAll($criteria5);   
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated a resource
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, name, create_user_id, update_user_id';
                $criteria8->condition='parent_id is NULL';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resources= Resources::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resources as $usergroup) {
                    
                      //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='(create_user_id=:id OR update_user_id=:userid) and parent_id is NULL';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resources::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id';
                    $criteria13->params = array(':id'=>$resid);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $domain_result,
                            "resourcegroup" => $group  
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria11 = new CDbCriteria();
             $criteria11->select = 'resource_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria11->condition='resourcegroup_id=:id';
             $criteria11->params = array(':id'=>$_id);
             $selected = ResourceHasResourcegroups::model()->findAll($criteria11);
            
                        
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'id, name';
             $group = Resourcegroup::model()->findAll($criteria12);   
               
               
             $criteria14 = new CDbCriteria();
             $criteria14->select = '*';
             $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and parent_id is NULL';
             $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
             $result= Resources::model()->findAll($criteria14); 
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "resourcegroup" => $group  
                           
                       ));
                       
                } 
               
               
           }  
         } 
         
         
         
         /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup category assignment table
         */
        public function actionListResourcesForResourcegroupAssigmentUpdate()
	{
		
             $_id = $_REQUEST['resourcegroup_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this toolbox
             $domain_id = $this->getTheDomainOfThisToolbox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $criteria->condition='parent_id is NULL and domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='resourcegroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ResourceHasResourcegroups::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $group = Resourcegroup::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "resourcegroup" => $group  
                       ));
                       
                }
                
           
         } 
         
         /**
          * This is the function that gets the domain of a toolbox
          */
         public function getTheDomainOfThisToolbox($toolbox_id){
             
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox_id);
                $domain = Resourcegroup::model()->find($criteria);
                
                return $domain['domain_id'];
         }
         
         
          /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * subgroup assignment 
          */
         public function actionListResourceGroupForUserAssignmentUpdate_old()
	{
		
             $_id = $_REQUEST['user_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = ResourceGroup::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasResourcegroup::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, email, username';
             $user = User::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "user" => $user  
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")){
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'user_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='user_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = UserHasResourcegroup::model()->findAll($criteria4);
            
                        
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, email, username';
             $user = User::model()->findAll($criteria5);   
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated a resourcegroup
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resourcegroup= Resourcegroup::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resourcegroup as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resourcegroup::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria11 = new CDbCriteria();
                    $criteria11->select = '*';
                    $criteria11->condition='id=:id';
                    $criteria11->params = array(':id'=>$resid);
                    $result2= Resourcegroup::model()->findAll($criteria11);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $domain_result,
                            "user" => $user  
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria11 = new CDbCriteria();
             $criteria11->select = 'user_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria11->condition='user_id=:id';
             $criteria11->params = array(':id'=>$_id);
             $selected = UserHasResourcegroup::model()->findAll($criteria11);
            
                        
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'id, email, username';
             $user = User::model()->findAll($criteria12);   
               
               
               $criteria14 = new CDbCriteria();
               $criteria14->select = '*';
               $criteria14->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= Resourcegroup::model()->findAll($criteria14);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "user" => $user  
                          // "resourcegroups"=>$resourcegroups
                           
                       ));
                       
                } 
               
               
           }  
	}
        
        
        
        /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * subgroup assignment 
          */
         public function actionListResourceGroupForUserAssignmentUpdate()
	{
		
             $_id = $_REQUEST['user_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
                   
            //$domain_id = $this->determineAUserDomainIdGiven($userid);
            
            //get the domain of the user
            $domain_id = $this->determineAUserDomainIdGiven($_id);
                       
             //retrieve all toolboxes assigned to a domain
            $all_toolboxes = [];
             $toolboxes = $this->retrieveAllToolboxesAssignedToThisDomain($domain_id);
             
             $all_toolboxes = [];
             
             foreach($toolboxes as $toolbox){
                 $criteria = new CDbCriteria();
                 $criteria->select = 'id, name,select_value';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$toolbox);
                 $result = ResourceGroup::model()->find($criteria); 
                 $all_toolboxes[] = $result;
             }
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasResourcegroup::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, email, username';
             $user = User::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $all_toolboxes,
                            "user" => $user  
                       ));
                       
                }
                
           
	}
         
         /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForCategoryScheduling()
	{
		
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $result = ResourceGroup::model()->findAll($criteria);   
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"total" => $total,
                            "data" => $result)
                       );
                }  
         }  
         
         
         /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForCategoryBulkScheduling_old()
	{
		
             $_id = $_REQUEST['category_id'];
             //$_id = 1;
            
             $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = ResourceGroup::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'category_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='category_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $assigned = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria2);
            
            /**            
             $criteria8 = new CDbCriteria();
             $criteria8->select = 'id, name';
             $category = ResourceGroupCategory::model()->findAll($criteria8);  
             * 
             */ 
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $assigned,
                            "data" => $result
                           // "category" => $category  
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")){
                         
             $criteria9 = new CDbCriteria();
             $criteria9->select = 'category_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria9->condition='category_id=:id';
             $criteria9->params = array(':id'=>$_id);
             $assigned = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria9);
            
            /**            
             $criteria10 = new CDbCriteria();
             $criteria10->select = 'id, name';
             $category = ResourceGroupCategory::model()->findAll($criteria10);   
             * 
             */
                


                //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resourcegroup
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resourcegroup= Resourcegroup::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resourcegroup as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resourcegroup::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id';
                    $criteria13->params = array(':id'=>$resid);
                    $result2= Resourcegroup::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $assigned,
                            "data" => $domain_result
                           // "category" =>$category,
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'category_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria12->condition='category_id=:id';
             $criteria12->params = array(':id'=>$_id);
             $assigned = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria12);
            
            /**            
             $criteria13 = new CDbCriteria();
             $criteria13->select = 'id, name';
             $category = ResourceGroupCategory::model()->findAll($criteria13);   
             * 
             */
               
               
               $criteria11 = new CDbCriteria();
               $criteria11->select = '*';
               $criteria11->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria11->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= Resourcegroup::model()->findAll($criteria11);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $assigned,
                            "data" => $result
                           // "category" => $category  
                       ));
                       
                } 
               
               
           }  
	} 
        
        
        
        /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForCategoryBulkScheduling()
	{
		
             $_id = $_REQUEST['category_id'];
             //$_id = 1;
            
             $userid = Yii::app()->user->id;   
             $domain_id = $this->determineAUserDomainIdGiven($userid);
             
             
            //retrieve all toolboxes assigned to this group
            $toolboxes = $this->retrieveAllToolboxesAssignedToThisDomain($_id);
            
            $all_toolboxes = [];
            
            foreach($toolboxes as $toolbox){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name,select_value';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox);
                $result = ResourceGroup::model()->find($criteria);
                
                $all_toolboxes[] = $result;
            }
             
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='category_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $assigned = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria2);
            
            /**            
             $criteria8 = new CDbCriteria();
             $criteria8->select = 'id, name';
             $category = ResourceGroupCategory::model()->findAll($criteria8);  
             * 
             */ 
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $assigned,
                            "data" => $all_toolboxes
                           // "category" => $category  
                       ));
                       
                }
                
           
	} 
         
         
         
          /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForGroupBulkScheduling_old()
	{
		
                $_id = $_REQUEST['group_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = ResourceGroup::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'group_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='group_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = GroupHasResourcegroup::model()->findAll($criteria2);
            
            /**            
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $group = Group::model()->findAll($criteria3);   
             * 
             */
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                           // "group" => $group
                          // "resourcegroups"=>$resourcegroups
                       ));
                       
                }
                
}elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")){
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'group_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='group_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = GroupHasResourcegroup::model()->findAll($criteria4);
            
            /**            
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, name';
             $group = Group::model()->findAll($criteria5); 
             * 
             */  
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated a resourcegroup
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resourcegroup= Resourcegroup::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resourcegroup as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resourcegroup::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria11 = new CDbCriteria();
                    $criteria11->select = '*';
                    $criteria11->condition='id=:id';
                    $criteria11->params = array(':id'=>$resid);
                    $result2= Resourcegroup::model()->findAll($criteria11);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $domain_result
                           //"group" => $group
                          // "resourcegroups"=>$resourcegroups
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'group_id, resourcegroup_id, assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria12->condition='group_id=:id';
             $criteria12->params = array(':id'=>$_id);
             $selected = GroupHasResourcegroup::model()->findAll($criteria12);
            
                        
             $criteria13 = new CDbCriteria();
             $criteria13->select = 'id, name';
             $group = Group::model()->findAll($criteria13);   
               
               
               $criteria14 = new CDbCriteria();
               $criteria14->select = '*';
               $criteria14->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= Resourcegroup::model()->findAll($criteria14);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                            //"group" => $group
                          // "resourcegroups"=>$resourcegroups
                           
                       ));
                       
                } 
               
               
           }  
	}
        
        
        
        
        
          /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForGroupBulkScheduling()
	{
		
                $_id = $_REQUEST['group_id'];
                $domain_id = $_REQUEST['domain_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           
            //$domain_id = $this->determineAUserDomainIdGiven($userid);
            
            //retrieve all toolboxes assigned to this group
            $toolboxes = $this->retrieveAllToolboxesAssignedToThisDomain($domain_id);
            
            $all_toolboxes = [];
            
            foreach($toolboxes as $toolbox){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name,select_value';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox);
                $result = ResourceGroup::model()->find($criteria);
                
                $all_toolboxes[] = $result;
            }
             
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='group_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = GroupHasResourcegroup::model()->findAll($criteria2);
            
            /**            
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $group = Group::model()->findAll($criteria3);   
             * 
             */
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $all_toolboxes
                           // "group" => $group
                          // "resourcegroups"=>$resourcegroups
                       ));
                       
                }
                

	}
         
     
         
          /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForSubgroupBulkScheduling_old()
	{
		
             $_id = $_REQUEST['subgroup_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = ResourceGroup::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'subgroup_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='subgroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = SubgroupHasResourcegroup::model()->findAll($criteria2);
            
            /**            
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria3)
             * ;   
             */
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result,
                            //"subgroup" => $subgroup  
                          // "resourcegroups"=>$resourcegroups
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")){
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'subgroup_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='subgroup_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = SubgroupHasResourcegroup::model()->findAll($criteria4);
            
           /**             
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria5);  
            * 
            */ 
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated a resourcegroup
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resourcegroup= Resourcegroup::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resourcegroup as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resourcegroup::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria11 = new CDbCriteria();
                    $criteria11->select = '*';
                    $criteria11->condition='id=:id';
                    $criteria11->params = array(':id'=>$resid);
                    $result2= Resourcegroup::model()->findAll($criteria11);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $domain_result
                           // "subgroup" => $subgroup  
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'subgroup_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria12->condition='subgroup_id=:id';
             $criteria12->params = array(':id'=>$_id);
             $selected = SubgroupHasResourcegroup::model()->findAll($criteria12);
            
           /**            
             $criteria13 = new CDbCriteria();
             $criteria13->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria13);   
            * 
            */
               
               
               $criteria14 = new CDbCriteria();
               $criteria14->select = '*';
               $criteria14->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= Resourcegroup::model()->findAll($criteria14);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                           // "subgroup" => $subgroup  
                          // "resourcegroups"=>$resourcegroups
                           
                       ));
                       
                } 
               
               
           }  
	}
         
         
        /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForSubgroupBulkScheduling()
	{
		
             $_id = $_REQUEST['subgroup_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           //$domain_id = $this->determineAUserDomainIdGiven($userid);
           
           //determine the domain of this subgroup
           $domain_id = $this->getTheDomainOfThisSubgroup($_id);
             //retrieve all toolboxes assigned to a domain
             $toolboxes = $this->retrieveAllToolboxesAssignedToThisDomain($domain_id);
             
             $all_toolboxes = [];
             
             foreach($toolboxes as $toolbox){
                 $criteria = new CDbCriteria();
                 $criteria->select = 'id, name,select_value';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$toolbox);
                 $result = ResourceGroup::model()->find($criteria); 
                 $all_toolboxes[] = $result;
             }
             
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='subgroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = SubgroupHasResourcegroup::model()->findAll($criteria2);
            
            /**            
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria3)
             * ;   
             */
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $all_toolboxes,
                            //"subgroup" => $subgroup  
                          // "resourcegroups"=>$resourcegroups
                       ));
                       
                }
                
            
	}
        
        
        
        
         /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForUserBulkScheduling_old()
	{
		
              $_id = $_REQUEST['user_id'];
           //  $_id = 1;
           
            $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = ResourceGroup::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasResourcegroup::model()->findAll($criteria2);
            
            /**            
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, email, username';
             $user = User::model()->findAll($criteria3);  
             * 
             */ 
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                            //"user" => $user  
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")){
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'user_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='user_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = UserHasResourcegroup::model()->findAll($criteria4);
            
            /**            
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, email, username';
             $user = User::model()->findAll($criteria5);   
             * 
             */
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated a resourcegroup
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, name, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resourcegroup= Resourcegroup::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resourcegroup as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resourcegroup::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria11 = new CDbCriteria();
                    $criteria11->select = '*';
                    $criteria11->condition='id=:id';
                    $criteria11->params = array(':id'=>$resid);
                    $result2= Resourcegroup::model()->findAll($criteria11);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $domain_result
                          //  "user" => $user  
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria11 = new CDbCriteria();
             $criteria11->select = 'user_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria11->condition='user_id=:id';
             $criteria11->params = array(':id'=>$_id);
             $selected = UserHasResourcegroup::model()->findAll($criteria11);
            
                        
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'id, email, username';
             $user = User::model()->findAll($criteria12);   
               
               
               $criteria14 = new CDbCriteria();
               $criteria14->select = '*';
               $criteria14->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= Resourcegroup::model()->findAll($criteria14);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                           // "user" => $user  
                          // "resourcegroups"=>$resourcegroups
                           
                       ));
                       
                } 
               
               
           }  
	}
        
        
        
        
        /**
         * listing all the resourcegroup items needed for the resourcegroup to 
         * resourcegroup  category scheduling
         */
        public function actionListResourcegroupForUserBulkScheduling()
	{
		
              $_id = $_REQUEST['user_id'];
              $domain_id = $_REQUEST['domain_id'];
           //  $_id = 1;
              
              //logged in user
              $userid = Yii::app()->user->id;
              
              //$domain_id = $this->determineAUserDomainIdGiven($userid);
           
                    
            
             //retrieve all toolboxes assigned to a domain
             $toolboxes = $this->retrieveAllToolboxesAssignedToThisDomain($domain_id);
             
             $all_toolboxes = [];
             
             foreach($toolboxes as $toolbox){
                 $criteria = new CDbCriteria();
                 $criteria->select = 'id, name,select_value';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$toolbox);
                 $result = ResourceGroup::model()->find($criteria); 
                 $all_toolboxes[] = $result;
             }
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasResourcegroup::model()->findAll($criteria2);
            
            /**            
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, email, username';
             $user = User::model()->findAll($criteria3);  
             * 
             */ 
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $all_toolboxes
                            //"user" => $user  
                       ));
                       
                }
                
           
	}
         
         
         
          /**
         * listing all the resources for resourcegroup scheduling 
         * 
         */
        public function actionListResourceForResourcegroupBulkScheduling_old()
	{
		
              $_id = $_REQUEST['resourcegroup_id'];
            //$_id = 1;
                      
           
           $userid = Yii::app()->user->id;   
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $criteria->condition='parent_id is NULL';
             $result = Resources::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'resource_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='resourcegroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ResourceHasResourcegroups::model()->findAll($criteria2);
            
             /**           
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $group = Resourcegroup::model()->findAll($criteria3); 
              * 
              */ 
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                           // "resourcegroup" => $group  
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin") ){
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'resource_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='resourcegroup_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = ResourceHasResourcegroups::model()->findAll($criteria4);
            
           /**             
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, name';
             $group = Resourcegroup::model()->findAll($criteria5); 
            * 
            */  
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated a resource
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, name, create_user_id, update_user_id';
                $criteria8->condition='parent_id is NULL';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $resources= Resources::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($resources as $usergroup) {
                    
                      //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid and parent_id is NULL';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= Resources::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $resourcegroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourcegroupid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id';
                    $criteria13->params = array(':id'=>$resid);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $domain_result
                           // "resourcegroup" => $group  
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria11 = new CDbCriteria();
             $criteria11->select = 'resource_id, resourcegroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria11->condition='resourcegroup_id=:id';
             $criteria11->params = array(':id'=>$_id);
             $selected = ResourceHasResourcegroups::model()->findAll($criteria11);
            
            /**            
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'id, name';
             $group = Resourcegroup::model()->findAll($criteria12);  
             * 
             */ 
               
               
             $criteria14 = new CDbCriteria();
             $criteria14->select = '*';
             $criteria14->condition='create_user_id=:id OR update_user_id=:userid and parent_id is NULL';
             $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
             $result= Resources::model()->findAll($criteria14); 
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                           // "resourcegroup" => $group  
                           
                       ));
                       
                } 
               
               
           }  
         } 
         
         
         
           /**
         * listing all the resources for resourcegroup scheduling 
         * 
         */
        public function actionListResourceForResourcegroupBulkScheduling()
	{
		
              $_id = $_REQUEST['resourcegroup_id'];
              $domain_id = $_REQUEST['domain_id'];
            //$_id = 1;
                      
           
           $userid = Yii::app()->user->id;   
           //$domain_id = $this->determineAUserDomainIdGiven($userid);
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $criteria->condition='parent_id is NULL and domain_id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='resourcegroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ResourceHasResourcegroups::model()->findAll($criteria2);
            
             /**           
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $group = Resourcegroup::model()->findAll($criteria3); 
              * 
              */ 
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                           // "resourcegroup" => $group  
                       ));
                       
                }
                
            
         } 
         
         
         
                
            
            /**
             * This is a function that confirms if a domain country has a store
             */
            public function isDomainCountryWithACountryStore($domain_id){
                $country_id = $this->getThisDomainCountryId($domain_id);
                if($this->isCountryWithStore($country_id)){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the funation that obtains a country is
             */
            public function getThisDomainCountryId($domain_id){
                    $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='id=:id';
                     $criteria->params = array(':id'=>$domain_id);
                     $domain= ResourceGroupCategory::model()->find($criteria);
                     
                     return $domain['country_id'];
            }
            
            
            /**
             * This is the function that determines if a country has store
             */
            public function isCountryWithStore($country_id){
                 $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('stores')
                    ->where("country_id = $country_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            }
            
            /**
             * This is the function that retrieves the store id of a country
             */
            public function getTheStoreIdOfThisCountry($country_id){
                    $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='country_id=:id';
                     $criteria->params = array(':id'=>$country_id);
                     $store= Stores::model()->find($criteria);
                     
                     return $store['id'];
                
            }
            
            /**
             * This is the function that gets the store id of a country
             */
            public function getTheStoreIdOfTheDomainCountry($domain_id){
                //get the country id
                $country_id = $this->getThisDomainCountryId($domain_id);
                $store_id = $this->getTheStoreIdOfThisCountry($country_id);
                
                return $store_id;
            }
            
            /**
             * This is the function that gets the platform default store is
             */
            public function getThePlatformDefaultStoreId(){
               
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='default_store=:default';
                     $criteria->params = array(':default'=>1);
                     $store= Stores::model()->find($criteria);
                     
                     return $store['id'];
                
                
            }
            
            /**
	 * Assign Resourcegroup To Groups.
	 * If assignment is successful, close the window else insist an assignment be done.
	 */
	public function actionAssignResourcegroupToGroup()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                                             
               //get the logged in user
                $user_id = Yii::app()->user->id;
                
                //get the domain of this user
                $domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                //get the name of the group
                $group_name = $this->getTheGroupName($_id);
                
                //get the domain of this group
                //$domain_id = $this->getTheDomainOfThisToolbox($_id);
                        
                 $cmd =Yii::app()->db->createCommand();   
                 if(isset($_POST['resourcegroup'])){
                     
                     foreach($_POST['resourcegroup'] as $toolbox_id){
                        
                            $selected_toolboxes[] = $toolbox_id;
                       
                        }  
                     //spool all the toolboxes already assigned to this toolbox
                    $existing_toolboxes = $this->alreadyAssignedToolboxesToThisGroup($_id);
                    $selected_toolboxes = [];
                          //get the array difference
                    $discarded_toolboxes = array_diff($existing_toolboxes,$selected_toolboxes);
                    
                    //delete all the toolboxes in $discarded_toolboxes array
                    foreach($discarded_toolboxes as $discarded){
                        
                        $this->removeThisToolboxFromThisGroup($discarded, $_id);
                    }
                     if (is_array($_POST['resourcegroup'])) {
                            foreach($_POST['resourcegroup'] as $value){  
                                //get the minimum subscription period for this toolbox in this domain
                                $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                //get the maximum subscription period for this toolbox in this domain
                                $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                //confirm that this toolbox service is not already assiged to this group
                                if($this->isToolboxNotAlreadyAssignedToThisGroup($_id, $value)){
                                   
                                    $cmd->insert('group_has_resourcegroup',
                                        array(
                                           'group_id'=>$_POST['id'],
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                           'resourcegroup_id'=>$value,
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id,
                                            'min_date'=>$min_date,
                                            'max_date'=>$max_date,
                                            'start_date'=>$min_date,
                                            'end_date'=>$max_date
                                              
                                        ));
                                        
                                    
                                }else{
                                    $group_id = $_POST['id'];
                                    $cmd->update('group_has_resourcegroup',
                                        array(
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                           'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id,
                                            'min_date'=>$min_date,
                                            'max_date'=>$max_date,
                                            'start_date'=>$min_date,
                                            'end_date'=>$max_date
                                              
                                        ),
                                       ("group_id=$group_id and resourcegroup_id=$value"));
                                    
                                    
                                }
                             }
                             
                       }else {
                           $value = $_POST['resourcegroup'];
                           //get the minimum subscription period for this toolbox in this domain
                           $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                           //get the maximum subscription period for this toolbox in this domain
                            $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                           if($this->isToolboxNotAlreadyAssignedToThisGroup($_id, $value)){
                               $cmd->insert('group_has_resourcegroup',
                                   array(
                                        'group_id'=>$_POST['id'],
                                        'assign_name'=>$_POST['assign_name'],
                                        'assign_description'=>$_POST['assign_description'],
                                        'resourcegroup_id'=>$value,
                                         'min_date'=>$min_date,
                                         'max_date'=>$max_date,
                                         'date_assigned'=>new CDbExpression('NOW()'),
                                         'assigned_by'=>Yii::app()->user->id,
                                         'start_date'=>$min_date,
                                         'end_date'=>$max_date
                                              
                                    ));
                               
                           }
                            
                           
                       }
                      
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>"Folders successfully assigned to the '$group_name' group/division"
                       ));
                        
                    } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Using this bulk module, you cannot effect or add zero number of folder service to a group. PLEASE USE THE SINGLE FOLDER TO GROUP ASSIGNMENT MODULE INTSTEAD'
                          )); 
                        
                    }
                       
                        
                 
              
            }
            
            
            
           
            /**
             * This is the function that removes all toolboxes from a group
             */
            public function removeAllToolboxesFromThisGroup($group_id){
                
                 
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('group_has_resourcegroup', 'group_id=:groupid ', array(':groupid'=>$group_id ));
            
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
         /**
	 * Assign Resourcegroup To Subgroups.
	 * If assignment is successful, close the window else insist an assignment to be done.
	 */
	public function actionAssignResourcegroupToSubgroup()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                
               
               //get the logged in user
                $user_id = Yii::app()->user->id;
                
                //get the subgroup name
                $subgroup_name = $this->getTheSubgroupName($_id);
                
                //get the domain of this user
                $domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                                 
               $cmd =Yii::app()->db->createCommand();   
                if(isset($_POST['resourcegroup'])){
                     //spool all the toolboxes already assigned to this toolbox
                    $existing_toolboxes = $this->alreadyAssignedToolboxesToThisSubgroup($_id);
                    $selected_toolboxes = [];
                    foreach($_POST['resourcegroup'] as $toolbox_id){
                        
                        $selected_toolboxes[] = $toolbox_id;
                        
                    }   
                    //get the array difference
                    $discarded_toolboxes = array_diff($existing_toolboxes,$selected_toolboxes);
                    
                    //delete all the toolboxes in $discarded_toolboxes array
                    foreach($discarded_toolboxes as $discarded){
                        
                        $this->removeThisToolboxFromThisSubgroup($discarded, $_id);
                    }
                           
                     if (is_array($_POST['resourcegroup'])) {
                            foreach($_POST['resourcegroup'] as $value){  
                                //get the minimum subscription period for this toolbox in this domain
                                $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                //get the maximum subscription period for this toolbox in this domain
                                $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                if($this->isToolboxNotAlreadyAssignedToThisSubgroup($_id, $value)){
                                    
                                     $cmd->insert('subgroup_has_resourcegroup',
                                        array(
                                           'subgroup_id'=>$_POST['id'],
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                           'resourcegroup_id'=>$value,
                                            'min_date'=>$min_date,
                                            'max_date'=>$max_date,
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id,
                                            'start_date'=>$min_date,
                                            'end_date'=>$max_date
                                              
                                        ));
                                      
                                }else{
                                     $subgroup_id = $_POST['id'];
                                    $cmd->update('subgroup_has_resourcegroup',
                                        array(
                                           'assign_description'=>$_POST['assign_description'],
                                            'assign_name'=>$_POST['assign_name'],
                                            'min_date'=>$min_date,
                                            'max_date'=>$max_date,
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id,
                                            'start_date'=>$min_date,
                                            'end_date'=>$max_date
                                              
                                        ),
                                       ("subgroup_id=$subgroup_id and resourcegroup_id=$value"));
                                    
                                   
                                }
                                   
                                    
                                } 
                               
                               
                             
                             
                       }else {
                           $value = $_POST['resourcegroup'];
                           //get the minimum subscription period for this toolbox in this domain
                                $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                //get the maximum subscription period for this toolbox in this domain
                                $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                if($this->isToolboxNotAlreadyAssignedToThisSubgroup($_id, $value)){
                                   $cmd->insert('subgroup_has_resourcegroup',
                                   array(
                                        'subgroup_id'=>$_POST['id'],
                                        'assign_name'=>$_POST['assign_name'],
                                        'assign_description'=>$_POST['assign_description'],
                                        'resourcegroup_id'=>$value,
                                        'min_date'=>$min_date,
                                        'max_date'=>$max_date,
                                        'date_assigned'=>new CDbExpression('NOW()'),
                                        'assigned_by'=>Yii::app()->user->id,
                                       'start_date'=>$min_date,
                                        'end_date'=>$max_date
                                              
                                    ));
                            
                                    
                                }    
                            
                       }
                      
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>"Folder successfully assigned to the '$subgroup_name' subgroup/department"
                       ));
                        
                    } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Using this bulk module, you cannot effect or add zero number of folder service to a subgroup. PLEASE USE THE SINGLE FOLDER TO SUBGROUP ASSIGNMENT MODULE INTSTEAD'
                          )); 
                        
                    }
                  
                          
                               
           
                    
            }
            
            
            
             /**
	 * Assign Resourcegroup To Users.
	 * If assignment is successful, close the window else insist an assignment to be done.
	 */
	public function actionAssignResourcegroupToUser()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                
               
                                             
               //get the logged in user
                $user_id = Yii::app()->user->id;
                
                
                //get the name of this user
                $user_name = $this->getTheUsername($_id);
                
                //get the domain of this user
                $domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                                  
                $cmd =Yii::app()->db->createCommand();
               
                if(isset($_POST['resourcegroup'])){
                    
                    //spool all the toolboxes already assigned to this toolbox
                    $existing_toolboxes = $this->alreadyAssignedToolboxesToThisUser($_id);
                    $selected_toolboxes = [];
                    foreach($_POST['resourcegroup'] as $toolbox_id){
                        
                        $selected_toolboxes[] = $toolbox_id;
                        
                    }   
                    //get the array difference
                    $discarded_toolboxes = array_diff($existing_toolboxes,$selected_toolboxes);
                    
                    //delete all the toolboxes in $discarded_toolboxes array
                    foreach($discarded_toolboxes as $discarded){
                        
                        $this->removeThisToolboxFromThisUser($discarded, $_id);
                    }
                           
                    if (is_array($_POST['resourcegroup'])) {
                            foreach($_POST['resourcegroup'] as $value){  
                                //get the minimum subscription period for this toolbox in this domain
                                $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                //get the maximum subscription period for this toolbox in this domain
                                $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                if($this->isToolboxNotAlreadyAssignedToThisUser($_id, $value)){
                                     $cmd->insert('user_has_resourcegroup',
                                        array(
                                           'user_id'=>$_POST['id'],
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                           'resourcegroup_id'=>$value,
                                            'min_date'=>$min_date,
                                            'max_date'=>$max_date,
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id,
                                            'start_date'=>$min_date,
                                            'end_date'=>$max_date
                                              
                                        ));
                                      
                                    
                                }else{
                                     $user_id = $_POST['id'];
                                    $cmd->update('user_has_resourcegroup',
                                        array(
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                           'min_date'=>$min_date,
                                            'max_date'=>$max_date,
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id,
                                            'start_date'=>$min_date,
                                            'end_date'=>$max_date
                                              
                                        ),
                                       ("user_id=$user_id and resourcegroup_id=$value"));
                                    
                 
                                }
                                  
                               
                             }
                             
                       }else {
                           $value = $_POST['resourcegroup'];
                           //get the minimum subscription period for this toolbox in this domain
                                $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                //get the maximum subscription period for this toolbox in this domain
                                $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($value,$domain_id);
                                if($this->isToolboxNotAlreadyAssignedToThisUser($_id, $value)){
                                    
                                     $cmd->insert('user_has_resourcegroup',
                                   array(
                                        'user_id'=>$_POST['id'],
                                        'assign_name'=>$_POST['assign_name'],
                                        'assign_description'=>$_POST['assign_description'],
                                        'resourcegroup_id'=>$value,
                                       'min_date'=>$min_date,
                                       'max_date'=>$max_date,
                                       'date_assigned'=>new CDbExpression('NOW()'),
                                       'assigned_by'=>Yii::app()->user->id,
                                       'start_date'=>$min_date,
                                       'end_date'=>$max_date
                                              
                                    ));
                                }
                          
                           
                       }
                      
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>"Folder(s) successfully assigned to  '$user_name'"
                       ));
                        
                    } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Using this bulk module, you cannot effect or add zero number of folder service to a user. PLEASE USE THE SINGLE FOLDER TO USER ASSIGNMENT MODULE INTSTEAD'
                          )); 
                        
                    }
                  
                          
                               
           
                    
            }
            
            
                     
            
            
       
            
         /**
	 * Schedule Resourcegroup To Category.
	 * If schedule is successful, close the window else insist on doing the a single item 
           * scheduling.
          * 
          */    
            
            public function actionScheduleSingleResourcegroupToCategory()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
               $excluded_days = [];
                $_id = $_POST['category_id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['subscription_min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['subscription_max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                $resourcegroup_id = $_POST['resourcegroup_id'];
               
                
                if(isset($_POST['sunday'])){
                    $excluded_days[] = $_POST['sunday'];
                }
                if(isset($_POST['monday'])){
                    $excluded_days[] = $_POST['monday'];
                }
                if(isset($_POST['tuesday'])){
                    $excluded_days[] = $_POST['tuesday'];
                }
                if(isset($_POST['wednesday'])){
                    $excluded_days[] = $_POST['wednesday'];
                }
                if(isset($_POST['thursday'])){
                    $excluded_days[] = $_POST['thursday'];
                }
                if(isset($_POST['friday'])){
                    $excluded_days[] = $_POST['friday'];
                }
                if(isset($_POST['saturday'])){
                    $excluded_days[] = $_POST['saturday'];
                }
                 //get the toolbox name
                 $toolboxname = $this->getToolboxName($resourcegroup_id);
                 
                 //get the domain name
                 $domainname = $this->determineDomainNameGivenItId($_id);
                 
                 
             
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();           
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                   if(($end_date <= $max_date) AND ($end_date >= $start_date)){                
                       //perform the assignment table update here
                       if($this->isTheVisibilityOfThisServicePermitted($resourcegroup_id)){
                            $cmd->update('resourcegroup_has_resourcegroupcategory',
                                    array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                    'end_date'=>$end_date),
					 "category_id = $_id and resourcegroup_id = $resourcegroup_id"
                                     );
                       }else{
                            $cmd->update('resourcegroup_has_resourcegroupcategory',
                                    array('start_date'=>$start_date,'end_date'=>$end_date),
					 "category_id = $_id and resourcegroup_id = $resourcegroup_id"
                                     );
                       }
                      
                      // if(isset($excluded_days)){
                         if(is_array($excluded_days) AND $excluded_days != NULL) {
                               $num = 0;
                               foreach($excluded_days as $value){
                                   if($value == 'Sunday' ) {
                                       $num = $num + 1;
                                        $cmd->update('resourcegroup_has_resourcegroupcategory',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "category_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                     );
                                   }elseif($value == 'Monday'){
                                       $num = $num + 2;
                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "category_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        );       
                                       
                                   }elseif($value == 'Tuesday'){
                                       $num = $num + 4;
                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "category_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   } elseif($value == 'Wednesday'){
                                       $num = $num + 8;
                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "category_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   }elseif($value == 'Thursday'){
                                       $num = $num + 16;
                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "category_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   } elseif($value == 'Friday'){
                                       $num = $num + 32;
                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "category_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                                                              
                                   }elseif($value == 'Saturday'){
                                       $num = $num + 64;
                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "category_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                   
                                       
                                   }
                                       
                                       
                                                
                                  
                                   
                               }
                                                                                          
                           }elseif($excluded_days == NULL){
                                      // $num = $num + 64;
                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                             array('excluded_days'=>NULL),
                                             "category_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                   
                                       
                       }
                     $msg ="'$toolboxname' sucessfully scheduled on '$domainname' domain ";     
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                       
                   }else {
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'End Date is out of range with the Time to Live period or it is less than the Start Date',
                            
                             
                          )); 
                       
                   }             
                    
                }else {
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Start Date is out of range with the Time To Live period or it is greater than the End Date'
                          )); 
                    
                    
                }
                
        }//end of single scheduling function   
        
        
        
        /**
	 * Schedule Resourcegroup To Category.
	 * If schedule is successful, close the window else insist on doing the a single item 
           * scheduling.
	 */
	public function actionScheduleBulkResourcegroupToCategory()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                //$min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
                //$max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d", strtotime($_POST['end_date']));
               
                $success_counter = 0;
                $failure_counter = 0;
                //$resourcegroup_id = $_POST['resourcegroup_id'];
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();   
                      if(isset($_POST['resourcegroup'])){
                            if(is_array($_POST['resourcegroup'])) {
                                 foreach($_POST['resourcegroup'] as $resourcegroup){
                                     //determine if the start date and the end date is permissible
                                     if($this->isStartDatePermissible($resourcegroup,$_id,$start_date) AND $this->isEndDatePermissible($resourcegroup,$_id,$end_date)){
                                         //save all the data into the database except the set the data type 
                                             $cmd->update('resourcegroup_has_resourcegroupcategory',
                                             array('start_date'=>$start_date,'end_date'=>$end_date),
                                             "category_id = $_id and resourcegroup_id = $resourcegroup"
                                             );
                                         $success_counter = $success_counter + 1;
                                     }
                                     
                                     //update table to save the excluded_days data into the database
                                     if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('resourcegroup_has_resourcegroupcategory',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('resourcegroup_has_resourcegroupcategory',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }//end of the excluded_days isset if statement
                             
                                }//end of the resourcegroup array  foreach statement
                                
                         
                            } else { //end of resourcegroup is_array if  statement
                                $resourcegroup = $_POST['resourcegroup'];
                               if($this->isStartDatePermissible($resourcegroup,$_id,$start_date) AND $this->isEndDatePermissible($resourcegroup,$_id,$end_date)){
                                    $cmd->update('resourcegroup_has_resourcegroupcategory',
                                             array('start_date'=>$start_date,'end_date'=>$end_date),
                                             "category_id = $_id and resourcegroup_id = $resourcegroup"
                                  );
                                   $success_counter = $success_counter + 1;
                               } 
                               
                                  if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('resourcegroup_has_resourcegroupcategory',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('resourcegroup_has_resourcegroupcategory',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('resourcegroup_has_resourcegroupcategory',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('resourcegroup_has_resourcegroupcategory',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "category_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }// end of the excluded_day isset statement for non-array resourcegroup
                                
                                
                            }//end of resourcegroup is_array if else  statement
                            $msg = "$success_counter'  folder service(s) were successfully scheduled'"; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() == 0,
                                     "msg"=>$msg
                             ));
                            
                    
                }else{
                    header('Content-Type: application/json');
                          echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() != 0,
                           "msg" => "Select at least one item in the folder to schedule"   
                      ));
                    
                    
                }//end of resourcegroup isset if-else statement 
                        
                        
                        
        
          
        }//end of bulk resourcegroup to category scheduling function      
                                             
                
         
        /**
         * This is the function that determines if a start date is permissible for a toolbox scheduling
         */
        public function isStartDatePermissible($toolbox_id,$domain_id,$start_date){
            //retrieve the min date for this service to this domain
            
            $min_date = $this->getTheMinDate($toolbox_id,$domain_id);
            if(($start_date >= $min_date)){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that determine if an end date is permissible for a toolbox scheduling
         */
        public function isEndDatePermissible($toolbox_id,$domain_id,$end_date){
            
            //get the max date for this service to this domain
            $max_date = $this->getTheMaxDate($toolbox_id,$domain_id);
            
            if(($end_date <= $max_date)){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that gets the min date for this toolbox service to this domain
         */
        public function getTheMinDate($toolbox_id,$domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='category_id=:domainid and resourcegroup_id=:groupid';
            $criteria->params = array(':domainid'=>$domain_id, ':groupid'=>$toolbox_id);
            $date = ResourcegroupHasResourcegroupcategory::model()->find($criteria);
            
            return $date['min_date'];
        }
        
        
        /**
         * This is the function that gets the max date for this toolbox service to this domain
         */
        public function getTheMaxDate($toolbox_id,$domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='category_id=:domainid and resourcegroup_id=:groupid';
            $criteria->params = array(':domainid'=>$domain_id, ':groupid'=>$toolbox_id);
            $date = ResourcegroupHasResourcegroupcategory::model()->find($criteria);
            
            return $date['max_date'];
        }
        
        
        /**
	 * Schedule Resourcegroup To Group.
	 * If schedule is successful, close the window else insist on doing the single item 
           * scheduling.
	 */
	public function actionScheduleSingleResourcegroupToGroup()
	{
		//$model=new GroupHasResourcegroup;

				// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $excluded_days = [];
                $_id = $_POST['group_id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['subscription_min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['subscription_max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                $resourcegroup_id = $_POST['resourcegroup_id'];
               
                
                if(isset($_POST['sunday'])){
                    $excluded_days[] = $_POST['sunday'];
                }
                if(isset($_POST['monday'])){
                    $excluded_days[] = $_POST['monday'];
                }
                if(isset($_POST['tuesday'])){
                    $excluded_days[] = $_POST['tuesday'];
                }
                if(isset($_POST['wednesday'])){
                    $excluded_days[] = $_POST['wednesday'];
                }
                if(isset($_POST['thursday'])){
                    $excluded_days[] = $_POST['thursday'];
                }
                if(isset($_POST['friday'])){
                    $excluded_days[] = $_POST['friday'];
                }
                if(isset($_POST['saturday'])){
                    $excluded_days[] = $_POST['saturday'];
                }
                 
                
                //get the toolbox name
                 $toolboxname = $this->getToolboxName($resourcegroup_id);
                 
                 //get the domain name
                 $groupname = $this->getTheGroupName($_id);
                         
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();           
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                   if(($end_date <= $max_date) AND ($end_date >= $start_date)){                
                       //perform the assignment table update here
                       if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup_id)){
                           $cmd->update('group_has_resourcegroup',
                                    array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                    'end_date'=>$end_date),
					 "group_id = $_id and resourcegroup_id = $resourcegroup_id"
                                     );
                           
                       }else{
                           $cmd->update('group_has_resourcegroup',
                                    array('start_date'=>$start_date,'end_date'=>$end_date),
					 "group_id = $_id and resourcegroup_id = $resourcegroup_id"
                                     );
                       } 
                       
                      // if(isset($excluded_days)){
                         if(is_array($excluded_days) AND $excluded_days != NULL) {
                               $num = 0;
                               foreach($excluded_days as $value){
                                   if($value == 'Sunday' ) {
                                       $num = $num + 1;
                                        $cmd->update('group_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "group_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                     );
                                   }elseif($value == 'Monday'){
                                       $num = $num + 2;
                                       $cmd->update('group_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "group_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        );       
                                       
                                   }elseif($value == 'Tuesday'){
                                       $num = $num + 4;
                                       $cmd->update('group_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "group_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   } elseif($value == 'Wednesday'){
                                       $num = $num + 8;
                                       $cmd->update('group_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "group_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   }elseif($value == 'Thursday'){
                                       $num = $num + 16;
                                       $cmd->update('group_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "group_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   } elseif($value == 'Friday'){
                                       $num = $num + 32;
                                       $cmd->update('group_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "group_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                                                              
                                   }elseif($value == 'Saturday'){
                                       $num = $num + 64;
                                       $cmd->update('group_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "group_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                   
                                       
                                   }
                                       
                                       
                                                
                                  
                                   
                               }
                                                                                          
                           }elseif($excluded_days == NULL){
                                      // $num = $num + 64;
                                       $cmd->update('group_has_resourcegroup',
                                             array('excluded_days'=>NULL),
                                             "group_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                   
                                       
                       }
                     $msg = "'$toolboxname' folder service is successfully scheduled on the '$groupname' group";      
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                       
                   }else {
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'End Date is out of range with the subscription period or it is less than the Start Date'
                          )); 
                       
                   }             
                    
                }else {
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Start Date is out of range with the subscription period or it is greater than the End Date'
                          )); 
                    
                    
                }
                
  
                
        }//end of single scheduling function   
        
        
        /**
	 * Schedule Resourcegroup To Subgroup.
	 * If schedule is successful, close the window else insist on doing the single item 
           * scheduling.
	 */
	public function actionScheduleSingleResourcegroupToSubgroup()
	{
		//$model=new SubgroupHasResourcegroup;

		 		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
               $excluded_days = [];
                $_id = $_POST['subgroup_id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['subscription_min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['subscription_max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                $resourcegroup_id = $_POST['resourcegroup_id'];
               
                
                if(isset($_POST['sunday'])){
                    $excluded_days[] = $_POST['sunday'];
                }
                if(isset($_POST['monday'])){
                    $excluded_days[] = $_POST['monday'];
                }
                if(isset($_POST['tuesday'])){
                    $excluded_days[] = $_POST['tuesday'];
                }
                if(isset($_POST['wednesday'])){
                    $excluded_days[] = $_POST['wednesday'];
                }
                if(isset($_POST['thursday'])){
                    $excluded_days[] = $_POST['thursday'];
                }
                if(isset($_POST['friday'])){
                    $excluded_days[] = $_POST['friday'];
                }
                if(isset($_POST['saturday'])){
                    $excluded_days[] = $_POST['saturday'];
                }
                 
                 //get the toolbox name
                 $toolboxname = $this->getToolboxName($resourcegroup_id);
                 
                 //get the domain name
                 $subgroupname = $this->getTheSubgroupName($_id);
             
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();           
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                   if(($end_date <= $max_date) AND ($end_date >= $start_date)){                
                       //perform the assignment table update here
                       if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup_id)){
                           $cmd->update('subgroup_has_resourcegroup',
                                    array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                    'end_date'=>$end_date),
					 "subgroup_id = $_id and resourcegroup_id = $resourcegroup_id"
                                     );
                       }else{
                           $cmd->update('subgroup_has_resourcegroup',
                                    array('start_date'=>$start_date,'end_date'=>$end_date),
					 "subgroup_id = $_id and resourcegroup_id = $resourcegroup_id"
                                     );
                       }
                       
                      // if(isset($excluded_days)){
                         if(is_array($excluded_days) AND $excluded_days != NULL) {
                               $num = 0;
                               foreach($excluded_days as $value){
                                   if($value == 'Sunday' ) {
                                       $num = $num + 1;
                                        $cmd->update('subgroup_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                     );
                                   }elseif($value == 'Monday'){
                                       $num = $num + 2;
                                       $cmd->update('subgroup_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        );       
                                       
                                   }elseif($value == 'Tuesday'){
                                       $num = $num + 4;
                                       $cmd->update('subgroup_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   } elseif($value == 'Wednesday'){
                                       $num = $num + 8;
                                       $cmd->update('subgroup_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   }elseif($value == 'Thursday'){
                                       $num = $num + 16;
                                       $cmd->update('subgroup_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   } elseif($value == 'Friday'){
                                       $num = $num + 32;
                                       $cmd->update('subgroup_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                                                              
                                   }elseif($value == 'Saturday'){
                                       $num = $num + 64;
                                       $cmd->update('subgroup_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                   
                                       
                                   }
                                       
                                       
                                                
                                  
                                   
                               }
                                                                                          
                           }elseif($excluded_days == NULL){
                                      // $num = $num + 64;
                                       $cmd->update('subgroup_has_resourcegroup',
                                             array('excluded_days'=>NULL),
                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                   
                                       
                       }
                    $msg = "'$toolboxname' is successfully scheduled on the '$subgroupname' subgroup ";       
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                       
                   }else {
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'End Date is out of range with the subscription period or it is less than the Start Date'
                          )); 
                       
                   }             
                    
                }else {
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Start Date is out of range with the subscription period or it is greater than the End Date'
                          )); 
                    
                    
                }
                
  
                
        }//end of single subgroup to resourcegroup scheduling function   
        
        
        
         /**
	 * Schedule Resourcegroup To Subgroup.
	 * If schedule is successful, close the window else insist on doing the single item 
           * scheduling.
	 */
	public function actionScheduleSingleResourcegroupToUser()
	{
		//$model=new UserHasResourcegroup;

		 		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
               $excluded_days = [];
                $_id = $_POST['user_id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['subscription_min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['subscription_max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                $resourcegroup_id = $_POST['resourcegroup_id'];
               
                
                if(isset($_POST['sunday'])){
                    $excluded_days[] = $_POST['sunday'];
                }
                if(isset($_POST['monday'])){
                    $excluded_days[] = $_POST['monday'];
                }
                if(isset($_POST['tuesday'])){
                    $excluded_days[] = $_POST['tuesday'];
                }
                if(isset($_POST['wednesday'])){
                    $excluded_days[] = $_POST['wednesday'];
                }
                if(isset($_POST['thursday'])){
                    $excluded_days[] = $_POST['thursday'];
                }
                if(isset($_POST['friday'])){
                    $excluded_days[] = $_POST['friday'];
                }
                if(isset($_POST['saturday'])){
                    $excluded_days[] = $_POST['saturday'];
                }
                 
                //get the toolbox name
                 $toolboxname = $this->getToolboxName($resourcegroup_id);
                 
                 //get the domain name
                 $username = $this->getTheUsername($_id); 
             
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();           
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                   if(($end_date <= $max_date) AND ($end_date >= $start_date)){                
                       //perform the assignment table update here
                       if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup_id)){
                            $cmd->update('user_has_resourcegroup',
                                    array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                    'end_date'=>$end_date),
					 "user_id = $_id and resourcegroup_id = $resourcegroup_id"
                                     );
                       }else{
                            $cmd->update('user_has_resourcegroup',
                                    array('start_date'=>$start_date,'end_date'=>$end_date),
					 "user_id = $_id and resourcegroup_id = $resourcegroup_id"
                                     );
                       }
                      
                      // if(isset($excluded_days)){
                         if(is_array($excluded_days) AND $excluded_days != NULL) {
                               $num = 0;
                               foreach($excluded_days as $value){
                                   if($value == 'Sunday' ) {
                                       $num = $num + 1;
                                        $cmd->update('user_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                     );
                                   }elseif($value == 'Monday'){
                                       $num = $num + 2;
                                       $cmd->update('user_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        );       
                                       
                                   }elseif($value == 'Tuesday'){
                                       $num = $num + 4;
                                       $cmd->update('user_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   } elseif($value == 'Wednesday'){
                                       $num = $num + 8;
                                       $cmd->update('user_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   }elseif($value == 'Thursday'){
                                       $num = $num + 16;
                                       $cmd->update('user_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                       
                                   } elseif($value == 'Friday'){
                                       $num = $num + 32;
                                       $cmd->update('user_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                                                              
                                   }elseif($value == 'Saturday'){
                                       $num = $num + 64;
                                       $cmd->update('user_has_resourcegroup',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                   
                                       
                                   }
                                       
                                       
                                                
                                  
                                   
                               }
                                                                                          
                           }elseif($excluded_days == NULL){
                                      // $num = $num + 64;
                                       $cmd->update('user_has_resourcegroup',
                                             array('excluded_days'=>NULL),
                                             "user_id = $_id and  resourcegroup_id = $resourcegroup_id"
                                        ); 
                                   
                                       
                       }
                     $msg = "' $toolboxname' folder service is successfully scheduled for '$username'  ";      
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                       
                   }else {
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'End Date is out of range with the subscription period or it is less than the Start Date'
                          )); 
                       
                   }             
                    
                }else {
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Start Date is out of range with the subscription period or it is greater than the End Date'
                          )); 
                    
                    
                }
                
  
                
        }//end of single resourcegroup to user scheduling function 
        
        
        /**
         * This is the function that determines if a toolbox service visibility is permitted for user scheduling
         */
        public function isTheVisibilityOfThisServicePermitted($resourcegroup_id){
            
             $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("id = $resourcegroup_id and (visibility = 'private'  or visibility = 'private & restricted_public')");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
            
            
        }
        
        
         /**
         * This is the function that determines if a toolbox service visibility is permitted for user scheduling
         */
        public function isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup_id){
            
             $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("id = $resourcegroup_id and (visibility = 'private'  or visibility = 'private & restricted_public' or visibility = 'public' or visibility='restricted_public' or visibility='private & public' or visibility='reserved')");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
            
            
        }
        
         /**
	 * Schedule Resourcegroup To Subgroup.
	 * If schedule is successful, close the window else insist on doing the single item 
           * scheduling.
	 */
	public function actionScheduleSingleResourceToResourcegroup()
	{
		//$model=new ResourceHasResourcegroups;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $excluded_days = [];
                $_id = $_POST['resourcegroup_id'];
                $min_date = date("Y-m-d", strtotime($_POST['min_date'])); 
                $max_date = date("Y-m-d", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d", strtotime($_POST['end_date']));
                $resource_id = $_POST['resource_id'];
               
                
                if(isset($_POST['sunday'])){
                    $excluded_days[] = $_POST['sunday'];
                }
                if(isset($_POST['monday'])){
                    $excluded_days[] = $_POST['monday'];
                }
                if(isset($_POST['tuesday'])){
                    $excluded_days[] = $_POST['tuesday'];
                }
                if(isset($_POST['wednesday'])){
                    $excluded_days[] = $_POST['wednesday'];
                }
                if(isset($_POST['thursday'])){
                    $excluded_days[] = $_POST['thursday'];
                }
                if(isset($_POST['friday'])){
                    $excluded_days[] = $_POST['friday'];
                }
                if(isset($_POST['saturday'])){
                    $excluded_days[] = $_POST['saturday'];
                }
                 
                 //get the toolbox name
                 $toolboxname = $this->getToolboxName($_id);
                 
                 //get the domain name
                 $toolname = $this->getTheToolName($resource_id); 
             
             
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();           
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                   if(($end_date <= $max_date) AND ($end_date >= $start_date)){                
                       //perform the assignment table update here
                       if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($_id)){
                            $cmd->update('resource_has_resourcegroups',
                                    array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                    'end_date'=>$end_date),
					 "resourcegroup_id = $_id and resource_id = $resource_id"
                                     );
                       }else{
                          $cmd->update('resource_has_resourcegroups',
                                    array('start_date'=>$start_date,
                                    'end_date'=>$end_date),
					 "resourcegroup_id = $_id and resource_id = $resource_id"
                                     ); 
                       }
                      
                      // if(isset($excluded_days)){
                         if(is_array($excluded_days) AND $excluded_days != NULL) {
                               $num = 0;
                               foreach($excluded_days as $value){
                                   if($value == 'Sunday' ) {
                                       $num = $num + 1;
                                        $cmd->update('resource_has_resourcegroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "resourcegroup_id = $_id and  resource_id = $resource_id"
                                     );
                                   }elseif($value == 'Monday'){
                                       $num = $num + 2;
                                       $cmd->update('resource_has_resourcegroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "resourcegroup_id = $_id and  resource_id = $resource_id"
                                        );       
                                       
                                   }elseif($value == 'Tuesday'){
                                       $num = $num + 4;
                                       $cmd->update('resource_has_resourcegroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "resourcegroup_id = $_id and  resource_id = $resource_id"
                                        ); 
                                       
                                   } elseif($value == 'Wednesday'){
                                       $num = $num + 8;
                                       $cmd->update('resource_has_resourcegroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "resourcegroup_id = $_id and  resource_id = $resource_id"
                                        ); 
                                       
                                   }elseif($value == 'Thursday'){
                                       $num = $num + 16;
                                       $cmd->update('resource_has_resourcegroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "resourcegroup_id = $_id and  resource_id = $resource_id"
                                        ); 
                                       
                                   } elseif($value == 'Friday'){
                                       $num = $num + 32;
                                       $cmd->update('resource_has_resourcegroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "resourcegroup_id = $_id and  resource_id = $resource_id"
                                        ); 
                                                                              
                                   }elseif($value == 'Saturday'){
                                       $num = $num + 64;
                                       $cmd->update('resource_has_resourcegroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "resourcegroup_id = $_id and  resource_id = $resource_id"
                                        ); 
                                   
                                       
                                   }
                                       
                                       
                                                
                                  
                                   
                               }
                                                                                          
                           }elseif($excluded_days == NULL){
                                      // $num = $num + 64;
                                       $cmd->update('resource_has_resourcegroups',
                                             array('excluded_days'=>NULL),
                                             "resourcegroup_id = $_id and  resource_id = $resource_id"
                                        ); 
                                   
                                       
                       }
                     $msg = "' $toolname' session is scheduled on the '$toolboxname' folder";      
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                       
                   }else {
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'End Date is out of range with the subscription period or it is less than the Start Date'
                          )); 
                       
                   }             
                    
                }else {
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Start Date is out of range with the subscription period or it is greater than the End Date'
                          )); 
                    
                    
                }
                
  
                
        }//end of single scheduling function 
        
        
        
         /**
	 * Schedule Resourcegroup To Group.
	 * If schedule is successful, close the window else insist on doing the a single item 
           * scheduling.
	 */
	public function actionScheduleBulkResourcegroupToGroup()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                //$min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
               // $max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d ", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d", strtotime($_POST['end_date']));
                //$resourcegroup_id = $_POST['resourcegroup_id'];
                //get the group name
                $groupname = $this->getTheGroupName($_id);
                
                //get the domain id of this group
                
                $domain_id = $this->getTheDomainOfThisGroup($_id);
                $success_counter = 0;
                $failure_counter = 0;
                $cmd =Yii::app()->db->createCommand();   
                
                        if(isset($_POST['resourcegroup'])){
                            if(is_array($_POST['resourcegroup'])) {
                                 foreach($_POST['resourcegroup'] as $resourcegroup){
                                     //save all the data into the database except the set the data type
                                   if($this->isStartDatePermissible($resourcegroup,$domain_id,$start_date) AND $this->isEndDatePermissible($resourcegroup,$domain_id,$end_date)){
                                       if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup)){
                                         $cmd->update('group_has_resourcegroup',
                                             array('start_date'=>$start_date, 'end_date'=>$end_date),
                                             "group_id = $_id and resourcegroup_id = $resourcegroup"
                                     );
                                         $success_counter = $success_counter + 1;
                                     }else{
                                         $cmd->update('group_has_resourcegroup',
                                             array('start_date'=>$start_date, 'end_date'=>$end_date),
                                             "group_id = $_id and resourcegroup_id = $resourcegroup"
                                     );
                                         $success_counter = $success_counter + 1;
                                     }
                                        
                                    } 
                                     
                                     
                                     //update table to save the excluded_days data into the database
                                     if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('group_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('group_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('group_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('group_has_resourcegroup',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('group_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('group_has_resourcegroup',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('group_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('group_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }//end of the excluded_days isset if statement
                             
                                }//end of the resourcegroup array  foreach statement
                                
                         
                            } else { //end of resourcegroup is_array if  statement
                                $resourcegroup = $_POST['resourcegroup'];
                                if($this->isStartDatePermissible($resourcegroup,$domain_id,$start_date) AND $this->isEndDatePermissible($resourcegroup,$domain_id,$end_date)){
                                    if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup)){
                                    $cmd->update('group_has_resourcegroup',
                                             array('start_date'=>$start_date,'end_date'=>$end_date),
                                             "group_id = $_id and resourcegroup_id = $resourcegroup"
                                  );
                                    $success_counter = $success_counter + 1;
                                }else{
                                    $cmd->update('group_has_resourcegroup',
                                             array('start_date'=>$start_date,
                                             'end_date'=>$end_date),
                                             "group_id = $_id and resourcegroup_id = $resourcegroup"
                                  );
                                    $success_counter = $success_counter + 1;
                                }
                                    
                                }
                                
                                
                                  if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('group_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('group_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('group_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('group_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('group_has_resourcegroup',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('group_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('group_has_resourcegroup',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('group_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('group_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "group_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }// end of the excluded_day isset statement for non-array resourcegroup
                                
                                
                            }//end of resourcegroup is_array if else  statement
                            $msg = "$success_counter  folder service(s) were successfully scheduled for the '$groupname' group " ;
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() == 0,
                                     "msg"=>$msg
                             ));
                            
                    
                }else{
                    header('Content-Type: application/json');
                          echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() != 0,
                           "msg" => "Select at least one item in the folder to schedule"   
                      ));
                    
                    
                }//end of resourcegroup isset if-else statement 
                        
                        
                        
         
          
        }//end of bulk resourcegroup to group scheduling function 
        
       
        
         /**
	 * Schedule Resourcegroup To Group.
	 * If schedule is successful, close the window else insist on doing the a single item 
           * scheduling.
	 */
	public function actionScheduleBulkResourcegroupToSubgroup()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
               // $min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
               // $max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d", strtotime($_POST['end_date']));
                //$resourcegroup_id = $_POST['resourcegroup_id'];
                $success_counter = 0;
                $failure_counter = 0;
                //get the subgroup name
                $subgroupname = $this->getTheSubgroupName($_id); 
                
                //get the domain id for this subgroup
                
                $domain_id = $this->getTheDomainOfThisSubgroup($_id);
                $cmd =Yii::app()->db->createCommand();   
                
                        if(isset($_POST['resourcegroup'])){
                            if(is_array($_POST['resourcegroup'])) {
                                 foreach($_POST['resourcegroup'] as $resourcegroup){
                                     if($this->isStartDatePermissible($resourcegroup,$domain_id,$start_date) AND $this->isEndDatePermissible($resourcegroup,$domain_id,$end_date)){
                                         
                                          //save all the data into the database except the set the data type 
                                     if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup)){
                                        $cmd->update('subgroup_has_resourcegroup',
                                             array('start_date'=>$start_date,'end_date'=>$end_date),
                                             "subgroup_id = $_id and resourcegroup_id = $resourcegroup"
                                     ); 
                                        $success_counter = $success_counter + 1;
                                     }else{
                                        $cmd->update('subgroup_has_resourcegroup',
                                             array('start_date'=>$start_date, 'end_date'=>$end_date),
                                             "subgroup_id = $_id and resourcegroup_id = $resourcegroup"
                                     ); 
                                        $success_counter = $success_counter + 1;
                                     }
                                     }
                                    
                                     
                                     //update table to save the excluded_days data into the database
                                     if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('subgroup_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('subgroup_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('subgroup_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('subgroup_has_resourcegroup',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('subgroup_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('subgroup_has_resourcegroup',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('subgroup_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('subgroup_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }//end of the excluded_days isset if statement
                             
                                }//end of the resourcegroup array  foreach statement
                                
                         
                            } else { //end of resourcegroup is_array if  statement
                                $resourcegroup = $_POST['resourcegroup'];
                                if($this->isStartDatePermissible($resourcegroup,$domain_id,$start_date) AND $this->isEndDatePermissible($resourcegroup,$domain_id,$end_date)){
                                    if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup)){
                                     $cmd->update('subgroup_has_resourcegroup',
                                             array('start_date'=>$start_date,'end_date'=>$end_date),
                                             "subgroup_id = $_id and resourcegroup_id = $resourcegroup"
                                  );
                                     $success_counter = $success_counter + 1;
                                }else{
                                    $cmd->update('subgroup_has_resourcegroup',
                                             array( 'start_date'=>$start_date,'end_date'=>$end_date),
                                             "subgroup_id = $_id and resourcegroup_id = $resourcegroup"
                                  );
                                    $success_counter = $success_counter + 1;
                                }
                               
                                    
                                }
                                
                                  if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('subgroup_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('subgroup_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('subgroup_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('subgroup_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('subgroup_has_resourcegroup',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('subgroup_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('subgroup_has_resourcegroup',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('subgroup_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('subgroup_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }// end of the excluded_day isset statement for non-array resourcegroup
                                
                                
                            }//end of resourcegroup is_array if else  statement
                            $msg = "$success_counter  folder service(s) were successfully scheduled for the '$subgroupname' subgroup " ; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() == 0,
                                     "msg"=>$msg
                             ));
                            
                    
                }else{
                    header('Content-Type: application/json');
                          echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() != 0,
                           "msg" => "Select at least one item in the folder to schedule"   
                      ));
                    
                    
                }//end of resourcegroup isset if-else statement 
                        
                        
                        
         
          
        }//end of bulk resourcegroup to subgroup scheduling function 
        
        
        /**
	 * Schedule Bulk Resourcegroup To User.
	 * If schedule is successful, close the window else insist on doing the a single item 
           * scheduling.
	 */
	public function actionScheduleBulkResourcegroupToUser()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                //$min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
                //$max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d", strtotime($_POST['end_date']));
                //$resourcegroup_id = $_POST['resourcegroup_id'];
               $success_counter = 0;
                $failure_counter = 0;
                //get the subgroup name
                $username = $this->getTheUsername($_id); 
                
                //get the domain of this user
                $domain_id = $this->determineAUserDomainIdGiven($_id);
                $cmd =Yii::app()->db->createCommand();   
               
                        if(isset($_POST['resourcegroup'])){
                            if(is_array($_POST['resourcegroup'])) {
                                 foreach($_POST['resourcegroup'] as $resourcegroup){
                                     if($this->isStartDatePermissible($resourcegroup,$domain_id,$start_date) AND $this->isEndDatePermissible($resourcegroup,$domain_id,$end_date)){
                                         //save all the data into the database except the set the data type 
                                     if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup)){
                                         $cmd->update('user_has_resourcegroup',
                                             array('start_date'=>$start_date,'end_date'=>$end_date),
                                             "user_id = $_id and resourcegroup_id = $resourcegroup"
                                     );
                                         $success_counter = $success_counter + 1;
                                     }else{
                                        $cmd->update('user_has_resourcegroup',
                                             array( 'start_date'=>$start_date, 'end_date'=>$end_date),
                                             "user_id = $_id and resourcegroup_id = $resourcegroup"
                                     ); 
                                        $success_counter = $success_counter + 1;
                                     }
                                         
                                     }
                                     
                                     
                                     //update table to save the excluded_days data into the database
                                     if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('user_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('user_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('user_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('user_has_resourcegroup',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('user_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('user_has_resourcegroup',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('user_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('user_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }//end of the excluded_days isset if statement
                             
                                }//end of the resourcegroup array  foreach statement
                                
                         
                            } else { //end of resourcegroup is_array if  statement
                                $resourcegroup = $_POST['resourcegroup'];
                                if($this->isStartDatePermissible($resourcegroup,$domain_id,$start_date) AND $this->isEndDatePermissible($resourcegroup,$domain_id,$end_date)){
                                    if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($resourcegroup)){
                                   $cmd->update('user_has_resourcegroup',
                                             array('start_date'=>$start_date,'end_date'=>$end_date),
                                             "user_id = $_id and resourcegroup_id = $resourcegroup"
                                  ); 
                                   $success_counter = $success_counter + 1;
                                }else{
                                    $cmd->update('user_has_resourcegroup',
                                             array( 'start_date'=>$start_date, 'end_date'=>$end_date),
                                             "user_id = $_id and resourcegroup_id = $resourcegroup"
                                  ); 
                                    $success_counter = $success_counter + 1;
                                }
                                }
                                
                                
                                  if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('user_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('user_has_resourcegroup',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('user_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('user_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('user_has_resourcegroup',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('user_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('user_has_resourcegroup',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('user_has_resourcegroup',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('user_has_resourcegroup',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  resourcegroup_id = $resourcegroup"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }// end of the excluded_day isset statement for non-array resourcegroup
                                
                                
                            }//end of resourcegroup is_array if else  statement
                            $msg = "$success_counter  folder services were successfully scheduled for '$username'  " ;  
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() == 0,
                                     "msg"=>$msg
                             ));
                            
                    
                }else{
                    header('Content-Type: application/json');
                          echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() != 0,
                           "msg" => "Select at least one item in the folder to schedule"   
                      ));
                    
                    
                }//end of resourcegroup isset if-else statement 
                        
                        
                        
         
          
        }//end of bulk resourcegroup to user scheduling function 
        
        
         
        
        
        /**
	 * Schedule Bulk Resources To Resourcegroup.
	 * If schedule is successful, close the window else insist on doing the a single item 
           * scheduling.
	 */
	public function actionScheduleBulkResourceToResourcegroup()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                //$resourcegroup_id = $_POST['resourcegroup_id'];
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand(); 
                $counter = 0;
                //get the toolbox name
                $toolboxname = $this->getToolboxName($_id);
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                    if(($end_date <= $max_date) AND ($end_date >= $start_date)){  
                        if(isset($_POST['resource'])){
                            if(is_array($_POST['resource'])) {
                                 foreach($_POST['resource'] as $resource){
                                     //save all the data into the database except the set data type 
                                     if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($_id)){
                                         $cmd->update('resource_has_resourcegroups',
                                             array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                             'end_date'=>$end_date),
                                             "resourcegroup_id = $_id and resource_id = $resource"
                                     );
                                         $counter = $counter + 1;
                                     }else{
                                         $cmd->update('resource_has_resourcegroups',
                                             array('start_date'=>$start_date,
                                             'end_date'=>$end_date),
                                             "resourcegroup_id = $_id and resource_id = $resource"
                                     );
                                         $counter = $counter + 1;
                                     }
                                     
                                     //update table to save the excluded_days data into the database
                                     if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "resourcegroup_id = $_id and  resource_id = $resource"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('resource_has_resourcegroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "resourcegroup_id = $_id and  resource_id = $resource"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('resource_has_resourcegroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "resourcegroup_id = $_id and  resource_id = $resource"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('resource_has_resourcegroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('resource_has_resourcegroups',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "resourcegroup_id = $_id and  resource_id = $resource"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('resource_has_resourcegroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "resourcegroup_id = $_id and  resource_id = $resource"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('resource_has_resourcegroups',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "resourcegroup_id = $_id and  resource_id = $resource"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('resource_has_resourcegroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "resourcegroup_id = $_id and  resource_id = $resource"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('resource_has_resourcegroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "resourcegroup_id = $_id and  resource_id = $resource"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }//end of the excluded_days isset if statement
                             
                                }//end of the resourcegroup array  foreach statement
                                
                         
                            } else { //end of resourcegroup is_array if  statement
                                $resource = $_POST['resource'];
                                if($this->isTheVisibilityOfThisServicePermittedForThisAssignment($_id)){
                                    $cmd->update('resource_has_resourcegroups',
                                             array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                             'end_date'=>$end_date),
                                             "resourcegroup_id = $_id and resource_id = $resource"
                                  );
                                    $counter = $counter + 1;
                                }else{
                                    $cmd->update('resource_has_resourcegroups',
                                             array('start_date'=>$start_date, 'end_date'=>$end_date),
                                             "resourcegroup_id = $_id and resource_id = $resource"
                                  );
                                    $counter = $counter + 1;
                                }
                                
                                  if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "resourcegroup_id = $_id and  resource_id = $resource"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('resource_has_resourcegroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "resourcegroup_id = $_id and  resource_id = $resource"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('resource_has_resourcegroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('resource_has_resourcegroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "resourcegroup_id = $_id and  resourcegroup_id = $resource"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('resource_has_resourcegroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "resourcegroup_id = $_id and  resource_id = $resource"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('resource_has_resourcegroups',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "resourcegroup_id = $_id and  resource_id = $resource"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('resource_has_resourcegroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "resourcegroup_id = $_id and  resource_id = $resource"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('resource_has_resourcegroups',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "resourcegroup_id = $_id and  resource_id = $resource"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('resource_has_resourcegroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "resourcegroup_id = $_id and  resource_id = $resource"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('resource_has_resourcegroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "resourcegroup_id = $_id and  resource_id = $resource"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }// end of the excluded_day isset statement for non-array resourcegroup
                                
                                
                            }//end of resourcegroup is_array if else  statement
                            $msg = " $counter number of file(s) is/are successfully scheduled in the '$toolboxname' Folder "; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() == 0,
                                     "msg"=>$msg
                             ));
                            
                    
                }else{
                    header('Content-Type: application/json');
                          echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() != 0,
                           "msg" => "Select at least one item in the Folder to schedule"   
                      ));
                    
                    
                }//end of resourcegroup isset if-else statement 
                        
                        
                        
         }else {
               header('Content-Type: application/json');
                     echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() != 0,
                         "msg" => 'End Date is out of range with the subscription period or it is less than the Start Date'
                      )); 
                        
                        
          }//end of end_date check if-else statement
                    
                    
          }else{
              header('Content-Type: application/json');
                  echo CJSON::encode(array(
                     "success" => mysqli_connect_errno() != 0,
                     "msg" => 'Start Date is out of range with the subscription period or it is greater than the End Date'
               ));  
                    
                    
                    
          }//end of start_date check if-else  statement
          
        }//end of bulk resources to resourcegroup scheduling function 
        
            /**
	 * Assign Resourcegroup To Subgroups.
	 * If assignment is successful, close the window else insist an assignment to be done.
	 */
	public function actionAssignResourceToResourcegroup()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                
                $cmd =Yii::app()->db->createCommand();
                                             
              
                
                if(isset($_POST['resource'])){
                    //spool all the toolboxes already assigned to this toolbox
                    $existing_tools = $this->alreadyAssignedToolsToThisResourcegroup($_id);
                    $selected_tools = [];
                    foreach($_POST['resource'] as $tool_id){
                        
                        $selected_tools[] = $tool_id;
                        
                    }   
                    //get the array difference
                    $discarded_tools = array_diff($existing_tools,$selected_tools);
                    
                    //delete all the toolboxes in $discarded_toolboxes array
                    foreach($discarded_tools as $discarded){
                        
                        $this->removeThisToolFromThisResourcegroup($discarded, $_id);
                    }
                
                  
                         if (is_array($_POST['resource'])) {
                            foreach($_POST['resource'] as $value){   
                                if($this->isToolNotAlreadyAssignedToThisResourcegroup($value, $_id)){
                                    $cmd->insert('resource_has_resourcegroups',
                                        array(
                                           'resourcegroup_id'=>$_POST['id'],
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                           'resource_id'=>$value,
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id
                                              
                                        ));
                                 
                                }else{
                                    $group_id = $_POST['id'];
                                    $cmd->update('resource_has_resourcegroups',
                                        array(
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                          
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id
                                              
                                        ),
                                       ("resourcegroup_id=$group_id and resource_id=$value"));
                                }
                            
                             }
                    
                    
                   
                             
                       }else {
                           $value = $_POST['resource'];
                           
                           $cmd->insert('resource_has_resourcegroups',
                                   array(
                                        'resourcegroup_id'=>$_POST['id'],
                                        'assign_name'=>$_POST['assign_name'],
                                        'assign_description'=>$_POST['assign_description'],
                                        'resource_id'=>$value,
                                        'date_assigned'=>new CDbExpression('NOW()'),
                                        'assigned_by'=>Yii::app()->user->id
                                              
                                    ));
                            
                            
                           
                           
                       }
                      
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>"Successfull assignment of file(s) to Folder"
                       ));
                        
                    } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Using this bulk module, you cannot effect or add zero number of file  to a folder. PLEASE USE THE SINGLE FILE TO FOLDER ASSIGNMENT MODULE INTSTEAD'
                          )); 
                        
                    }
                  
                          
                               
           
                    
            }
            
            
             /**
	 * List all the resourcegroups in this category
	 */
	public function actionListAllResourcegroupsInCategory_old()
	{
		
                   $_id = $_REQUEST['id'];
                //$_id = 1;
               
		$userid = Yii::app()->user->id;   
                if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") ){   
                    $criteria = new CDbCriteria();
                    $criteria->select = 'resourcegroup_id, category_id, max_date,min_date, start_date, end_date, excluded_days';
                    $criteria->condition='category_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $resourcegroup= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
             } else {
		//obtain all the resourcegroup created by the user
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='create_user_id=:id OR update_user_id=:userid';
                 $criteria1->params = array(':id'=>$userid, ':userid'=>$userid);
                 $allgroups= Resourcegroup::model()->findAll($criteria1);
                 
                 $resourcegroup = [];
                 
                 foreach($allgroups as $group){
                    $criteria2 = new CDbCriteria();
                    $criteria2->select = 'resourcegroup_id, category_id, max_date,min_date, start_date, end_date, excluded_days';
                    $criteria2->condition='category_id=:id AND resourcegroup_id=:groupid';
                    $criteria2->params = array(':id'=>$_id, ':groupid'=>$group->id);
                    $usergroups= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria2);
                    
                    $resourcegroup = array_merge($resourcegroup, $usergroups);
                     
                     
                 }
                 if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
			 
			 
            } 
               
               
	}
        
        
             /**
	 * List all the resourcegroups in this category
	 */
	public function actionListAllResourcegroupsInCategory()
	{
		
                 $_id = $_REQUEST['id'];
                //$_id = 1;
               
		$userid = Yii::app()->user->id;   
                
                $domain_id = $this->determineAUserDomainIdGiven($userid);
                  
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='category_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $toolboxes= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                    
                    $domain_toolboxes = [];
                    foreach($toolboxes as $toolbox){
                        if($this->isToolboxVisibilityPrivate($toolbox['resourcegroup_id'])){
                            $domain_toolboxes[] = $toolbox;
                        }
                        
                        
                    }
                
               if($domain_toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($domain_toolboxes);
                       
                }
             
			 
			 
            
               
               
	}
        
        
        
            /**
	 * List all the active toolboxes/resourcegroups in this category
	 */
	public function actionListAllToolbxesConsumedByThisDomain()
	{
		
                 $_id = $_REQUEST['id'];
                //$_id = 1;
               
		$userid = Yii::app()->user->id;   
                
                $domain_id = $this->determineAUserDomainIdGiven($userid);
                  
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='category_id=:id and toolbox_status=:status';
                    $criteria->params = array(':id'=>$_id,':status'=>"active");
                    $toolboxes= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                    
                    $domain_toolboxes = [];
                    foreach($toolboxes as $toolbox){
                        
                            $domain_toolboxes[] = $toolbox;
                      
                        
                        
                    }
                
               if($domain_toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($domain_toolboxes);
                       
                }
             
			 
			 
            
               
               
	}
        
        
        /**
         * This is the function that determines a toolbox visibility
         */
        public function isToolboxVisibilityPrivate($toolbox_id){
            
                $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='id=:id';
                 $criteria1->params = array(':id'=>$toolbox_id);
                 $toolbox= Resourcegroup::model()->find($criteria1);
                 
                 if($toolbox['visibility'] == "private" || $toolbox['visibility']== "private & restricted_public" ){
                     return true;
                 }else{
                     return false;
                 }
            
        }
        
            /**
	 * List all the resourcegroups in this category for assignment purpose
	 */
	public function actionListAllResourcegroupsInCategoryForAssignment()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                
                //determine all the resourcegroups assigned to this category
                $criteria = new CDbCriteria();
                $criteria->select = 'resourcegroup_id, category_id, max_date,min_date, start_date, end_date, excluded_days';
                $criteria->condition='category_id=:id';
                $criteria->params = array(':id'=>$_id);
                $group= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                
                $resourcegroup = [];
                foreach($group as $item){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='id=:id';
                    $criteria1->params = array(':id'=>$item->resourcegroup_id);
                    $resources= Resourcegroup::model()->findAll($criteria1);
                    
                    $resourcegroup = array_merge($resourcegroup, $resources);
                    
                    
                    
                }
                
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
               
               
	}
        
        
        
            /**
	 * List all the resourcegroups in this category for assignment purpose
	 */
	public function actionListAllResourcegroupsInCategoryForSubgroupAssignment_old()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                
                //determine the group of this subgroup
                $criteria2 = new CDbCriteria();
                $criteria2->select = 'id, group_id';
                $criteria2->condition='id=:id';
                $criteria2->params = array(':id'=>$_id);
                $groupid= SubGroup::model()->find($criteria2);
                
                
                //determine the grouptype of the group
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, grouptype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$groupid->group_id);
                $grouptype= Group::model()->find($criteria3);
                
                
                //determine the grouptype name of the group
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$grouptype->grouptype_id);
                $grouptype_name= GroupType::model()->find($criteria4);
                
                
                //determine the category id of the grouptype name
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name';
                $criteria5->condition='name=:name';
                $criteria5->params = array(':name'=>$grouptype_name->name);
                $categoryid= ResourcegroupCategory::model()->find($criteria5);
                
                
                //determine all the resourcegroups assigned to this category
                $criteria = new CDbCriteria();
                $criteria->select = 'resourcegroup_id, category_id, max_date,min_date, start_date, end_date, excluded_days';
                $criteria->condition='category_id=:id';
                $criteria->params = array(':id'=>$categoryid->id);
                $group= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                
                $resourcegroup = [];
                foreach($group as $item){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='id=:id';
                    $criteria1->params = array(':id'=>$item->resourcegroup_id);
                    $resources= Resourcegroup::model()->findAll($criteria1);
                    
                    $resourcegroup = array_merge($resourcegroup, $resources);
                    
                    
                    
                }
                
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
               
               
	}
        
        
        
            /**
	 * List all the resourcegroups in this category for assignment purpose
	 */
	public function actionListAllResourcegroupsInCategoryForSubgroupAssignment()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                
                //determine the group of this subgroup
                $criteria2 = new CDbCriteria();
                $criteria2->select = 'id, group_id';
                $criteria2->condition='id=:id';
                $criteria2->params = array(':id'=>$_id);
                $groupid= SubGroup::model()->find($criteria2);
                
                
                //determine the domain of the group
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, domain_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$groupid['group_id']);
                $domain= Group::model()->find($criteria3);
                
                
                //determine all the resourcegroups assigned to this category/domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='category_id=:id';
                $criteria->params = array(':id'=>$domain['domain_id']);
                $group= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                
                $resourcegroup = [];
                foreach($group as $item){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='id=:id';
                    $criteria1->params = array(':id'=>$item['resourcegroup_id']);
                    $resources= Resourcegroup::model()->findAll($criteria1);
                    
                    $resourcegroup = array_merge($resourcegroup, $resources);
                    
                    
                    
                }
                
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
               
               
	}
        
        
           /**
	 * List all the resourcegroups in this category for group assignment purpose
	 */
	public function actionListAllResourcegroupsInCategoryForGroupAssignment_old()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                                                             
                //determine the grouptype of the group
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, grouptype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$_id);
                $grouptype= Group::model()->find($criteria3);
                
                
                //determine the grouptype name of the group
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$grouptype->grouptype_id);
                $grouptype_name= GroupType::model()->find($criteria4);
                
                
                //determine the category id of the grouptype name
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name';
                $criteria5->condition='name=:name';
                $criteria5->params = array(':name'=>$grouptype_name->name);
                $categoryid= ResourcegroupCategory::model()->find($criteria5);
                
                
                //determine all the resourcegroups assigned to this category
                $criteria = new CDbCriteria();
                $criteria->select = 'resourcegroup_id, category_id, max_date,min_date, start_date, end_date, excluded_days';
                $criteria->condition='category_id=:id';
                $criteria->params = array(':id'=>$categoryid->id);
                $group= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                
                $resourcegroup = [];
                foreach($group as $item){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='id=:id';
                    $criteria1->params = array(':id'=>$item->resourcegroup_id);
                    $resources= Resourcegroup::model()->findAll($criteria1);
                    
                    $resourcegroup = array_merge($resourcegroup, $resources);
                    
                    
                    
                }
                
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
               
               
	}
        
        
        
        
           /**
	 * List all the resourcegroups in this category for group assignment purpose
	 */
	public function actionListAllResourcegroupsInCategoryForGroupAssignment()
	{
		
            //get the logged in user
            $user_id = Yii::app()->user->id;
            //$domain_id = $this->determineAUserDomainIdGiven($user_id);
            
                $_id = $_REQUEST['id'];
                //$_id = 1;
                                                             
               //get the domain of this group
                $domain_id = $this->getTheDomainOfThisGroup($_id);
                
                //determine all the resourcegroups assigned to this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='category_id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $group= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                
                $resourcegroup = [];
                foreach($group as $item){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='id=:id';
                    $criteria1->params = array(':id'=>$item['resourcegroup_id']);
                    $resources= Resourcegroup::model()->findAll($criteria1);
                    
                    $resourcegroup = array_merge($resourcegroup, $resources);
                    
                    
                    
                }
                
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
               
               
	}
        
        
      
        
        
           /**
	 * List all the resourcegroups in this category for user assignment purpose
	 */
	public function actionListAllResourcegroupsInCategoryForUserAssignment()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                                                             
                //get the logged in user
                $user_id = Yii::app()->user->id;
                
                //get the domain id
                
               // $domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                //get the domain id of this user
                $domain_id = $this->getTheDomainIdOfThisUser($_id);
                
               //determine all the resourcegroups assigned to this category
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='category_id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $group= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                
                $resourcegroup = [];
                foreach($group as $item){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='id=:id';
                    $criteria1->params = array(':id'=>$item['resourcegroup_id']);
                    $resources= Resourcegroup::model()->findAll($criteria1);
                    
                    $resourcegroup = array_merge($resourcegroup, $resources);
                    
                    
                    
                }
                
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
               
               
	}
        
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$user_id);
                $user= User::model()->find($criteria);
                
                
                return $user['domain_id'];
            
            
        }
        
        
            /**
	 * List all the resources in a resourcegroup
	 */
	public function actionListAllResourcesInResourcegroup_old()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $userid = Yii::app()->user->id;   
		if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") ){   
                    $criteria = new CDbCriteria();
                    $criteria->select = 'resource_id, resourcegroup_id,max_date,min_date, start_date, end_date, excluded_days';
                    $criteria->condition='resourcegroup_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $resources= ResourceHasResourcegroups::model()->findAll($criteria);
                
               if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resources);
                       
                }
              }else {
                  //obtain all the resources created by the user
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='create_user_id=:id OR update_user_id=:userid and parent_id is Null';
                 $criteria1->params = array(':id'=>$userid, ':userid'=>$userid);
                 $allresources= Resources::model()->findAll($criteria1);
                 
                 $resources = [];
                 
                 foreach($allresources as $res){
                    $criteria2 = new CDbCriteria();
                    $criteria2->select = 'resource_id, resourcegroup_id,max_date,min_date, start_date, end_date, excluded_days';
                    $criteria2->condition='resourcegroup_id=:id and resource_id=:resid';
                    $criteria2->params = array(':id'=>$_id, ':resid'=>$res->id);
                    $allres= ResourceHasResourcegroups::model()->findAll($criteria2);
                    
                    $resources = array_merge($resources, $allres);
                     
                 }
                 if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resources);
                       
                }
                  
                  
              } 
               
               
	}
        
        
          /**
	 * List all the resources in a resourcegroup
	 */
	public function actionListAllResourcesInResourcegroup()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $userid = Yii::app()->user->id;   
		  
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='resourcegroup_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $resources= ResourceHasResourcegroups::model()->findAll($criteria);
                
               if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resources);
                       
                }
              
    
	}
        
        
            /**
	 * List all the resources in a resourcegroup
	 */
	public function actionListAllOnScheduledResourcesInResourcegroup_old()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $criteria = new CDbCriteria();
                $criteria->select = 'resource_id, resourcegroup_id,max_date,min_date, start_date, end_date, excluded_days';
                $criteria->condition='resourcegroup_id=:id AND DATEDIFF(end_date, CURDATE())>= 0';
                $criteria->params = array(':id'=>$_id);
                $resources= ResourceHasResourcegroups::model()->findAll($criteria);
                
               if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resources);
                       
                }
               
               
	}
        
        
        
             /**
	 * This is the function that list all on scheduled tools/resources in a toolbox
	 */
	public function actionListAllOnScheduledResourcesInResourcegroup()
	{
		
                 $_id = $_REQUEST['id'];
               // $_id = 2;
                
                //get all schedule tools in this toolbox
                $all_tools = [];
                $all_tools = $this->getAllOnScheduledToolsInThisToolbox($_id);
                
                //get the active and on schedule tools details
                $allactive_tools = [];
                foreach($all_tools as $tool){
                    
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='resourcegroup_id=:id AND resource_id=:tool';
                    $criteria->params = array(':id'=>$_id,':tool'=>$tool);
                    $resources= ResourceHasResourcegroups::model()->find($criteria);
                    
                    $allactive_tools[] = $resources;
                    
                }
                
                     
               if($all_tools===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($allactive_tools);
                       
                }
        }      
        
        
        
        /**
         * This is the function that gets all active and onschedule tools in a toolbox
         */
        public function getAllOnScheduledToolsInThisToolbox($toolbox_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='resourcegroup_id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $tools= ResourceHasResourcegroups::model()->findAll($criteria);
                    
                    $alltools = [];
                    foreach($tools as $tool ){
                        if($this->isThisToolOnScheduleInThisToolbox($toolbox_id,$tool['resource_id'])){
                            $alltools[] =$tool['resource_id'];
                        }
                    }
            
                    return $alltools;
            
        }
        
        
        /**
         * This is the function to determine if a tool is on schedule in a toolbox
         */
        public function isThisToolOnScheduleInThisToolbox($toolbox_id,$tool_id){
            
             //retrieve the start date for this user in the subgroup
            $start_date = $this->getTheStartScheduledDateForThisToolInThisToolbox($tool_id,$toolbox_id);
            
            //get the end date for this user in the subgroup
            $end_date = $this->getTheEndScheduledDateForThisToolInThisToolbox($tool_id,$toolbox_id);
            
            if($this->isThisPeriodWithinSchedule($start_date,$end_date)){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that retrieves the start date of a tool in toolbox
         */
        public function getTheStartScheduledDateForThisToolInThisToolbox($tool_id,$toolbox_id) {
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='resource_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$tool_id,':resgroupid'=>$toolbox_id);
                 $period = ResourceHasResourcegroups::model()->find($criteria);
                 
                 return $period['start_date'];
        }
        
        
        
         /**
         * This is the function that retrieves the start date of a tool in toolbox
         */
        public function getTheEndScheduledDateForThisToolInThisToolbox($tool_id,$toolbox_id) {
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='resource_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$tool_id,':resgroupid'=>$toolbox_id);
                 $period = ResourceHasResourcegroups::model()->find($criteria);
                 
                 return $period['end_date'];
        }
             /**
	 * List all the resourcegroups in this group
	 */
	public function actionListAllResourcegroupsInAGroup_old()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $userid = Yii::app()->user->id;   
		if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") ){ 
                    $criteria = new CDbCriteria();
                    $criteria->select = 'resourcegroup_id, group_id,max_date,min_date, start_date, end_date, excluded_days';
                    $criteria->condition='group_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $resourcegroup= GroupHasResourcegroup::model()->findAll($criteria);
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
             }else {
                 //obtain all the resourcegroup created by the user
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='create_user_id=:id OR update_user_id=:userid';
                 $criteria1->params = array(':id'=>$userid, ':userid'=>$userid);
                 $allgroups= Resourcegroup::model()->findAll($criteria1);
                 
                 $resourcegroup = [];
                 
                 foreach($allgroups as $group){
                    $criteria2 = new CDbCriteria();
                    $criteria2->select = 'resourcegroup_id, group_id,max_date,min_date, start_date, end_date, excluded_days';
                    $criteria2->condition='group_id=:id and resourcegroup_id=:resid';
                    $criteria2->params = array(':id'=>$_id, 'resid'=>$group->id);
                    $usergroups= GroupHasResourcegroup::model()->findAll($criteria2);
                     
                    $resourcegroup = array_merge($resourcegroup, $usergroups); 
                 }
                  if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
                 
                 
             } 
               
               
	}
        
        
        
            /**
	 * List all the resourcegroups in this group
	 */
	public function actionListAllResourcegroupsInAGroup()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $userid = Yii::app()->user->id;   
		
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='group_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $resourcegroup= GroupHasResourcegroup::model()->findAll($criteria);
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
             
	}
        
             /**
	 * List all the resourcegroups in this subgroup
	 */
	public function actionListAllResourcegroupsInASubgroup_old()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $userid = Yii::app()->user->id;   
                if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin")){
                $criteria = new CDbCriteria();
                $criteria->select = 'resourcegroup_id, subgroup_id, max_date,min_date, start_date, end_date, excluded_days';
                $criteria->condition='subgroup_id=:id';
                $criteria->params = array(':id'=>$_id);
                $resourcegroup= SubgroupHasResourcegroup::model()->findAll($criteria);
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
             }else {
                 //obtain all the resourcegroup created or updated by the user
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='create_user_id=:id OR update_user_id=:userid';
                 $criteria1->params = array(':id'=>$userid, ':userid'=>$userid);
                 $allgroups= Resourcegroup::model()->findAll($criteria1);
                 
                 $resourcegroup = [];
                 
                 foreach($allgroups as $group){
                    $criteria2 = new CDbCriteria();
                    $criteria2->select = 'resourcegroup_id, subgroup_id, max_date,min_date, start_date, end_date, excluded_days';
                    $criteria2->condition='subgroup_id=:id and resourcegroup_id=:groupid';
                    $criteria2->params = array(':id'=>$_id, ':groupid'=>$group->id);
                    $usergroups= SubgroupHasResourcegroup::model()->findAll($criteria2);
                    
                    $resourcegroup = array_merge($resourcegroup, $usergroups);
                     
                     
                 }
                 if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
                 
                 
             } 
               
               
	}
        
        
        
             /**
	 * List all the resourcegroups in this subgroup
	 */
	public function actionListAllResourcegroupsInASubgroup()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $userid = Yii::app()->user->id;   
               
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='subgroup_id=:id';
                $criteria->params = array(':id'=>$_id);
                $resourcegroup= SubgroupHasResourcegroup::model()->findAll($criteria);
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
             
               
               
	}
        
        
         /**
	 * List all the resourcegroups for this user
	 */
	public function actionListAllResourcegroupsForThisUser_old()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                   
                $userid = Yii::app()->user->id;   
		if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin")){ 
                    $criteria = new CDbCriteria();
                    $criteria->select = 'resourcegroup_id, user_id,max_date,min_date, start_date, end_date, excluded_days';
                    $criteria->condition='user_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $resourcegroup= UserHasResourcegroup::model()->findAll($criteria);
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
               } else {
                   //obtain the resourcegroup created by this user
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='create_user_id=:id OR update_user_id=:userid';
                    $criteria1->params = array(':id'=>$userid, ':userid'=>$userid);
                    $allgroups= Resourcegroup::model()->findAll($criteria1);
                 
                 $resourcegroup = [];
                 
                 foreach($allgroups as $group){
                    $criteria2 = new CDbCriteria();
                    $criteria2->select = 'resourcegroup_id, user_id,max_date,min_date, start_date, end_date, excluded_days';
                    $criteria2->condition='user_id=:id and resourcegroup_id=:groupid';
                    $criteria2->params = array(':id'=>$_id, ':groupid'=>$group->id);
                    $usergroups= UserHasResourcegroup::model()->findAll($criteria2);
                    
                    $resourcegroup = array_merge($resourcegroup, $usergroups);
                     
                     
                 }
                 if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
                   
                   
               }
               
               
	}
        
        
        
         /**
	 * List all the resourcegroups for this user
	 */
	public function actionListAllResourcegroupsForThisUser()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                   
                $userid = Yii::app()->user->id;   
		
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='user_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $resourcegroup= UserHasResourcegroup::model()->findAll($criteria);
                
               if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($resourcegroup);
                       
                }
               
               
	}
        
          /**
	 * List all the resourcegroups and category for single scheduling
	 */
	public function actionListResourcegroupForCategoryForSingleScheduling()
	{
		
             $category_id = $_REQUEST['category_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$category_id);
             $category = ResourceGroupCategory::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
               
                if($category===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "category" => $category)
                       );
                       
                } 
               
               
	}
        
        
           /**
	 * List all the resourcegroups and user for single scheduling
	 */
	public function actionListResourcegroupForUserForSingleScheduling()
	{
		
             $user_id = $_REQUEST['user_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, firstname, middlename, lastname';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $user = User::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
               
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "user" => $user)
                       );
                       
                } 
               
               
	}
        
        
           /**
	 * List all the resourcegroups and subgroup for single scheduling
	 */
	public function actionListResourcegroupForSubgroupForSingleScheduling()
	{
		
             $subgroup_id = $_REQUEST['subgroup_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$subgroup_id);
             $subgroup = SubGroup::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
               
                if($subgroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "subgroup" => $subgroup)
                       );
                       
                } 
               
               
	}
        
        
           /**
	 * List all the resourcegroups and subgroup for single scheduling
	 */
	public function actionListResourcegroupForGroupForSingleScheduling()
	{
		
             $group_id = $_REQUEST['group_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$group_id);
             $group = Group::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
               
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "group" => $group)
                       );
                       
                } 
               
               
	}
        
        
          /**
	 * List all the resourcegroup for this group for single assignment
	 */
	public function actionListResourcegroupForGroupForSingleAssignment()
	{
		
             $group_id = $_REQUEST['group_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$group_id);
             $group = Group::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'assign_name, assign_description';
             $criteria3->condition='resourcegroup_id=:id AND group_id=:group';
             $criteria3->params = array(':id'=>$resourcegroup_id, ':group'=>$group_id);
             $assignment = GroupHasResourcegroup::model()->findAll($criteria3);
               
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "group" => $group,
                           "assignment"=> $assignment)
                       );
                       
                } 
               
               
	}
        
        
        /**
	 * List all the resourcegroup for this subgroup for single assignment
	 */
	public function actionListResourcegroupForSubgroupForSingleAssignment()
	{
		
             $subgroup_id = $_REQUEST['subgroup_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$subgroup_id);
             $subgroup = SubGroup::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'assign_name, assign_description';
             $criteria3->condition='resourcegroup_id=:id AND subgroup_id=:group';
             $criteria3->params = array(':id'=>$resourcegroup_id, ':group'=>$subgroup_id);
             $assignment = SubgroupHasResourcegroup::model()->findAll($criteria3);
               
                if($subgroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "subgroup" => $subgroup,
                           "assignment"=> $assignment)
                       );
                       
                } 
               
               
	}
        
        
        /**
	 * List all the resourcegroup for this user for single assignment
	 */
	public function actionListResourcegroupForUserForSingleAssignment()
	{
		
             $user_id = $_REQUEST['user_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, firstname, middlename, lastname, role';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $user = User::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'assign_name, assign_description';
             $criteria3->condition='resourcegroup_id=:id AND user_id=:user';
             $criteria3->params = array(':id'=>$resourcegroup_id, ':user'=>$user_id);
             $assignment = UserHasResourcegroup::model()->findAll($criteria3);
               
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "user" => $user,
                           "assignment"=> $assignment)
                       );
                       
                } 
               
               
	}
        
        
        /**
	 * List all the resourcegroup for this category for single assignment
	 */
	public function actionListResourcegroupForCategoryForSingleAssignment()
	{
		
             $category_id = $_REQUEST['category_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$category_id);
             $category = ResourceGroupCategory::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->find($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'assign_name, assign_description';
             $criteria3->condition='resourcegroup_id=:id AND category_id=:category';
             $criteria3->params = array(':id'=>$resourcegroup_id, ':category'=>$category_id);
             $assignment = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria3);
               
                if($category===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup['name'],
                            "category" => $category,
                           "assignment"=> $assignment)
                       );
                       
                } 
               
               
	}
        
        
        /**
	 * List all the resource for this resourcegroup for single assignment
	 */
	public function actionListResourceForResourcegroupForSingleAssignment()
	{
		
             $resource_id = $_REQUEST['resource_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$resource_id);
             $resource = Resources::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'assign_name, assign_description';
             $criteria3->condition='resourcegroup_id=:id AND resource_id=:resource';
             $criteria3->params = array(':id'=>$resourcegroup_id, ':resource'=>$resource_id);
             $assignment = ResourceHasResourcegroups::model()->findAll($criteria3);
               
                if($resourcegroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "resource" => $resource,
                           "assignment"=> $assignment)
                       );
                       
                } 
               
               
	}
        
        
          /**
	 * List all the resources for resourcegroup for single scheduling
	 */
	public function actionListResourcesForResourcegroupForSingleScheduling()
	{
		
             $resource_id = $_REQUEST['resource_id'];
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$resource_id);
             $resource = Resources::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $resourcegroup = Resourcegroup::model()->findAll($criteria2);
               
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" => $resourcegroup,
                            "resource" => $resource)
                       );
                       
                } 
               
               
	}
        
        
        
          /**
	 * List all the resourcegroups and subgroup for single scheduling
           * 
           */
	 
	public function actionListAllResourcegroupForThisUser_old()
	{
            $advanced_search = $_POST['advancedsearch'];
            $searched_start_date = $_POST['searched_start_date'];
            $searched_end_date = $_POST['searched_end_date'];
            $contentsearch = $_POST['contentsearch'];
            $document_initiator = $_POST['document_initiator'];
            $domain_verifier = $_POST['domain_verifier'];
            $platform_checker = $_POST['platform_checker'];
            $platform_verifier = $_POST['platform_verifier'];
            $processing_user = $_POST['processing_user'];
            $document_type = $_POST['type'];   
            
                      
            if($advanced_search == "false"){
                
                $today = new CDbExpression("UNIX_TIMESTAMP('NOW()')");
                   //convert to time
            $today_time = time($today);
            
            $allresourcegroup = [];
            $allsubgroupresource = [];
             $allgroupresource = [];
             //$allresult = [];
            $result = [];
             $user_id = Yii::app()->user->id;
             //$user_id = 1;
             //$resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            //obtain all the resourcegroup directly assigned to this user
            $criteria = new CDbCriteria();
            $criteria->select = 'resourcegroup_id, user_id, start_date, end_date';
            $criteria->condition='user_id=:userId AND DATEDIFF(end_date, CURDATE())>= 0 ';
            $criteria->params = array(':userId'=>$user_id);
            $allresourcegroup = UserHasResourcegroup::model()->findAll($criteria); 
            $result = array_merge($result, $allresourcegroup);
            
                      
             //obtain all the subgroups for this user
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, subgroup_id';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$user_id);
             $subgroup = UserHasSubgroups::model()->findAll($criteria2);
            
             
             $allsubgroup = [];
           
             //$allresourcegroup = [];
             $counter = 0;
             $groupcounter = 0;
             foreach($subgroup as $group){
                 //$allsubgroup[$counter] = $group->subgroup_id;
                                  
                 //obtain all the  resourcegroup within a subgroup
                 $criteria3 = new CDbCriteria();
                 $criteria3->select = 'resourcegroup_id, subgroup_id, start_date, end_date';
                 $criteria3->condition='subgroup_id=:id AND DATEDIFF(end_date, CURDATE())>= 0';
                 //$criteria3->condition='subgroup_id=:id';
                 $criteria3->params = array(':id'=>$group->subgroup_id);
                 $allresourcegroup = SubgroupHasResourcegroup::model()->findAll($criteria3); 
                 $result = array_merge($result, $allresourcegroup);
             
                 
                 $counter = $counter + 1;
                 
               //obtain the group for this subgroup
                     $criteria4 = new CDbCriteria();
                     $criteria4->select = 'id, group_id';
                     $criteria4->condition='id=:id';
                     $criteria4->params = array(':id'=>$group->subgroup_id);
                     $allgroup = SubGroup::model()->find($criteria4);
                
                   //  for($i=0; $i<=$counter; $i++){
                 
                    //obtain the resourcegroup(s) assigned to this group
                     $criteria5 = new CDbCriteria();
                     $criteria5->select = 'resourcegroup_id,group_id, max_date, end_date';
                     $criteria5->condition='group_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                     $criteria5->params = array(':id'=>$allgroup->group_id);
                    $allresourcegroup = GroupHasResourcegroup::model()->findAll($criteria5); 
                    $result = array_merge($result, $allresourcegroup);
                  
                   // $result = array_unique(array_merge($result,  $allresourcegroup));
                     //$result[] = array_unique($allresourcegroup);
                             
                 
             }
             $allresult = $result;
             $resourcegroup = [];
             $resourcegroup_container = [];
             
             foreach($allresult as $dresult){
                $resourcegroup_container[] = $dresult->resourcegroup_id;
                
                              
             }
            // $resourcegroup = (implode("," ,array_unique($resourcegroup_container)));
              $resourcegroup = array_unique($resourcegroup_container, $sort_flags=SORT_NUMERIC);
            
             $AllUserresourcegroup = [];
             $active_resourcegroup = [];
             $alluserresult_2 = [];
             $alluserresult = [];
             
             //determine the usertype and the resourcegroupl category
             
              $criteria8 = new CDbCriteria();
              $criteria8->select = 'id, usertype_id';
              $criteria8->condition='id=:id';
              $criteria8->params = array(':id'=>$user_id);
              $usertype = User::model()->find($criteria8);  
                    
              //obtain the usertype name
              $criteria8 = new CDbCriteria();
              $criteria8->select = 'id, name';
              $criteria8->condition='id=:id';
              $criteria8->params = array(':id'=>$usertype->usertype_id);
              $usertype_name = UserType::model()->find($criteria8);  
                    
              //obtain the category id corresponding to that usertype
              $criteria9 = new CDbCriteria();
              $criteria9->select = 'id, name';
              $criteria9->condition='name=:name';
              $criteria9->params = array(':name'=>$usertype_name->name);
              $category = ResourceGroupCategory::model()->find($criteria9);  

             foreach($resourcegroup as $group){
             
                    //ascertain if the resourcegroup is assigned and on scheduled on that users category
                    $criteria7 = new CDbCriteria();
                    $criteria7->select = 'resourcegroup_id,category_id, max_date, end_date';
                    $criteria7->condition='category_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                    $criteria7->params = array(':id'=>$category->id);
                    $active_resourcegroup = resourcegroupHasResourcegroupcategory::model()->findAll($criteria7);
                    
                
              //$alluserresult = array_merge($alluserresult,$AllUserresourcegroup );    
             }    
             
              
            $alluserresult_2 = array_merge($alluserresult_2,$active_resourcegroup);  
               
             foreach($alluserresult_2 as $group){
                 
               $criteria6 = new CDbCriteria();
               $criteria6->select = '*';
               $criteria6->condition='id=:id';
               $criteria6->params = array(':id'=>$group->resourcegroup_id);
               $AllUserresourcegroup = Resourcegroup::model()->findAll($criteria6); 
               
               $alluserresult = array_merge($alluserresult,$AllUserresourcegroup); 
                 
             }
            
                  
               
                if($allresourcegroup ===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" =>$alluserresult
                         //"resourcegroup" => $alluserresult_2
                                                   
                           
                       ));
                       
                } 
                
                
            }else{//advance search == true
                if($document_type == 'primary'){
                    
                    if($this->isThereAUsableDateRange($searched_start_date,$searched_end_date) == false){
                        if($this->isSearchByProcessorUserEnabled($processing_user) == false){
                               $today = new CDbExpression("UNIX_TIMESTAMP('NOW()')");
                   //convert to time
                $today_time = time($today);

                $allresourcegroup = [];
                $allsubgroupresource = [];
                 $allgroupresource = [];
                 //$allresult = [];
                $result = [];
                 $user_id = Yii::app()->user->id;
                 //$user_id = 1;
                 //$resourcegroup_id = $_REQUEST['resourcegroup_id'];
                 //$_id = 1;
                //obtain all the resourcegroup directly assigned to this user
                $criteria = new CDbCriteria();
                $criteria->select = 'resourcegroup_id, user_id, start_date, end_date';
                $criteria->condition='user_id=:userId AND DATEDIFF(end_date, CURDATE())>= 0 ';
                $criteria->params = array(':userId'=>$user_id);
                $allresourcegroup = UserHasResourcegroup::model()->findAll($criteria); 
                $result = array_merge($result, $allresourcegroup);


                 //obtain all the subgroups for this user
                 $criteria2 = new CDbCriteria();
                 $criteria2->select = 'user_id, subgroup_id';
                 $criteria2->condition='user_id=:id';
                 $criteria2->params = array(':id'=>$user_id);
                 $subgroup = UserHasSubgroups::model()->findAll($criteria2);


                 $allsubgroup = [];

                 //$allresourcegroup = [];
                 $counter = 0;
                 $groupcounter = 0;
                 foreach($subgroup as $group){
                     //$allsubgroup[$counter] = $group->subgroup_id;

                     //obtain all the  resourcegroup within a subgroup
                     $criteria3 = new CDbCriteria();
                     $criteria3->select = 'resourcegroup_id, subgroup_id, start_date, end_date';
                     $criteria3->condition='subgroup_id=:id AND DATEDIFF(end_date, CURDATE())>= 0';
                     //$criteria3->condition='subgroup_id=:id';
                     $criteria3->params = array(':id'=>$group->subgroup_id);
                     $allresourcegroup = SubgroupHasResourcegroup::model()->findAll($criteria3); 
                     $result = array_merge($result, $allresourcegroup);


                     $counter = $counter + 1;

                   //obtain the group for this subgroup
                         $criteria4 = new CDbCriteria();
                         $criteria4->select = 'id, group_id';
                         $criteria4->condition='id=:id';
                         $criteria4->params = array(':id'=>$group->subgroup_id);
                         $allgroup = SubGroup::model()->find($criteria4);

                       //  for($i=0; $i<=$counter; $i++){

                        //obtain the resourcegroup(s) assigned to this group
                         $criteria5 = new CDbCriteria();
                         $criteria5->select = 'resourcegroup_id,group_id, max_date, end_date';
                         $criteria5->condition='group_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                         $criteria5->params = array(':id'=>$allgroup->group_id);
                        $allresourcegroup = GroupHasResourcegroup::model()->findAll($criteria5); 
                        $result = array_merge($result, $allresourcegroup);

                       // $result = array_unique(array_merge($result,  $allresourcegroup));
                         //$result[] = array_unique($allresourcegroup);


                 }
                 $allresult = $result;
                 $resourcegroup = [];
                 $resourcegroup_container = [];

                 foreach($allresult as $dresult){
                    $resourcegroup_container[] = $dresult->resourcegroup_id;


                 }
                // $resourcegroup = (implode("," ,array_unique($resourcegroup_container)));
                  $resourcegroup = array_unique($resourcegroup_container, $sort_flags=SORT_NUMERIC);

                 $AllUserresourcegroup = [];
                 $active_resourcegroup = [];
                 $alluserresult_2 = [];
                 $alluserresult = [];

                 //determine the usertype and the resourcegroupl category

                  $criteria8 = new CDbCriteria();
                  $criteria8->select = 'id, usertype_id';
                  $criteria8->condition='id=:id';
                  $criteria8->params = array(':id'=>$user_id);
                  $usertype = User::model()->find($criteria8);  

                  //obtain the usertype name
                  $criteria8 = new CDbCriteria();
                  $criteria8->select = 'id, name';
                  $criteria8->condition='id=:id';
                  $criteria8->params = array(':id'=>$usertype->usertype_id);
                  $usertype_name = UserType::model()->find($criteria8);  

                  //obtain the category id corresponding to that usertype
                  $criteria9 = new CDbCriteria();
                  $criteria9->select = 'id, name';
                  $criteria9->condition='name=:name';
                  $criteria9->params = array(':name'=>$usertype_name->name);
                  $category = ResourceGroupCategory::model()->find($criteria9);  

                 foreach($resourcegroup as $group){

                        //ascertain if the resourcegroup is assigned and on scheduled on that users category
                        $criteria7 = new CDbCriteria();
                        $criteria7->select = 'resourcegroup_id,category_id, max_date, end_date';
                        $criteria7->condition='category_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                        $criteria7->params = array(':id'=>$category->id);
                        $active_resourcegroup = resourcegroupHasResourcegroupcategory::model()->findAll($criteria7);


                  //$alluserresult = array_merge($alluserresult,$AllUserresourcegroup );    
                 }    


                $alluserresult_2 = array_merge($alluserresult_2,$active_resourcegroup);  

                 foreach($alluserresult_2 as $group){

                   $criteria6 = new CDbCriteria();
                   $criteria6->select = '*';
                   $criteria6->condition='id=:id';
                   $criteria6->params = array(':id'=>$group->resourcegroup_id);
                   $AllUserresourcegroup = Resourcegroup::model()->findAll($criteria6); 

                   $alluserresult = array_merge($alluserresult,$AllUserresourcegroup); 

                 }



                    if($allresourcegroup ===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                           header('Content-Type: application/json');
                           echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "resourcegroup" =>$alluserresult
                             //"resourcegroup" => $alluserresult_2


                           ));

                    } 
                            
           }else{//user processor enabled
               
                  $today = new CDbExpression("UNIX_TIMESTAMP('NOW()')");
                   //convert to time
            $today_time = time($today);
            
            $allresourcegroup = [];
            $allsubgroupresource = [];
            $allgroupresource = [];
             //$allresult = [];
            $result = [];
             $user_id = Yii::app()->user->id;
             //$user_id = 1;
             //$resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            //obtain all the resourcegroup directly assigned to this user
            $criteria = new CDbCriteria();
            $criteria->select = 'resourcegroup_id, user_id, start_date, end_date';
            $criteria->condition='user_id=:userId AND DATEDIFF(end_date, CURDATE())>= 0 ';
            $criteria->params = array(':userId'=>$user_id);
            $allresourcegroup = UserHasResourcegroup::model()->findAll($criteria); 
            $result = array_merge($result, $allresourcegroup);
            
                      
             //obtain all the subgroups for this user
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, subgroup_id';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$user_id);
             $subgroup = UserHasSubgroups::model()->findAll($criteria2);
            
             
             $allsubgroup = [];
           
             //$allresourcegroup = [];
             $counter = 0;
             $groupcounter = 0;
             foreach($subgroup as $group){
                 //$allsubgroup[$counter] = $group->subgroup_id;
                                  
                 //obtain all the  resourcegroup within a subgroup
                 $criteria3 = new CDbCriteria();
                 $criteria3->select = 'resourcegroup_id, subgroup_id, start_date, end_date';
                 $criteria3->condition='subgroup_id=:id AND DATEDIFF(end_date, CURDATE())>= 0';
                 //$criteria3->condition='subgroup_id=:id';
                 $criteria3->params = array(':id'=>$group->subgroup_id);
                 $allresourcegroup = SubgroupHasResourcegroup::model()->findAll($criteria3); 
                 $result = array_merge($result, $allresourcegroup);
             
                 
                 $counter = $counter + 1;
                 
               //obtain the group for this subgroup
                     $criteria4 = new CDbCriteria();
                     $criteria4->select = 'id, group_id';
                     $criteria4->condition='id=:id';
                     $criteria4->params = array(':id'=>$group->subgroup_id);
                     $allgroup = SubGroup::model()->find($criteria4);
                
                   //  for($i=0; $i<=$counter; $i++){
                 
                    //obtain the resourcegroup(s) assigned to this group
                     $criteria5 = new CDbCriteria();
                     $criteria5->select = 'resourcegroup_id,group_id, max_date, end_date';
                     $criteria5->condition='group_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                     $criteria5->params = array(':id'=>$allgroup->group_id);
                    $allresourcegroup = GroupHasResourcegroup::model()->findAll($criteria5); 
                    $result = array_merge($result, $allresourcegroup);
                  
                   // $result = array_unique(array_merge($result,  $allresourcegroup));
                     //$result[] = array_unique($allresourcegroup);
                             
                 
             }
             $allresult = $result;
             $resourcegroup = [];
             $resourcegroup_container = [];
             
             foreach($allresult as $dresult){
                $resourcegroup_container[] = $dresult->resourcegroup_id;
                
                              
             }
            // $resourcegroup = (implode("," ,array_unique($resourcegroup_container)));
              $resourcegroup = array_unique($resourcegroup_container, $sort_flags=SORT_NUMERIC);
            
             $AllUserresourcegroup = [];
             $active_resourcegroup = [];
             $alluserresult_2 = [];
             $alluserresult = [];
             
             //determine the usertype and the resourcegroupl category
             
              $criteria8 = new CDbCriteria();
              $criteria8->select = 'id, usertype_id';
              $criteria8->condition='id=:id';
              $criteria8->params = array(':id'=>$user_id);
              $usertype = User::model()->find($criteria8);  
                    
              //obtain the usertype name
              $criteria8 = new CDbCriteria();
              $criteria8->select = 'id, name';
              $criteria8->condition='id=:id';
              $criteria8->params = array(':id'=>$usertype->usertype_id);
              $usertype_name = UserType::model()->find($criteria8);  
                    
              //obtain the category id corresponding to that usertype
              $criteria9 = new CDbCriteria();
              $criteria9->select = 'id, name';
              $criteria9->condition='name=:name';
              $criteria9->params = array(':name'=>$usertype_name->name);
              $category = ResourceGroupCategory::model()->find($criteria9);  

             foreach($resourcegroup as $group){
             
                    //ascertain if the resourcegroup is assigned and on scheduled on that users category
                    $criteria7 = new CDbCriteria();
                    $criteria7->select = 'resourcegroup_id,category_id, max_date, end_date';
                    $criteria7->condition='category_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                    $criteria7->params = array(':id'=>$category->id);
                    $active_resourcegroup = resourcegroupHasResourcegroupcategory::model()->findAll($criteria7);
                    
                
              //$alluserresult = array_merge($alluserresult,$AllUserresourcegroup );    
             }    
             
              
            $alluserresult_2 = array_merge($alluserresult_2,$active_resourcegroup);  
               
             foreach($alluserresult_2 as $group){
                 
               $criteria6 = new CDbCriteria();
               $criteria6->select = '*';
               $criteria6->condition='id=:id';
               $criteria6->params = array(':id'=>$group->resourcegroup_id);
               $AllUserresourcegroup = Resourcegroup::model()->findAll($criteria6); 
               if($this->isThisDocumentProcessedByThisUser($processing_user)){
                   $alluserresult = array_merge($alluserresult,$AllUserresourcegroup); 
               }
               
                 
             }
            
                  
               
                if($allresourcegroup ===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" =>$alluserresult
                         //"resourcegroup" => $alluserresult_2
                                                   
                           
                       ));
                       
                } 
               
               
               
                            
           }
                        
           }else{//there is a date range
                 
            if($this->isSearchByProcessorUserEnabled($processing_user) == false){
                      $today = new CDbExpression("UNIX_TIMESTAMP('NOW()')");
                   //convert to time
            $today_time = time($today);
            
            $allresourcegroup = [];
            $allsubgroupresource = [];
            $allgroupresource = [];
             //$allresult = [];
            $result = [];
             $user_id = Yii::app()->user->id;
             //$user_id = 1;
             //$resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            //obtain all the resourcegroup directly assigned to this user
            $criteria = new CDbCriteria();
            $criteria->select = 'resourcegroup_id, user_id, start_date, end_date';
            $criteria->condition='user_id=:userId AND DATEDIFF(end_date, CURDATE())>= 0 ';
            $criteria->params = array(':userId'=>$user_id);
            $allresourcegroup = UserHasResourcegroup::model()->findAll($criteria); 
            $result = array_merge($result, $allresourcegroup);
            
                      
             //obtain all the subgroups for this user
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, subgroup_id';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$user_id);
             $subgroup = UserHasSubgroups::model()->findAll($criteria2);
            
             
             $allsubgroup = [];
           
             //$allresourcegroup = [];
             $counter = 0;
             $groupcounter = 0;
             foreach($subgroup as $group){
                 //$allsubgroup[$counter] = $group->subgroup_id;
                                  
                 //obtain all the  resourcegroup within a subgroup
                 $criteria3 = new CDbCriteria();
                 $criteria3->select = 'resourcegroup_id, subgroup_id, start_date, end_date';
                 $criteria3->condition='subgroup_id=:id AND DATEDIFF(end_date, CURDATE())>= 0';
                 //$criteria3->condition='subgroup_id=:id';
                 $criteria3->params = array(':id'=>$group->subgroup_id);
                 $allresourcegroup = SubgroupHasResourcegroup::model()->findAll($criteria3); 
                 $result = array_merge($result, $allresourcegroup);
             
                 
                 $counter = $counter + 1;
                 
               //obtain the group for this subgroup
                     $criteria4 = new CDbCriteria();
                     $criteria4->select = 'id, group_id';
                     $criteria4->condition='id=:id';
                     $criteria4->params = array(':id'=>$group->subgroup_id);
                     $allgroup = SubGroup::model()->find($criteria4);
                
                   //  for($i=0; $i<=$counter; $i++){
                 
                    //obtain the resourcegroup(s) assigned to this group
                     $criteria5 = new CDbCriteria();
                     $criteria5->select = 'resourcegroup_id,group_id, max_date, end_date';
                     $criteria5->condition='group_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                     $criteria5->params = array(':id'=>$allgroup->group_id);
                    $allresourcegroup = GroupHasResourcegroup::model()->findAll($criteria5); 
                    $result = array_merge($result, $allresourcegroup);
                  
                   // $result = array_unique(array_merge($result,  $allresourcegroup));
                     //$result[] = array_unique($allresourcegroup);
                             
                 
             }
             $allresult = $result;
             $resourcegroup = [];
             $resourcegroup_container = [];
             
             foreach($allresult as $dresult){
                $resourcegroup_container[] = $dresult->resourcegroup_id;
                
                              
             }
            // $resourcegroup = (implode("," ,array_unique($resourcegroup_container)));
              $resourcegroup = array_unique($resourcegroup_container, $sort_flags=SORT_NUMERIC);
            
             $AllUserresourcegroup = [];
             $active_resourcegroup = [];
             $alluserresult_2 = [];
             $alluserresult = [];
             
             //determine the usertype and the resourcegroupl category
             
              $criteria8 = new CDbCriteria();
              $criteria8->select = 'id, usertype_id';
              $criteria8->condition='id=:id';
              $criteria8->params = array(':id'=>$user_id);
              $usertype = User::model()->find($criteria8);  
                    
              //obtain the usertype name
              $criteria8 = new CDbCriteria();
              $criteria8->select = 'id, name';
              $criteria8->condition='id=:id';
              $criteria8->params = array(':id'=>$usertype->usertype_id);
              $usertype_name = UserType::model()->find($criteria8);  
                    
              //obtain the category id corresponding to that usertype
              $criteria9 = new CDbCriteria();
              $criteria9->select = 'id, name';
              $criteria9->condition='name=:name';
              $criteria9->params = array(':name'=>$usertype_name->name);
              $category = ResourceGroupCategory::model()->find($criteria9);  

             foreach($resourcegroup as $group){
             
                    //ascertain if the resourcegroup is assigned and on scheduled on that users category
                    $criteria7 = new CDbCriteria();
                    $criteria7->select = 'resourcegroup_id,category_id, max_date, end_date';
                    $criteria7->condition='category_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                    $criteria7->params = array(':id'=>$category->id);
                    $active_resourcegroup = resourcegroupHasResourcegroupcategory::model()->findAll($criteria7);
                    
                
              //$alluserresult = array_merge($alluserresult,$AllUserresourcegroup );    
             }    
             
              
            $alluserresult_2 = array_merge($alluserresult_2,$active_resourcegroup);  
               
             foreach($alluserresult_2 as $group){
                 
               $criteria6 = new CDbCriteria();
               $criteria6->select = '*';
               $criteria6->condition='id=:id';
               $criteria6->params = array(':id'=>$group->resourcegroup_id);
               $AllUserresourcegroup = Resourcegroup::model()->findAll($criteria6); 
              
               $alluserresult = array_merge($alluserresult,$AllUserresourcegroup); 
               
               
                 
             }
            
                  
               
                if($allresourcegroup ===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" =>$alluserresult
                         //"resourcegroup" => $alluserresult_2
                                                   
                           
                       ));
                       
                } 
                  
              }else{//processor user is enabled                  
                  
                      $today = new CDbExpression("UNIX_TIMESTAMP('NOW()')");
                   //convert to time
            $today_time = time($today);
            
            $allresourcegroup = [];
            $allsubgroupresource = [];
            $allgroupresource = [];
             //$allresult = [];
            $result = [];
             $user_id = Yii::app()->user->id;
             //$user_id = 1;
             //$resourcegroup_id = $_REQUEST['resourcegroup_id'];
             //$_id = 1;
            //obtain all the resourcegroup directly assigned to this user
            $criteria = new CDbCriteria();
            $criteria->select = 'resourcegroup_id, user_id, start_date, end_date';
            $criteria->condition='user_id=:userId AND DATEDIFF(end_date, CURDATE())>= 0 ';
            $criteria->params = array(':userId'=>$user_id);
            $allresourcegroup = UserHasResourcegroup::model()->findAll($criteria); 
            $result = array_merge($result, $allresourcegroup);
            
                      
             //obtain all the subgroups for this user
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, subgroup_id';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$user_id);
             $subgroup = UserHasSubgroups::model()->findAll($criteria2);
            
             
             $allsubgroup = [];
           
             //$allresourcegroup = [];
             $counter = 0;
             $groupcounter = 0;
             foreach($subgroup as $group){
                 //$allsubgroup[$counter] = $group->subgroup_id;
                                  
                 //obtain all the  resourcegroup within a subgroup
                 $criteria3 = new CDbCriteria();
                 $criteria3->select = 'resourcegroup_id, subgroup_id, start_date, end_date';
                 $criteria3->condition='subgroup_id=:id AND DATEDIFF(end_date, CURDATE())>= 0';
                 //$criteria3->condition='subgroup_id=:id';
                 $criteria3->params = array(':id'=>$group->subgroup_id);
                 $allresourcegroup = SubgroupHasResourcegroup::model()->findAll($criteria3); 
                 $result = array_merge($result, $allresourcegroup);
             
                 
                 $counter = $counter + 1;
                 
               //obtain the group for this subgroup
                     $criteria4 = new CDbCriteria();
                     $criteria4->select = 'id, group_id';
                     $criteria4->condition='id=:id';
                     $criteria4->params = array(':id'=>$group->subgroup_id);
                     $allgroup = SubGroup::model()->find($criteria4);
                
                   //  for($i=0; $i<=$counter; $i++){
                 
                    //obtain the resourcegroup(s) assigned to this group
                     $criteria5 = new CDbCriteria();
                     $criteria5->select = 'resourcegroup_id,group_id, max_date, end_date';
                     $criteria5->condition='group_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                     $criteria5->params = array(':id'=>$allgroup->group_id);
                    $allresourcegroup = GroupHasResourcegroup::model()->findAll($criteria5); 
                    $result = array_merge($result, $allresourcegroup);
                  
                   // $result = array_unique(array_merge($result,  $allresourcegroup));
                     //$result[] = array_unique($allresourcegroup);
                             
                 
             }
             $allresult = $result;
             $resourcegroup = [];
             $resourcegroup_container = [];
             
             foreach($allresult as $dresult){
                $resourcegroup_container[] = $dresult->resourcegroup_id;
                
                              
             }
            // $resourcegroup = (implode("," ,array_unique($resourcegroup_container)));
              $resourcegroup = array_unique($resourcegroup_container, $sort_flags=SORT_NUMERIC);
            
             $AllUserresourcegroup = [];
             $active_resourcegroup = [];
             $alluserresult_2 = [];
             $alluserresult = [];
             
             //determine the usertype and the resourcegroupl category
             
              $criteria8 = new CDbCriteria();
              $criteria8->select = 'id, usertype_id';
              $criteria8->condition='id=:id';
              $criteria8->params = array(':id'=>$user_id);
              $usertype = User::model()->find($criteria8);  
                    
              //obtain the usertype name
              $criteria8 = new CDbCriteria();
              $criteria8->select = 'id, name';
              $criteria8->condition='id=:id';
              $criteria8->params = array(':id'=>$usertype->usertype_id);
              $usertype_name = UserType::model()->find($criteria8);  
                    
              //obtain the category id corresponding to that usertype
              $criteria9 = new CDbCriteria();
              $criteria9->select = 'id, name';
              $criteria9->condition='name=:name';
              $criteria9->params = array(':name'=>$usertype_name->name);
              $category = ResourceGroupCategory::model()->find($criteria9);  

             foreach($resourcegroup as $group){
             
                    //ascertain if the resourcegroup is assigned and on scheduled on that users category
                    $criteria7 = new CDbCriteria();
                    $criteria7->select = 'resourcegroup_id,category_id, max_date, end_date';
                    $criteria7->condition='category_id=:id AND DATEDIFF(end_date, CURDATE())>= 0 ';
                    $criteria7->params = array(':id'=>$category->id);
                    $active_resourcegroup = resourcegroupHasResourcegroupcategory::model()->findAll($criteria7);
                    
                
              //$alluserresult = array_merge($alluserresult,$AllUserresourcegroup );    
             }    
             
              
            $alluserresult_2 = array_merge($alluserresult_2,$active_resourcegroup);  
               
             foreach($alluserresult_2 as $group){
                 
               $criteria6 = new CDbCriteria();
               $criteria6->select = '*';
               $criteria6->condition='id=:id';
               $criteria6->params = array(':id'=>$group->resourcegroup_id);
               $AllUserresourcegroup = Resourcegroup::model()->findAll($criteria6); 
              if($this->isThisDocumentWithinTheDateRange()){
                 if($this->isThisDocumentProcessedByThisUser($processing_user)){
                    $alluserresult = array_merge($alluserresult,$AllUserresourcegroup); 
                }
              }
              
               
                 
             }
            
                  
               
                if($allresourcegroup ===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" =>$alluserresult
                         //"resourcegroup" => $alluserresult_2
                                                   
                           
                       ));
                       
                } 
              }
                        
                        
          }
                    
          }else{//type == complementary
               if($this->isThereAUsableDateRange($searched_start_date,$searched_end_date) == false){
                   if($this->isSearchByProcessorUserEnabled($processing_user) == false){
                       
                       
                       
                   }else{//processor user enabled
                       
                       
                   }  
                   
                   
               }else{//date range available
                   
                    if($this->isSearchByProcessorUserEnabled($processing_user) == false){
                       
                       
                       
                   }else{//processor user enabled
                       
                       
                   }  
                   
                   
                   
               }
                        
                    
          }
            }
               
               
	}
        
        
        
          /**
	 * List all the active and on scheduled toolboxes for a user
           * 
           */
	 
	public function actionListAllResourcegroupForThisUser()
	{
           

            if(isset($_REQUEST['advancedsearch'])){
                $advancedsearch = $_REQUEST['advancedsearch'];
            }else{
               $advancedsearch = false; 
            }
            if(isset($_REQUEST['search_start_date'])){
                $search_start_date = $_REQUEST['search_start_date'];
            }
            if(isset($_REQUEST['search_end_date'])){
               $search_end_date = $_REQUEST['search_end_date'];
            }
            if(isset($_REQUEST['contentsearch'])){
               $contentsearch = $_REQUEST['contentsearch'];
            }
            if(isset($_REQUEST['document_initiator'])){
                $document_initiator = $_REQUEST['document_initiator'];
            }
           
            if(isset($_REQUEST['domain_verifier'])){
               $domain_verifier = $_REQUEST['domain_verifier'];
            }
            if(isset($_REQUEST['platform_checker'])){
              $platform_checker = $_REQUEST['platform_checker'];
            }
            if(isset($_REQUEST['platform_verifier'])){
               $platform_verifier = $_REQUEST['platform_verifier'];
            }
           if(isset($_REQUEST['processing_user'])){
               $processing_user = $_REQUEST['processing_user'];
            }
            if(isset($_REQUEST['type'])){
                $documenttype = $_REQUEST['type'];  
            }
             if(isset($_REQUEST['preferred_date'])){
                $preferred_date = $_REQUEST['preferred_date'];  
            }
           
                    
            //get the user's id
            
            if(isset($_REQUEST['searchstring'])){
                $searchstring = $_REQUEST['searchstring'];
                //$string = preg_replace('/\s/', '', $searchstring);
                $searchWords = explode('+',$searchstring);
            }else{
                $searchstring="";
            }
            if(isset($_REQUEST['keyword'])){
                $keyword = $_REQUEST['keyword'];
            }else{
               $keyword="false"; 
            }
            if(isset($_REQUEST['actor'])){
                $actor = $_REQUEST['actor'];
            }else{
                $actor="false";
            }
            if(isset($_REQUEST['designation'])){
                $designation = $_REQUEST['designation'];
            }else{
               $designation="false"; 
            }
            if(isset($_REQUEST['context'])){
                $context = $_REQUEST['context'];
                
                
            }else{
                $context="false";
            }
            if(isset($_REQUEST['dcontext'])){
                    $dcontext = $_REQUEST['dcontext'];
                }
              $user_id = Yii::app()->user->id;
            
            //get the user domain
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
         
            //retrieve all subgroup that this user belong to
            $subgroups = [];
            $subgroups = $this->getAllSubgroupsThisUserBelongTo($user_id);
            
            //get all the active and on scheduled toolboxes assigned to this subgroups
            $allsubgroup_toolboxes = [];
            
            foreach($subgroups as $subgroup){
                
                $allsubgroup_toolboxes = $this->getAllToolboxesAssignedToThisSubgroup($subgroup);
            }
           
            //get all the active and on scheduled toolboxes that was directly assigned to this user
            $alluser_toolboxes = [];
            $alluser_toolboxes = $this->getAllOnScheduledToolboxesDirectlyAssignedToUser($user_id);
            
            //merge all active and on scheduled toolboxes from both subgroups and directly to user
            $alltoolboxes = [];
            
             $alltoolboxes = array_unique(array_merge($allsubgroup_toolboxes,$alluser_toolboxes));
            
            if(($searchstring =="" && $keyword == "false") && ($actor == "false" && $designation == "false") && $context== "false" ){
                
            //retrieve the details of these toolboxes
                $usable_toolboxes = [];
                foreach($alltoolboxes as $toolbox){
                 
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox);
                    $active_toolboxes = Resourcegroup::model()->find($criteria);
                    
                    if($advancedsearch == false){
                        $usable_toolboxes[] = $active_toolboxes;
                    }else{
                        if($documenttype == 'primary'){
                            if($this->isThereAUsableDateRange($search_start_date,$search_end_date) == false){
                                if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                                    $usable_toolboxes[] = $active_toolboxes;
                                }else{//processing user search enabled
                                    if($this->isThisBoxWithDocumentsProcessedByThisUser($processing_user, $active_toolboxes['id'])){
                                        $usable_toolboxes[] = $active_toolboxes;
                                    }
                                }
                            }else{//there is a date range
                                 if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                                     if($this->isBoxWithDocumentWithinTheDateRange($search_start_date,$search_end_date,$preferred_date,$active_toolboxes['id'])){
                                         $usable_toolboxes[] = $active_toolboxes;
                                     }
                                 }else{//processing date enabled
                                     if($this->isBoxWithDocumentWithinTheDateRange($search_start_date,$search_end_date,$preferred_date,$active_toolboxes['id'])){
                                        if($this->isThisBoxWithDocumentsProcessedByThisUser($processing_user, $active_toolboxes['id'])){
                                            $usable_toolboxes[] = $active_toolboxes;
                                        } 
                                     }
                                 }
                            }
                        }else{
                              $usable_toolboxes[] = $active_toolboxes;
                        }
                    }
                    
                }
   
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" =>$usable_toolboxes,
                          
                       ));
                
            }else {
                 $usable_media = [];
                if($this->isSeachStringParameterAnInfluencer($searchstring)){
                  foreach($searchWords as $word){
                      if($this->isKeywordParameterAnInfluencer($keyword)){
                          //on each of the toolboxes/media Program service confirm if there is a slot with such keyword
                          foreach($alltoolboxes as $toolbox){
                              if($this->isProgramWithMediaSlotWithSuchKeyword($toolbox,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype,$contentsearch)){
                                  $usable_media[]= $toolbox;
                              }
                          }
                      }
                      if($this->isActorParameterAnInfluencer($actor)){
                          
                          foreach($alltoolboxes as $toolbox){
                              if($this->isProgramWithMediaSlotWithSuchAnActor($toolbox,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype)){
                                  $usable_media[]= $toolbox;
                              }
                          }
                      }
                      if($this->isDesignationParameterAnInfluencer($designation)){
                          foreach($alltoolboxes as $toolbox){
                              if($this->isProgramWithMediaSlotWithSuchADesignation($toolbox,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype)){
                                  $usable_media[]= $toolbox;
                              }
                          }
                      }
                      //if there are no search influencers
                      if($this->searchStringParameterIsTheOnlyInfluencer($searchstring,$keyword,$actor,$designation,$context)){
                          //if search string parameter is the only influencer
                        $searchable_items = [];
                       // foreach($searchWords as $word){
                          $q = "SELECT id FROM resourcegroup where name REGEXP '$word'" ;
                          $cmd = Yii::app()->db->createCommand($q);
                          $results = $cmd->query();
                          foreach($results as $result){
                              foreach($alltoolboxes as $toolbox){
                                 if($result['id'] == $toolbox){
                                      $usable_media[] = $result['id'];
                                 }
                              }
                           
                        }
                          
                        
                   // } 
                   }
                   
                }// end of the foreach statement
                 if($this->isContextParameterAnInfluencer($context)){
                          $context_filtered_media =  [];
                           //find the unique toolboxes for this search
                         $search_unique = array_unique($usable_media);
                         foreach($search_unique as $media_program){
                            // if($media != "" || $media != " "){
                              if($this->isProgramWithMediaServiceWithinThisContext($media_program,$dcontext,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype)){
                                  $context_filtered_media[]= $media_program;
                              }
                            // }
                          }
                           //load the data for this toolboxes/media
                        $target_media = [];
                        foreach($context_filtered_media as $searching){
                            $criteria = new CDbCriteria();
                            $criteria->select = '*';
                            $criteria->condition='id=:id';
                            $criteria->params = array(':id'=>$searching);
                            $active_media = Resourcegroup::model()->find($criteria); 
                            $target_media[] = $active_media;
                        }
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "resourcegroup" =>$target_media,
                                "context"=>"set",
                                "search_start_date"=>$search_start_date,
                                "search_end_date"=>$search_end_date,
                                ""
                               
                            ));
                        
                          
                          
                      }else{
                                       
                            //find the unique toolboxes for this search
                         $search_unique = array_unique($usable_media);
                  
                         //load the data for this toolboxes/media
                        $target_media = [];
                        foreach($search_unique as $searching){
                            $criteria = new CDbCriteria();
                            $criteria->select = '*';
                            $criteria->condition='id=:id';
                            $criteria->params = array(':id'=>$searching);
                            $active_media = Resourcegroup::model()->find($criteria); 
                            $target_media[] = $active_media;
                        }
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "resourcegroup" =>$target_media,
                                "searching"=>$search_unique,
                                "usable"=>$usable_media,
                                "context"=>"no set"
                            ));
                        }
                        
                    
                }else{
                     if($this->isContextParameterAnInfluencer($context)){
                            //get all the media within the given context
                        
                        $target_media = [];
                        foreach($alltoolboxes as $program){
                                    if($this->isProgramWithMediaServiceWithinThisContext($program,$dcontext,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='id=:id';
                                        $criteria->params = array(':id'=>$program);
                                        $active_toolboxes = Resourcegroup::model()->find($criteria); 
                                        $target_media[] = $active_toolboxes;
                            }
                                
                        }
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "resourcegroup" =>$target_media,
                               
                            ));
                        
                            
             }else{
                   //retrieve the details of these toolboxes
                    $usable_toolboxes = [];
                    foreach($alltoolboxes as $toolbox){
                 
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='id=:id';
                        $criteria->params = array(':id'=>$toolbox);
                        $active_toolboxes = Resourcegroup::model()->find($criteria); 
                        $usable_toolboxes[] = $active_toolboxes;
                }
   
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "resourcegroup" =>$usable_toolboxes,
                           
                          
                       ));
                          
                     }
           
                }
            }//end here

             
    }
        
        
    
    /**
     * This is the function that determines if a box has a document processed by a particular user
     */
    public function isThisBoxWithDocumentsProcessedByThisUser($processing_user, $box_id){
        //get all the batches & files  in this box
        $batches = $this->retrieveAllToolsInThisToolbox($box_id);
        
        $counter = 0;
        foreach($batches as $batch){
            if($this->isThisBatchWithDocumentsProcessedByThisUser($processing_user,$batch)){
                $counter = $counter + 1;
            }
        }
        if($counter > 0){
            return true;
        }else{
            return false;
        }        
                
        
    }
    
    
    /**
     * This is the function that determines if a particular user processed a document
     */
    public function isThisBatchWithDocumentsProcessedByThisUser($processing_user,$batch){
        $documents = $this->retrieveAllTasksForThisTool($batch);
        
        $counter = 0;
        foreach($documents as $document){
            if($this->isDocumentProcessedByUser($document,$processing_user)){
                $counter = $counter + 1;
            }
        }
        if($counter >0){
            return true;
        }else{
            return false;
        }
    }
    
    
    /**
     * This is the function that determines if document is processed by a user
     */
    public function isDocumentProcessedByUser($document,$processing_user){
        
               $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("id = $document and create_user_id=$processing_user");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
    }
    
    /**
     * This is the function that dtermines if a box has a document that was processed within a date range
     */
    public function isBoxWithDocumentWithinTheDateRange($searched_start_date,$searched_end_date,$preferred_date,$box_id){
        //get all the batches & files  in this box
        $batches = $this->retrieveAllToolsInThisToolbox($box_id);
        $counter = 0;
        foreach($batches as $batch){
            if($this->isThisBatchWithDocumentsWithinThisDateRange($searched_start_date,$searched_end_date,$preferred_date,$batch)){
                $counter = $counter + 1;
            }
        }
        if($counter > 0){
            return true;
        }else{
            return false;
        }   
        
        
    }
        
    
    /**
     * This is the function that batches with document within date range
     */
    public function isThisBatchWithDocumentsWithinThisDateRange($searched_start_date,$searched_end_date,$preferred_date,$batch){
        $documents = $this->retrieveAllTasksForThisToolByThisDateRange($batch,$searched_start_date,$searched_end_date,$preferred_date);
       
        $counter = 0;
        foreach($documents as $document){
            if(!empty($document)){
                $counter = $counter + 1;
            }
        }
        if($counter>0){
            return true;
        }else{
            return false;
        }
    }
    
    
    
     
    
    
  
        /**
         * This is the function that determines if search string is a search influencer
         */
        public function isSeachStringParameterAnInfluencer($searchstring){
            if($searchstring != ""){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that determines if keyword is a search influencer
         */
        public function isKeywordParameterAnInfluencer($keyword){
            if($keyword ==="true" || $keyword === true){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that determines if actor is a search influencer
         */
        public function isActorParameterAnInfluencer($actor){
            if($actor ==="true" || $actor === true){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that determines if destination is a search influencer 
         */
        public function isDesignationParameterAnInfluencer($designation){
            if($designation === "true" || $designation === true){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that determines if a context is a search influencer
         */
        public function isContextParameterAnInfluencer($context){
            if($context === "true" || $context === true){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms that only the search string is the available for th search
         * 
         */
        public function searchStringParameterIsTheOnlyInfluencer($searchstring,$keyword,$actor,$designation,$context){
            if($this->isKeywordParameterAnInfluencer($keyword)===false && $this->isActorParameterAnInfluencer($actor) ===false && $this->isDesignationParameterAnInfluencer($designation)=== false){
                if($this->isSeachStringParameterAnInfluencer($searchstring) === true){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that searchs through the program/event to  confirm the existence of a keyword
         */
        public function isProgramWithMediaSlotWithSuchKeyword($toolbox_id,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype,$contentsearch){
          
            //get all the slots in this program
            //$all_slots = [];
            $all_sessions = $this->retrieveAllToolsInThisToolbox($toolbox_id);
            $keyword_counter = 0;
            //for each of the tools/session retrieve their task/slot and confirm the existence of that keyword
            foreach($all_sessions as $session){
                if($this->isThisKeywordInAnySlotInThisSession($session,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype,$contentsearch)){
                    $keyword_counter = $keyword_counter + 1;
                }
            }
           if($keyword_counter >0){
               return true;
           }else{
               return false;
           }
        }
        
        
        
        /**
         * This is the function that searches through a session/tool for a keyword
         */
        public function isThisKeywordInAnySlotInThisSession($session_id,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype,$contentsearch){
            
              
            if($advancedsearch == false){
                //retrieve all the slot/task in this session/tool
                $all_slots = $this->retrieveAllTasksForThisTool($session_id);
            }else{
                if($documenttype == 'primary'){
                    if($this->isThereAUsableDateRange($search_start_date,$search_end_date) == false){
                        if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                            $all_slots = $this->retrieveAllTasksForThisTool($session_id);
                        }else{//processing user enabled
                            $all_slots = $this->retrieveAllTasksForThisToolByThisUser($session_id,$processing_user);
                        }
                    }else{//date range available
                         if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRange($session_id,$search_start_date,$search_end_date,$preferred_date);
                         }else{//processing user enabled
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRangeAndUser($session_id,$search_start_date,$search_end_date,$preferred_date,$processing_user);
                         }
                    }
              }else if($documenttype == 'complementary'){//document type is complementary
                   if($this->isThereAUsableDateRange($search_start_date,$search_end_date) == false){
                        if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                            $all_slots = $this->retrieveAllTasksForThisTool($session_id);
                        }else{//processing user enabled
                            $all_slots = $this->retrieveAllTasksForThisToolByThisUser($session_id,$processing_user);
                        }
                    }else{//date range available
                         if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRange($session_id,$search_start_date,$search_end_date,$preferred_date);
                         }else{//processing user enabled
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRangeAndUser($session_id,$search_start_date,$search_end_date,$preferred_date,$processing_user);
                         }
                    }
                    
                }
            }
            
            
            $keyword_counter = 0;
            foreach($all_slots as $slot){
                if($this->isThisKeywordInThisSlot($slot,$word,$documenttype,$contentsearch)){
                    $keyword_counter = $keyword_counter + 1;
                }
            }
            if($keyword_counter >0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms the existence of a keyword in amedia slot
         */
        public function isThisKeywordInThisSlot($slot_id,$word,$documenttype,$contentsearch){
            
           
         if($documenttype == 'primary'){
                
             //get all the keywords with this media slot 
            $slot_keywords = $this->retrieveAllKeywordsInThisMediaSlot($slot_id);
            
            //examine the word in each of these keywords
            $counter = 0;
            foreach($slot_keywords as $keyword){
                if($this->isSearchWordPartOfASlotKeyword($keyword, $word)){
                    $counter = $counter + 1;
                }
            }
            
            if($counter > 0){
                return  true;
            }else{
                return false;
            }
                
                
        }else if($documenttype == 'complementary'){//type is complementary
                //get all complementary resoures for this document
                $comp_resources = $this->retrieveAllComplementaryResourcesForThisDocument($slot_id);
            
                //examine the word in each of these keywords
                $counter = 0;
                foreach($comp_resources as $comp){
                    if($this->isThisKeywordInThisComplementaryResource($comp,$word)){
                        $counter = $counter + 1;
                    }
                   if($contentsearch == true){
                        if($this->isThisKeywordInThisDocumentContent($comp,$word)){
                            $counter = $counter + 1;
                        }
                    }
                }
           
                if($counter > 0){
                     return  true;
                }else{
                    return false;
                }
                
            }
            
        }
        
        
        /**
         * This is the function that reads document content to search for a word or phrase
         */
        public function isThisKeywordInThisDocumentContent($comp,$word){
            if($this->isThisANonScannedDocument($comp)){
                if($this->isThisAPdfDocument($comp)){
                    if($this->isThisKeywordOrPhraseInThisDocument($comp,$word)){
                        return true;
                    }else{
                        return false;
                    }
                    
                    
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that determines if a complementary document is a pdf document
         * 
         */
        public function isThisAPdfDocument($document_id){
            //get the document name
            
            $doc_name = $this->getThisComplementaryDocumentName($document_id);
            
            //test for the extension of the file
            if(strtolower(substr("$doc_name",-4)) == ".pdf"){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that searches the content of a pdf file in search of a word
         */
        public function isThisKeywordOrPhraseInThisDocument($comp,$word){
            
        }
        
         /**
         * Date range testing function
         */
        public function actionTester(){
            $batch = 1;
            $searched_start_date = "2016-01-10T00:00:00";
            $searched_end_date = "2016-12-20T00:00:00";
            $preferred_date = "captured_date";
            $task = $this->isThisAPdfDocument($document_id);
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                     "task" => $task,
                                    
                               
                            ));
        }
        
    
        
        /**
         * This is the function that gets the complementary document filename
         */
        public function getThisComplementaryDocumentName($document_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$document_id);
               $comp= DocumentResource::model()->find($criteria);
               
               return $comp['filename'];
        }
        
        /**
         * This is the function that gets the input type of a complementary document resource
         */
        public function isThisANonScannedDocument($comp){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('document_resource')
                    ->where("id = $comp and input_type='unscanned'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        /**
         * This is the function that determines if a keyword is in a complementary document
         */
        public function isThisKeywordInThisComplementaryResource($comp,$word){
            $document_keywords = $this->retrieveAllKeywordsInThisComplementaryDocument($comp);
            
            //examine the word in each of these keywords
            $counter = 0;
            foreach($document_keywords as $keyword){
                if($this->isSearchWordPartOfAComplementaryDocumentKeyword($keyword, $word)){
                    $counter = $counter + 1;
                }
            }
            
            if($counter > 0){
                return  true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that retrieves all keywords from a complementary document
         */
        public function retrieveAllKeywordsInThisComplementaryDocument($comp_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='document_resource_id=:id';
               $criteria->params = array(':id'=>$comp_id);
               $keywords= DocumentResourceKeyword::model()->findAll($criteria);
               
               $allkeywords = [];
               foreach($keywords as $keyword){
                   
                   $allkeywords[] = $keyword['id'];
               }
            
               return $allkeywords;
            
            
        }
        
        /**
         * This is the function that determines if search word is part of a complementary document keyword
         */
        public function isSearchWordPartOfAComplementaryDocumentKeyword($keyword_id, $word){
             $cmd =Yii::app()->db->createCommand();
               $cmd->select('COUNT(*)')
                    ->from('document_resource_keyword')
                    ->where("id = $keyword_id and keyword REGEXP '$word'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        /**
         * This is the function that retrieves all complementary resources for a document
         */
        public function retrieveAllComplementaryResourcesForThisDocument($document_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='primary_document_id=:id';
               $criteria->params = array(':id'=>$document_id);
               $comps= DocumentResource::model()->findAll($criteria);
               
               $allcomps = [];
               foreach($comps as $comp){
                   
                   $allcomps[] = $comp['id'];
               }
            
               return $allcomps;
            
        }
        
        
        
        /**
         * This is the function that confirms if a searched word is in a slot keyword
         */
        public function isSearchWordPartOfASlotKeyword($keyword_id, $word){
             $cmd =Yii::app()->db->createCommand();
               $cmd->select('COUNT(*)')
                    ->from('keywords')
                    ->where("id = $keyword_id and keyword REGEXP '$word'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that retrieves the entire slot keywords
         */
        public function retrieveAllKeywordsInThisMediaSlot($slot_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='media_id=:id';
               $criteria->params = array(':id'=>$slot_id);
               $keywords= MediaHasKeywords::model()->findAll($criteria);
               
               $allkeywords = [];
               foreach($keywords as $keyword){
                   
                   $allkeywords[] = $keyword['keyword_id'];
               }
            
               return $allkeywords;
            
        }
        
        
        /**
         * This is the function that retrieves all keywords in a document resource
         */
        public function retrieveAllKeywordsInThisDocumentResource($slot_id){
            $complementary_docs = $this->getAllTheComplementaryResourcesForThisDocument($slot_id);   
            
            
            $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='media_id=:id';
               $criteria->params = array(':id'=>$slot_id);
               $keywords= MediaHasKeywords::model()->findAll($criteria);
               
               $allkeywords = [];
               foreach($keywords as $keyword){
                   
                   $allkeywords[] = $keyword['keyword_id'];
               }
            
               return $allkeywords;
            
        }
        
        /**
         * This is the function that searches through a program/event to confirm the existence of an actor in a search
         */
        public function isProgramWithMediaSlotWithSuchAnActor($toolbox_id,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype){
            
            //get all the slots in this program
            //$all_slots = [];
            $all_sessions = $this->retrieveAllToolsInThisToolbox($toolbox_id);
            $actor_counter = 0;
            //for each of the tools/session retrieve their task/slot and confirm the existence of that keyword
            foreach($all_sessions as $session){
                if($this->isThisActorInAnySlotInThisSession($session,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype)){
                    $actor_counter = $actor_counter + 1;
                }
            }
           if($actor_counter >0){
               return true;
           }else{
               return false;
           }
            
        }
        
        /**
         * This is the function that confirms if the search actor is in any slot in a session
         */
        public function isThisActorInAnySlotInThisSession($session_id,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype){
            
            
            if($advancedsearch == false){
                //retrieve all the slot/task in this session/tool
                $all_slots = $this->retrieveAllTasksForThisTool($session_id);
            }else{
                if($documenttype == 'primary'){
                    if($this->isThereAUsableDateRange($search_start_date,$search_end_date) == false){
                        if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                            $all_slots = $this->retrieveAllTasksForThisTool($session_id);
                        }else{//processing user enabled
                            $all_slots = $this->retrieveAllTasksForThisToolByThisUser($session_id,$processing_user);
                        }
                    }else{//date range available
                         if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRange($session_id,$search_start_date,$search_end_date,$preferred_date);
                         }else{//processing user enabled
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRangeAndUser($session_id,$search_start_date,$search_end_date,$preferred_date,$processing_user);
                         }
                    }
                }else{//document type is complementary
                    //add the required code here
                    
                }
            }
            
            $actor_counter = 0;
            foreach($all_slots as $slot){
                if($this->isThisActorInThisSlot($slot,$word)){
                    $actor_counter = $actor_counter + 1;
                }
            }
            if($actor_counter >0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        
        /**
         * This is the function that verifies the existence of the searched actor in a slot
         */
        public function isThisActorInThisSlot($slot_id,$word){
            
             //get all the keywords with this media slot 
            $slot_actors = $this->retrieveAllActorsInThisMediaSlot($slot_id);
            
            //examine the word in each of these keywords
            $counter = 0;
            foreach($slot_actors as $actor){
                if($this->isSearchWordPartOfASlotActor($actor, $word)){
                    $counter = $counter + 1;
                }
            }
            
            if($counter > 0){
                return  true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if a searched word is part of slot actor
         */
        public function isSearchWordPartOfASlotActor($actor_id, $word){
            
            $cmd =Yii::app()->db->createCommand();
               $cmd->select('COUNT(*)')
                    ->from('actors')
                    ->where("id = $actor_id and name REGEXP '$word'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves all actors in a media slot
         */
        public function retrieveAllActorsInThisMediaSlot($slot_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='media_id=:id';
               $criteria->params = array(':id'=>$slot_id);
               $actors= MediaHasKeywords::model()->findAll($criteria);
               
               $allactors = [];
               foreach($actors as $actor){
                   
                   $allactors[] = $actor['actor_id'];
               }
            
               return $allactors;
            
        }
        
        
        /**
         * This is the function that searches through a program to determine if a slot has actor with this searched designation
         */
        public function isProgramWithMediaSlotWithSuchADesignation($toolbox_id,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype){
            
            //get all the slots in this program
            //$all_slots = [];
            $all_sessions = $this->retrieveAllToolsInThisToolbox($toolbox_id);
            $actor_counter = 0;
            //for each of the tools/session retrieve their task/slot and confirm the existence of that keyword
            foreach($all_sessions as $session){
                if($this->isThisDesignationInAnySlotInThisSession($session,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype)){
                    $actor_counter = $actor_counter + 1;
                }
            }
           if($actor_counter >0){
               return true;
           }else{
               return false;
           }
            
            
            
        }
        
        
        /**
         * This is the function  that confirms if a designation in the search is in a slot
         */
        public function isThisDesignationInAnySlotInThisSession($session_id,$word,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype){
            
           if($advancedsearch == false){
                //retrieve all the slot/task in this session/tool
                $all_slots = $this->retrieveAllTasksForThisTool($session_id);
            }else{
                if($documenttype == 'primary'){
                    if($this->isThereAUsableDateRange($search_start_date,$search_end_date) == false){
                        if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                            $all_slots = $this->retrieveAllTasksForThisTool($session_id);
                        }else{//processing user enabled
                            $all_slots = $this->retrieveAllTasksForThisToolByThisUser($session_id,$processing_user);
                        }
                    }else{//date range available
                         if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRange($session_id,$search_start_date,$search_end_date,$preferred_date);
                         }else{//processing user enabled
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRangeAndUser($session_id,$search_start_date,$search_end_date,$preferred_date,$processing_user);
                         }
                    }
                }else{//document type is complementary
                    //add the required code here
                    
                }
            }
            
            $designation_counter = 0;
            foreach($all_slots as $slot){
                if($this->isThisDesignationInThisSlot($slot,$word)){
                    $designation_counter = $designation_counter + 1;
                }
            }
            if($designation_counter >0){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that determines if search by processor user is enabled
         */
        public function isSearchByProcessorUserEnabled($processing_user){
            //if($processing_user == "" or $processing_user=" " or $processing_user==null){
            if(empty($processing_user)){       
                return false;
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that determines if there is a date range 
         */
        public function isThereAUsableDateRange($searched_start_date,$searched_end_date){
           // if(($searched_start_date == "" and $searched_end_date =="") or ($searched_start_date == " " and $searched_end_date ==" ") or ($searched_start_date == null and $searched_end_date ==null)){
            if(empty($searched_start_date) and empty($searched_end_date)){    
                return false;
            }else{
                return true;
            }
        }
        
        /**
         * This is the function that verifies if a designation is in a slot
         */
        public function isThisDesignationInThisSlot($slot_id,$word){
            
              //get all the keywords with this media slot 
            $slot_designation = $this->retrieveAllDesignationsInThisMediaSlot($slot_id);
            
            //examine the word in each of these keywords
            $counter = 0;
            foreach($slot_designation as $designation){
                if($this->isSearchWordPartOfASlotDesignation($designation, $word)){
                    $counter = $counter + 1;
                }
            }
            
            if($counter > 0){
                return  true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that confirms if a search word is part of an actor designation in a media
         */
        public function isSearchWordPartOfASlotDesignation($designation_id, $word){
            
             $cmd =Yii::app()->db->createCommand();
               $cmd->select('COUNT(*)')
                    ->from('designations')
                    ->where("id = $designation_id and designation REGEXP '$word'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves all designations in a slot
         */
        public function retrieveAllDesignationsInThisMediaSlot($slot_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='media_id=:id';
               $criteria->params = array(':id'=>$slot_id);
               $designations= MediaHasKeywords::model()->findAll($criteria);
               
               $alldesignations = [];
               foreach($designations as $designation){
                   
                   $alldesignations[] = $designation['designation_id'];
               }
            
               return $alldesignations;
            
        }
        
        /**
         * This is the function  that verifies if a media is within a given context
         */
        public function isProgramWithMediaServiceWithinThisContext($program_id,$dcontext_id,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype){
            
            //get all the slots in this program
            //$all_slots = [];
            $all_sessions = $this->retrieveAllToolsInThisToolbox($program_id);
            $context_counter = 0;
            //for each of the tools/session retrieve their task/slot and confirm the existence of that that context
            foreach($all_sessions as $session){
                if($this->isThisContextInAnySlotInThisSession($session,$dcontext_id,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype)){
                    $context_counter = $context_counter + 1;
                }
            }
           if($context_counter >0){
              return true;
              
           }else{
             return false;
           }
                
  
        }
        
        
         /**
         * This is the function that determines the existence of a context attributable to a media session
         */
        public function  isThisContextInAnySlotInThisSession($session_id, $context_id,$processing_user,$search_start_date,$search_end_date,$preferred_date,$advancedsearch,$documenttype){
            
       if($advancedsearch == false){
                //retrieve all the slot/task in this session/tool
                $all_slots = $this->retrieveAllTasksForThisTool($session_id);
            }else{
                if($documenttype == 'primary'){
                    if($this->isThereAUsableDateRange($search_start_date,$search_end_date) == false){
                        if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                            $all_slots = $this->retrieveAllTasksForThisTool($session_id);
                        }else{//processing user enabled
                            $all_slots = $this->retrieveAllTasksForThisToolByThisUser($session_id,$processing_user);
                        }
                    }else{//date range available
                         if($this->isSearchByProcessorUserEnabled($processing_user)== false){
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRange($session_id,$search_start_date,$search_end_date,$preferred_date);
                         }else{//processing user enabled
                             $all_slots = $this->retrieveAllTasksForThisToolByThisDateRangeAndUser($session_id,$search_start_date,$search_end_date,$preferred_date,$processing_user);
                         }
                    }
                }else{//document type is complementary
                    //add the required code here
                    
                }
            }
            
            $context_counter = 0;
            foreach($all_slots as $slot){
                if($this->isContextInThisSlot($slot,$context_id )){
                    $context_counter = $context_counter + 1;
                }
            }
            if($context_counter >0){
               return true;
              }else{
               return false;
               
            }
        }
        
        
        
        /**
         * This is the function that determines if this context is in this slot
         */
        public function isContextInThisSlot($slot_id, $context_id){
            
             //get all the context with this media slot 
            $slot_context = $this->retrieveAllThisMediaContext($slot_id);
            
            if(in_array($context_id,$slot_context)){
                return true;
                
            }else{
                return false;
               
            }
            
        
        }
        
        
        
        /**
         * This is the function that retrieves all context in a media slot
         */
        public function retrieveAllThisMediaContext($slot_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='media_id=:id';
               $criteria->params = array(':id'=>$slot_id);
               $contexts= MediaHasKeywords::model()->findAll($criteria);
               
               $allcontexts = [];
               foreach($contexts as $context){
                   
                   $allcontexts[] = $context['context_id'];
               }
            
               return $allcontexts;
            
            
        }
        
        
       
        
        
        /**
         * This is the function that gets all the subgroups that this user is active in
         */
        public function getAllSubgroupsThisUserBelongTo($user_id){
            
            //retrieve all subgroups that this  user belong to
            
            $all_subgroups = $this->getAllSubgroupsForThisUser($user_id);
            
            $active_subgroup = [];
            foreach($all_subgroups as $subgroup){
                if($this->isUserOnScheduledInThisSubgroup($subgroup,$user_id)){
                    $active_subgroup [] = $subgroup;
                }
                
            }
            return $active_subgroup;

        }
        
        
        /**
         * This is the function that retrieves all subgroups a user had ever been assigned to 
         */
        public function getAllSubgroupsForThisUser($user_id){
            
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='user_id=:id';
                 $criteria->params = array(':id'=>$user_id);
                 $subgroups = UserHasSubgroups::model()->findAll($criteria);
                 
                 $allsubgroups = [];
                 foreach($subgroups as $subgroup){
                     $allsubgroups[] = $subgroup['subgroup_id'];
                 }
                 return $allsubgroups;
            
        }
        
        
        /**
         * This is the function that determines if a user is on schedule in a subgroup
         */
        public function isUserOnScheduledInThisSubgroup($subgroup,$user_id){
            
                       
            //retrieve the start date for this user in the subgroup
            $start_date = $this->getTheStartScheduledDateForThisUserInThisSubgroup($subgroup,$user_id);
            
            //get the end date for this user in the subgroup
            $end_date = $this->getTheEndScheduledDateForThisUserInThisSubgroup($subgroup,$user_id);
            
            if($this->isThisPeriodWithinSchedule($start_date,$end_date)){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function that gets the start date for this users schedule in a subgroup
         */
        public function getTheStartScheduledDateForThisUserInThisSubgroup($subgroup_id,$user_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='user_id=:id and subgroup_id=:subgroup';
                 $criteria->params = array(':id'=>$user_id,':subgroup'=>$subgroup_id);
                 $date = UserHasSubgroups::model()->find($criteria);
                 
                 return $date['start_date'];
            
        }
        
        
        /**
         * This is the function that gets the end date for this users schedule in a subgroup
         */
        public function getTheEndScheduledDateForThisUserInThisSubgroup($subgroup_id,$user_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='user_id=:id and subgroup_id=:subgroup';
                 $criteria->params = array(':id'=>$user_id,':subgroup'=>$subgroup_id);
                 $date = UserHasSubgroups::model()->find($criteria);
                 
                 return $date['end_date'];
            
        }
        
        
        /**
         * This is the function that determines if a period is within schedule
         */
        public function isThisPeriodWithinSchedule($start_date,$end_date){
            
            $today = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            
            if($today <=$end_date ){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function that gets all toolboxes assigned to subgroup
         */
        public function getAllToolboxesAssignedToThisSubgroup($subgroup_id){
            //get the group_id of this subgroup
            $group_id = $this->getTheGroupIdOfThisSubgroup($subgroup_id);
            
            //get all toolboxes directly assigned to this group
            $group_toolboxes = [];
            $group_toolboxes = $this->getThisGroupToolboxesThatAreOnSchedule($group_id);
            
            //get the on scheduled toolboxes assigned to a subgroup
            $subgroup_toolboxes = [];
            $subgroup_toolboxes = $this->getThisSubgroupToolboxesThatAreOnSchedule($subgroup_id);
            
            $thissubgroup_toolboxes = [];
            //merge both group and the subgroup toolboxes
            //$thissubgroup_toolboxes = array_unique(array_merge($group_toolboxes,$subgroup_toolboxes));
            
              $thissubgroup_toolboxes = array_merge($group_toolboxes,$subgroup_toolboxes);
            
            
            return $thissubgroup_toolboxes;
        }
        
        
        
        /**
         * This is the function that gets a group's active and on schedule toolboxes
         */
        public function getThisGroupToolboxesThatAreOnSchedule($group_id){
            
                //get the logged in user id
                $user_id = Yii::app()->user->id;
                
                //user domain is
                $domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='group_id=:id';
                 $criteria->params = array(':id'=>$group_id);
                 $toolboxes = GroupHasResourcegroup::model()->findAll($criteria);
                 
                 $active_toolboxes = [];
                 foreach($toolboxes as $toolbox){
                     if($this->isToolboxActiveAndOnScheduleOnThisDomain($domain_id,$toolbox['resourcegroup_id'])){
                         if($this->isToolboxInThisGroupOnSchedule($group_id,$toolbox['resourcegroup_id'])){
                            $active_toolboxes[] = $toolbox['resourcegroup_id'];
                        }
                     }
                     
                 }
                 return $active_toolboxes;
        }
        
        /**
         * This is the function that determines if a toolbox is active and on schedule on a domain
         */
        public function isToolboxActiveAndOnScheduleOnThisDomain($domain_id,$toolbox_id){
            
            if($this->isToolboxActiveOnThisDomain($domain_id,$toolbox_id)){
                if($this->isThisToolboxOnScheduleOnThisDomain($domain_id,$toolbox_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that determines if a toolbox is active on a domain
         */
        public function isToolboxActiveOnThisDomain($domain_id,$toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='category_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$domain_id,':resgroupid'=>$toolbox_id);
                 $domain = ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                 
               if($domain['toolbox_status']=="active"){
                   return true;
               }else{
                   return false;
               }
            
        }
        
        
        /**
         * This is the function that determines if a toolbox is on schedule on a domain
         */
        public function isThisToolboxOnScheduleOnThisDomain($domain_id,$toolbox_id){
            
             //retrieve the start date for this toolbox in this domain
            $start_date = $this->getTheStartScheduledDateForThisToolboxInThisDomain($domain_id,$toolbox_id);
            
            //get the end date for this toolbox in this domain
            $end_date = $this->getTheEndScheduledDateForThisToolboxInThisDomain($domain_id,$toolbox_id);
            
            if($this->isThisPeriodWithinSchedule($start_date,$end_date)){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that gets the start date of a toolbox in a domain
         */
        public function getTheStartScheduledDateForThisToolboxInThisDomain($domain_id,$toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='category_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$domain_id,':resgroupid'=>$toolbox_id);
                 $period = ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                 
                 return $period['start_date'];
            
        }
        
         /**
         * This is the function that gets the start date of a toolbox in a domain
         */
        public function getTheEndScheduledDateForThisToolboxInThisDomain($domain_id,$toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='category_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$domain_id,':resgroupid'=>$toolbox_id);
                 $period = ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                 
                 return $period['end_date'];
            
        }
        
        /**
         * This is the function that determines if a toolbox in a group is on schedule
         */
        public function isToolboxInThisGroupOnSchedule($group_id,$toolbox_id){
            
             //retrieve the start date for this user in the subgroup
            $start_date = $this->getTheStartScheduledDateForThisToolboxInThisGroup($group_id,$toolbox_id);
            
            //get the end date for this user in the subgroup
            $end_date = $this->getTheEndScheduledDateForThisToolboxInThisGroup($group_id,$toolbox_id);
            
            if($this->isThisPeriodWithinSchedule($start_date,$end_date)){
                return true;
            }else{
                return false;
            }
            
        }
       
        
        /**
         * This is the function that gets the start date for a toolbox in a grouo
         */
        public function getTheStartScheduledDateForThisToolboxInThisGroup($group_id,$toolbox_id){
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='group_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$group_id,':resgroupid'=>$toolbox_id);
                 $period = GroupHasResourcegroup::model()->find($criteria);
                 
                 return $period['start_date'];
            
        }
        
        /**
         * This is the function that gets the end date for a toolbox in a group
         */
        public function getTheEndScheduledDateForThisToolboxInThisGroup($group_id,$toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='group_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$group_id,':resgroupid'=>$toolbox_id);
                 $period = GroupHasResourcegroup::model()->find($criteria);
                 
                 return $period['end_date'];
            
            
        }
        
        
        /**
         * This is the function that gets all the toolboxes assigned to a subgroup directly
         */
        public function getThisSubgroupToolboxesThatAreOnSchedule($subgroup_id){
            
            
            //get the logged in user
            $user_id = Yii::app()->user->id;
            //get the domain
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            //retrieve all toolboxes assigned to this group
            $toolboxes = [];
            $toolboxes = $this->getAllToolboxesInThisSubgroup($subgroup_id);
            
            $active_toolboxes = [];
            
            foreach($toolboxes as $toolbox){
                if($this->isToolboxActiveAndOnScheduleOnThisDomain($domain_id,$toolbox)){
                    if($this->isThisToolboxOnScheduleInThisSubgroup($toolbox,$subgroup_id)){
                        $active_toolboxes[] = $toolbox;
                    }
                }
               
            }
            return $active_toolboxes;
            
            
        }

        
        /**
         * This is the function that gets all the toolboxes assigned to a subgroup
         */
        public function getAllToolboxesInThisSubgroup($subgroup_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='subgroup_id=:id';
                 $criteria->params = array(':id'=>$subgroup_id);
                 $toolboxes = SubgroupHasResourcegroup::model()->findAll($criteria);
                 
                 $alltoolboxes = [];
                 foreach($toolboxes as $toolbox){
                     $alltoolboxes[] = $toolbox['resourcegroup_id'];
                 }
            
                 return $alltoolboxes;
        }
        
        
        /**
         * This is the function that detet=rmines if a toolbox in a subgroup is on schedule
         */
        public function isThisToolboxOnScheduleInThisSubgroup($toolbox_id,$subgroup_id){
            
             //retrieve the start date for this user in the subgroup
            $start_date = $this->getTheStartScheduledDateForThisToolboxInThisSubgroup($subgroup_id,$toolbox_id);
            
            //get the end date for this user in the subgroup
            $end_date = $this->getTheEndScheduledDateForThisToolboxInThisSubgroup($subgroup_id,$toolbox_id);
            
            if($this->isThisPeriodWithinSchedule($start_date,$end_date)){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function the retrieves the start date of a toolbox in a subgroup
         */
        public function getTheStartScheduledDateForThisToolboxInThisSubgroup($subgroup_id,$toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='subgroup_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$subgroup_id,':resgroupid'=>$toolbox_id);
                 $period = SubgroupHasResourcegroup::model()->find($criteria);
                 
                 return $period['start_date'];
            
        }
        
         /**
         * This is the function the retrieves the start date of a toolbox in a subgroup
         */
        public function getTheEndScheduledDateForThisToolboxInThisSubgroup($subgroup_id,$toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='subgroup_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$subgroup_id,':resgroupid'=>$toolbox_id);
                 $period = SubgroupHasResourcegroup::model()->find($criteria);
                 
                 return $period['end_date'];
            
        }
        
        
        /**
         * This is the function that gets all the active and on schedule toolboxes directly assigned to a user
         */
        public function getAllOnScheduledToolboxesDirectlyAssignedToUser($user_id){
            
            //get the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain id
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='user_id=:id';
                 $criteria->params = array(':id'=>$user_id);
                 $toolboxes = UserHasResourcegroup::model()->findAll($criteria);
                 
                 $active_toolboxes = [];
                 foreach($toolboxes as $toolbox){
                     if($this->isToolboxActiveAndOnScheduleOnThisDomain($domain_id,$toolbox['resourcegroup_id'])){
                          if($this->isToolboxForThisUserOnSchedule($user_id,$toolbox['resourcegroup_id'])){
                                $active_toolboxes[] = $toolbox['resourcegroup_id'];
                            }
                     }
                    
                 }
                 return $active_toolboxes;
            
        }
        
        
        /**
         * This is the function that determines if a toolbox is on scheduled for a user
         */
        public function isToolboxForThisUserOnSchedule($user_id,$toolbox_id){
            
             //retrieve the start date for this toolbox for this user
            $start_date = $this->getTheStartScheduledDateForThisToolboxForThiUser($user_id,$toolbox_id);
            
            //get the end date for this toolbox for this user
            $end_date = $this->getTheEndScheduledDateForThisToolboxForThisUser($user_id,$toolbox_id);
            
            if($this->isThisPeriodWithinSchedule($start_date,$end_date)){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that gets the start date for a toolbox directly assigned to a yser
         */
        public function getTheStartScheduledDateForThisToolboxForThiUser($user_id,$toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='user_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$user_id,':resgroupid'=>$toolbox_id);
                 $period = UserHasResourcegroup::model()->find($criteria);
                 
                 return $period['start_date'];
            
            
        }
        
        
        
        /**
         * This is the function that gets the start date for a toolbox directly assigned to a yser
         */
        public function getTheEndScheduledDateForThisToolboxForThisUser($user_id,$toolbox_id){
            
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='user_id=:id and resourcegroup_id=:resgroupid';
                 $criteria->params = array(':id'=>$user_id,':resgroupid'=>$toolbox_id);
                 $period = UserHasResourcegroup::model()->find($criteria);
                 
                 return $period['end_date'];
            
            
        }
        
        /**
	 * assign a resourcegroup to a group for single assignment process
	 */
	public function actionAssignSingleResourcegroupToGroup()
	{
		
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             $group_id = $_REQUEST['group_id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
			 
		
             //get the toolbox name
             $toolboxname = $this->getToolboxName($resourcegroup_id);
             
             //get the group name
             $groupname = $this->getTheGroupName($group_id);
            
             $cmd =Yii::app()->db->createCommand();  
             $result = $cmd->update('group_has_resourcegroup',
                	array(
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'update_time'=>new CDbExpression('NOW()')
					
					
			),
			"group_id = $group_id and  resourcegroup_id = $resourcegroup_id"
		);
             if($result > 0 ){
                  $msg="'$toolboxname' service in '$groupname' group is successfully updated";
                  header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
                 
             }else{
                   $msg="Update not effected in '$toolboxname' service in '$groupname' group";
                  header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=>$msg
                       ));
                
             }
            
               
	}
        
        
        /**
	 * assign a resourcegroup to a subgroup for single assignment process
	 */
	public function actionAssignSingleResourcegroupToSubgroup()
	{
		
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             $subgroup_id = $_REQUEST['subgroup_id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
			 
              //get the toolbox name
             $toolboxname = $this->getToolboxName($resourcegroup_id);
             
             //get the group name
             $subgroupname = $this->getTheSubgroupName($subgroup_id);
            
             $cmd =Yii::app()->db->createCommand();  
             $result = $cmd->update('subgroup_has_resourcegroup',
                	array(
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'update_time'=>new CDbExpression('NOW()')
					
					
			),
			"subgroup_id = $subgroup_id and  resourcegroup_id = $resourcegroup_id"
		);
             if($result > 0){
                 $msg ="'$toolboxname' service in '$subgroupname' group is successfully updated";                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
             }else{
                 $msg ="Update not effected in '$toolboxname' service in '$subgroupname' subgroup";                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=>$msg
                       ));
             }
              
               
               
	}
        
        
        /**
	 * assign a resourcegroup to a subgroup for single assignment process
	 */
	public function actionAssignSingleResourcegroupToUser()
	{
		
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             $user_id = $_REQUEST['user_id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
		
              //get the toolbox name
             $toolboxname = $this->getToolboxName($resourcegroup_id);
             
             //get the group name
             $username = $this->getTheUsername($user_id);
			 
            
             $cmd =Yii::app()->db->createCommand();  
            $result =  $cmd->update('user_has_resourcegroup',
                	array(
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'update_time'=>new CDbExpression('NOW()')
					
					
			),
			"user_id = $user_id and  resourcegroup_id = $resourcegroup_id"
		);
             if($result > 0){
                 $msg = "'$toolboxname' service for '$username' is successfully updated";
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
             }else{
                 
                 $msg ="Update not effected on '$toolboxname' service for '$username'";
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=>$msg
                       ));
             }
              
               
	}
        
        
         /**
	 * assign a resourcegroup to a category for single assignment process
	 */
	public function actionAssignSingleResourcegroupToCategory()
	{
		
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             $category_id = $_REQUEST['category_id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
			 
			 
            
             $cmd =Yii::app()->db->createCommand();  
             $cmd->update('resourcegroup_has_resourcegroupcategory',
                	array('resourcegroup_id'=>$resourcegroup_id,
				'category_id'=>$category_id,
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description
					
					
			),
			"category_id = $category_id and  resourcegroup_id = $resourcegroup_id"
		);
             
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                       ));
               
               
	}
        
        
        /**
	 * assign a resourcegroup to a category for single assignment process
	 */
	public function actionAssignSingleResourceToResourcegroup()
	{
		
             $resourcegroup_id = $_REQUEST['resourcegroup_id'];
             $resource_id = $_REQUEST['resource_id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
			 
		
              //get the toolbox name
             $toolboxname = $this->getToolboxName($resourcegroup_id);
             
             //get the group name
             $toolname = $this->getTheToolName($resource_id);
			 
            
             $cmd =Yii::app()->db->createCommand();  
             $result = $cmd->update('resource_has_resourcegroups',
                	array('resourcegroup_id'=>$resourcegroup_id,
				'resource_id'=>$resource_id,
                                'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'update_time'=>new CDbExpression('NOW()')
					
					
			),
			"resource_id = $resource_id and  resourcegroup_id = $resourcegroup_id"
		);
             if($result > 0){
                  $msg = "'$toolname' session in '$toolboxname' is successfully updated ";
                  header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
             }else{
                 
                  $msg = "'$toolname' file in '$toolboxname' could not be updated ";
                  header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=>$msg
                       ));
             }
            
               
               
	}
        
        
        
         /**
	 * assign a a single new resourcegroup to a group for single assignment process
	 */
	public function actionAssignNewSingleResourcegroupToGroup()
	{
		
             $resourcegroup_id = $_REQUEST['resourcegroup'];
            // $group_name = $_REQUEST['group'];
             $group_id = $_REQUEST['id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
             //get the logged in user
             $user_id = Yii::app()->user->id;
             
             //get the domain of the group
             $domain_id = $this->getTheDomainOfThisGroup($group_id);
             
	//get the minimum subscription period for this toolbox in this domain
          $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($resourcegroup_id,$domain_id);
           //get the maximum subscription period for this toolbox in this domain
           $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($resourcegroup_id,$domain_id);
            //confirm that this toolbox service is not already assiged to this group
         
           //get the toolbox name
           
           $toolboxname = $this->getToolboxName($resourcegroup_id);
           
           //get the group name
           
           $groupname = $this->getTheGroupName($group_id);
          if($this->isToolboxNotAlreadyAssignedToThisGroup($group_id,$resourcegroup_id)){ 
              
              $cmd =Yii::app()->db->createCommand();  
             $cmd->insert('group_has_resourcegroup',
                	array('resourcegroup_id'=>$resourcegroup_id,
				'group_id'=>$group_id,
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'date_assigned'=>new CDbExpression('NOW()'),
                                'assigned_by'=>Yii::app()->user->id,
                                'min_date'=>$min_date,
                                'max_date'=>$max_date,
                                'start_date'=>$min_date,
                                'end_date'=>$max_date
					
					
			)
		);
             $msg = "'$toolboxname' service is successfully added to the '$groupname' group";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=> $msg
                           
                       ));
              
              
          }else{
             $msg = "'$toolboxname' service is already available in '$groupname' group";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=> $msg
                           
                       )); 
              
          }  
             
               
               
	}
        
        
        /**
	 * assign a a single new resourcegroup to a group for single assignment process
	 */
	public function actionAssignNewSingleResourcegroupToSubgroup()
	{
		
             $resourcegroup_id = $_REQUEST['resourcegroup'];
             //$subgroup_name = $_REQUEST['subgroup'];
             $subgroup_id = $_REQUEST['id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
	 //get the domain of the group
             $domain_id = $this->getTheDomainOfThisSubgroup($subgroup_id);
             
	//get the minimum subscription period for this toolbox in this domain
          $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($resourcegroup_id,$domain_id);
           //get the maximum subscription period for this toolbox in this domain
           $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($resourcegroup_id,$domain_id);
            //confirm that this toolbox service is not already assiged to this group
         
           //get the toolbox name
           
           $toolboxname = $this->getToolboxName($resourcegroup_id);
           
           //get the group name
           
           $subgroupname = $this->getTheSubgroupName($subgroup_id);
            if($this->isToolboxNotAlreadyAssignedToThisSubgroup($subgroup_id,$resourcegroup_id)){ 
                $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('subgroup_has_resourcegroup',
                	array('resourcegroup_id'=>$resourcegroup_id,
				'subgroup_id'=>$subgroup_id,
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'date_assigned'=>new CDbExpression('NOW()'),
                                'assigned_by'=>Yii::app()->user->id,
                                'min_date'=>$min_date,
                                'max_date'=>$max_date,
                                'start_date'=>$min_date,
                                'end_date'=>$max_date
					
					
			)
					);
             $msg = "'$toolboxname' service is successfully added to the '$subgroupname' subgroup ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
                
                 $msg = "'$toolboxname' service is already available in '$subgroupname' subgroup";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=> $msg
                           
                       )); 
            }
            
             
               
               
	}
        
        
        
        /**
	 * assign a a single new resourcegroup to a group for single assignment process
	 */
	public function actionAssignNewSingleResourcegroupToUser()
	{
		
             $resourcegroup_id = $_REQUEST['resourcegroup'];
             $user_id = $_REQUEST['id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
	//get the domain of the group
             $domain_id = $this->determineAUserDomainIdGiven($user_id);
             
	//get the minimum subscription period for this toolbox in this domain
          $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($resourcegroup_id,$domain_id);
           //get the maximum subscription period for this toolbox in this domain
           $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($resourcegroup_id,$domain_id);
            //confirm that this toolbox service is not already assiged to this group
         
           //get the toolbox name
           
           $toolboxname = $this->getToolboxName($resourcegroup_id);
           
           //get the group name
           
           $username = $this->getTheUsername($user_id);
            
            if($this->isToolboxNotAlreadyAssignedToThisUser($user_id,$resourcegroup_id)){ 
                
                $cmd =Yii::app()->db->createCommand();  
             $cmd->insert('user_has_resourcegroup',
                	array('resourcegroup_id'=>$resourcegroup_id,
				'user_id'=>$user_id,
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'date_assigned'=>new CDbExpression('NOW()'),
                                'assigned_by'=>Yii::app()->user->id,
                                'min_date'=>$min_date,
                                'max_date'=>$max_date,
                                'start_date'=>$min_date,
                                'end_date'=>$max_date
					
					
			)
			
		);
             $msg = "'$toolboxname' service is successfully added to '$username' ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
                
            }else{
                 $msg = "'$toolboxname' service is already available for '$username'";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=> $msg
                           
                       )); 
                
            }
             
               
	}
        
        
        
        
        
         /**
	 * assign a a single new resourcegroup to a group for single assignment process
	 */
	public function actionAssignNewSingleResourceToResourcegroup()
	{
		
             $resource_id = $_REQUEST['resource'];
             $resourcegroup_id = $_REQUEST['id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
	//get the domain of the group
             $domain_id = $this->getTheResourceOrToolDomain($resource_id);
             
	//get the minimum subscription period for this toolbox in this domain
          $min_date = $this->getTheMinSubscriptionDayForThisToolboxInThisDomain($resourcegroup_id,$domain_id);
           //get the maximum subscription period for this toolbox in this domain
           $max_date = $this->getTheMaxSubscriptionDayForThisToolboxInThisDomain($resourcegroup_id,$domain_id);
            //confirm that this toolbox service is not already assiged to this group
         
           //get the toolbox name
           
           $toolboxname = $this->getToolboxName($resourcegroup_id);
           
           //get the group name
           
           $toolname = $this->getTheToolName($resource_id);
            if($this->isToolNotAlreadyAssignedToThisResourcegroup($resource_id,$resourcegroup_id)){ 
                
                 $cmd =Yii::app()->db->createCommand();  
                 $cmd->insert('resource_has_resourcegroups',
                	array('resourcegroup_id'=>$resourcegroup_id,
				'resource_id'=>$resource_id,
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'date_assigned'=>new CDbExpression('NOW()'),
                                'assigned_by'=>Yii::app()->user->id
					
					
			)
			
		);
             $msg = "'$toolname' is successfully added to the '$toolboxname' folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
                
            }else{
              $msg = "'$toolname' is already in the '$toolboxname' folder and could not be added again ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=>$msg
                       ));
               
            }
            
               
	}
         
        
        /**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneAssignedResourcegroup()
	{
            //delete a resource group
            $group_id = $_POST['group_id'];
            $resourcegroup_id = $_POST['resourcegroup_id'];
           
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('group_has_resourcegroup', 'group_id=:id and resourcegroup_id=:groupid', array(':id'=>$group_id, ':groupid'=>$resourcegroup_id ));
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>'The folder had successfully been removed from the Group',
                       ));
	}
        
        
         /**
	 * Deletes a particular assigned subgroup.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneAssignedSubgroupToResourcegroup()
	{
            //delete a resourcegroup from subgroup
            $subgroup_id = $_POST['subgroup_id'];
            $resourcegroup_id = $_POST['resourcegroup_id'];
           
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('subgroup_has_resourcegroup', 'subgroup_id=:id and resourcegroup_id=:groupid', array(':id'=>$subgroup_id, ':groupid'=>$resourcegroup_id ));
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>'The folder had successfully been removed from the Subgroup',
                       ));
	}
        
        
        /**
	 * Deletes a particular assigned user.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneAssignedResourcegroupToUser()
	{
            //delete a resourcegroup from subgroup
            $user_id = $_POST['user_id'];
            $resourcegroup_id = $_POST['resourcegroup_id'];
           
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('user_has_resourcegroup', 'user_id=:id and resourcegroup_id=:groupid', array(':id'=>$user_id, ':groupid'=>$resourcegroup_id ));
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>'The folder had successfully been removed from the User',
                       ));
	}
        
        /**
	 * Deletes a particular assigned resourcegroup in a category.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneAssignedResourcegroupToCategory()
	{
            //delete a resourcegroup from subgroup
            $category_id = $_POST['category_id'];
            $resourcegroup_id = $_POST['resourcegroup_id'];
           
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('resourcegroup_has_resourcegroupcategory', 'category_id=:id and resourcegroup_id=:groupid', array(':id'=>$category_id, ':groupid'=>$resourcegroup_id ));
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>'The folder had successfully been removed from the Category',
                       ));
	}
        
        
        
         /**
	 * Deletes a particular assigned resource in a resourcegroup.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneAssignedResourceToResourcegroup()
	{
            //delete a resourcegroup from subgroup
            $resource_id = $_POST['resource_id'];
            $resourcegroup_id = $_POST['group_id'];
           
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('resource_has_resourcegroups', 'resource_id=:id and resourcegroup_id=:groupid', array(':id'=>$resource_id, ':groupid'=>$resourcegroup_id ));
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>'The file had successfully been removed from the folder',
                       ));
	}
        
        
        /**
	 * Provide icon when unavailable
	 */
	public function provideResourcegroupIconWhenUnavailable($model)
	{
		return 'toolbox_unavailable.png';
	}
         
        
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
                
                
                
                
                
           
           
            
           
        }
        
        
        /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        
       
        
        /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
        /**
         * This is the function that retrieves domain toolboxes base on visibility for charting on the client side
         */
        public function actionpartnertoolboxesbyvisibility(){
            
            //$domain_id = $_REQUEST['id'];
            $domain_id = 1;
            
            //retrieve all the toolboxes consumed by this domain
            $toolboxes = $this->retrieveAllToolboxesConsumedByDomain($domain_id);
            
            $visibility = [];
            foreach($toolboxes as $toolbox){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, visibility';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox);
                $domaintoolboxes= Resourcegroup::model()->findAll($criteria);
                
                $visibility = array_merge($visibility,$domaintoolboxes);
                
                }
            
                if($visibility===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "toolbox" => $visibility,
                           //"toolbox"=>$toolboxes
                            
                       ));
                       
                } 
                 
                
                 
            
            
            
        }
        
        /**
         * This is the function that retrieves toolboxes assigned to a domain
         */
        public function retrieveAllToolboxesConsumedByDomain($domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='category_id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $toolboxes= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
            
            $alltoolboxes = [];
            foreach($toolboxes as $toolbox){
                $alltoolboxes[] = $toolbox['resourcegroup_id'];
            }
            
            return $alltoolboxes;
             
        }
        
        /**
         * This is the function that retrieves reserved toolboxes  for network assignment or update
         */
        public function actionListAllReservedToolboxesForNetworksInDomain(){
            
            //the logged in user
            $userid = Yii::app()->user->id;
            
            //the logged in domain
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
             $network_id = $_REQUEST['id'];
            
            //$network_id = 3;
            
            //select all the reserved toolboxes for this domain  
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid and visibility=:visibility';
             $criteria->params = array(':domainid'=>$domainid,':visibility'=>"reserved");
             $result = ResourceGroup::model()->findAll($criteria);   
           
             
             //retreive all toolboxes already assigned to this network
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='network_id=:id';
             $criteria2->params = array(':id'=>$network_id);
             $selected = NetworkHasToolboxes::model()->findAll($criteria2);
            
             //retrieve all the networks details           
             $criteria3 = new CDbCriteria();
             $criteria3->select = '*';
             $criteria3->condition='id=:id';
             $criteria3->params = array(':id'=>$network_id);
             $network = Network::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "toolbox" => $result,
                            "network" => $network  
                       ));
                       
                }
            
        }

        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
        
        /**
         * This is the function that list all reserved toolboxes belonging to a domain
         */
        public function actionListAllReservedToolboxesInThisDomain(){
            
            $userid = Yii::app()->user->id;
            $domain_id = $this->determineAUserDomainIdGiven($userid);
          
            //select all the reserved toolboxes for this domain  
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid and visibility=:visibility';
             $criteria->params = array(':domainid'=>$domain_id,':visibility'=>"reserved");
             $result = ResourceGroup::model()->findAll($criteria);   
           
                        
             if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                          "toolbox" => $result,
                          
                       ));
                       
                }
            
            
        }
        
       
        
        /**
         * This is the function that retrieves the detail a toolbox
         */
        public function actiontoolboxdetailinfo(){
            
            $toolbox_id = $_REQUEST['toolbox_id'];
            
            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            //$domainid = $this->determineAUserDomainIdGiven($userid);
            
            //get the domain of this toolbox
            $domainid = $this->getThisToolboxDomainId($toolbox_id);
            
            
                          
                //get the toolbox owner
                $owner = $this->getTheToolboxOwnerName($toolbox_id);
                //get the owner country
                $owner_country = $this->getTheToolboxOwnerCountry($toolbox_id);
                //get the total tools in this toolboxes
                $toolbox_tools = $this->totalToolsInToolbox($toolbox_id);
                //get the total task in this toolbox
                $toolbox_tasks = $this->totalTasksInThisTask($toolbox_id);
                
                //get the total number of domains consumimg this toolbox
                $consumer_domains = $this->totalDomainsConsumingToolbox($toolbox_id);
               
                
                //retreive all the information about the domain
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$toolbox_id);
               $toolboxes= Resourcegroup::model()->findAll($criteria);
            
                if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "toolbox" => $toolboxes,
                            "owner" => $owner,
                            "toolbox_tools" => $toolbox_tools,
                            "toolbox_tasks" => $toolbox_tasks,
                            "country" => $owner_country,
                            "consumer_domains" => $consumer_domains
               
                       ));
                       
                } 
            
        }
        
        
        /**
         * This is the function that gets the domain id of a toolbox
         */
        public function getThisToolboxDomainId($id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $domain= Resourcegroup::model()->find($criteria);
               
               return $domain['domain_id'];
            
        }
        
        
        /**
         * This is the function that gets the toolbox owner name
         */
        public function getTheToolboxOwnerName($toolbox_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$toolbox_id);
               $domain= Resourcegroup::model()->find($criteria);
               
               //get the domain name
               $domain_name = $this->determineDomainNameGivenItId($domain['domain_id']);
               
               return $domain_name;
               
            
            
        }
        
        /**
         * This is the function that returns the domain id of a toolbox owner given the toolbox id
         */
        public function getDomainIdOfThisToolbox($toolbox_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$toolbox_id);
               $domain= Resourcegroup::model()->find($criteria);
               
               return $domain['domain_id'];
            
        }
        
        /**
         * This is the function that get the operating country name of a domain 
         */
        public function getTheDomainCountryName($domain_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$domain_id);
               $country= ResourceGroupCategory::model()->find($criteria);
               
               return $this->getTheCountryNameGivenItsId($country['country_id']);
            
        }
        
        
         /**
         * This is the function that gets a country name given its id
         */
        public function getTheCountryNameGivenItsId($id){
            
            $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $country= Country::model()->find($criteria); 
               
               return $country['name'];
            
            
        }
        /**
         * Get the toolbox owner country
         */
        public function getTheToolboxOwnerCountry($toolbox_id){
            $domain_id = $this->getDomainIdOfThisToolbox($toolbox_id);
            
            $country = $this->getTheDomainCountryName($domain_id);
            
            return $country;
            
        }
        
        /**
         * This is the function that obtains the total tool in a toolbox
         */
        public function totalToolsInToolbox($toolbox_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resource_has_resourcegroups')
                    ->where("resourcegroup_id = $toolbox_id");
                $result = $cmd->queryScalar();
                
                return $result;
     
        }
        
        /**
         * This is the function that obtains the total tasks in a toolbox
         */
        public function totalTasksInThisTask($toolbox_id){
            
            //retrieve all tools in this toolbox
            $tools = $this->retrieveAllToolsInThisToolbox($toolbox_id);
            $total_tasks = 0;
            
            foreach($tools as $tool){
                
               $total_tasks = $total_tasks + $this->numberOfTaskInThisTool($tool); 
                
            }
            return $total_tasks;
            
            
        }
        
        
        /**
         * This is the function retrieves all tools in a toolbox
         */
        public function retrieveAllToolsInThisToolbox($toolbox_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='resourcegroup_id=:id';
               $criteria->params = array(':id'=>$toolbox_id);
               $tools= ResourceHasResourcegroups::model()->findAll($criteria);
               
               $alltools = [];
               foreach($tools as $tool){
                   $alltools[] = $tool['resource_id'];
               }
            
               return $alltools;
        }
        
        /**
         * This is the function that gets the number of tasks in a tool
         */
        public function numberOfTaskInThisTool($tool){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("parent_id = $tool");
                $result = $cmd->queryScalar();
                
                return $result;
        }
        
        /**
         * This is the function that ascertains the number of domains consuming a toolbox
         */
        public function totalDomainsConsumingToolbox($toolbox_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup_has_resourcegroupcategory')
                    ->where("resourcegroup_id = $toolbox_id");
                $result = $cmd->queryScalar();
                
                return $result;
     
        }
        
        /**
         * This is the function that list all tools in a toolbox
         */
        public function actionListAllToolsInThisToolbox(){
            
            //retrieve all tools in a toolbox
            
           $toolbox_id = $_REQUEST['id'];
             //$domain_id = 2;
            $tools = $this->retrieveAllToolsInThisToolbox($toolbox_id);
            $alltools = [];
            foreach($tools as $tool){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$tool);
               $assigned_tools= Resources::model()->find($criteria);
               $alltools[] = $assigned_tools;
                
            }
            
            if($alltools===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "tool" => $alltools
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        /**
         * This is the function that retrieves all tools in a toolbox
         
        public function retrieveAllToolsInThisToolbox($toolbox_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='resourcegroup_id=:id';
               $criteria->params = array(':id'=>$toolbox_id);
               $tools= ResourceHasResourcegroups::model()->find($criteria);
               
              $alltools = [];
               foreach($tools as $tool){
                   $alltools[] =$tool['resource_id'];
               }
            return $alltools;
            
            
            
        }
         * 
         */
        
        
         /**
         * This is the function that list all tasks in a toolbox
         */
        public function actionListAllTasksInThisToolbox(){
            
            //retrieve all tasks in a toolbox
            
           $toolbox_id = $_REQUEST['id'];
             //$domain_id = 2;
            $tools = $this->retrieveAllToolsInThisToolbox($toolbox_id);
            $alltasks = [];
            
            foreach($tools as $tool){
                //retrieve all task for this tool
                $tasks = $this->retrieveAllTasksForThisTool($tool);
                foreach($tasks as $task){
                    if(in_array($task, $alltasks)){
                        continue;
                    }else{
                          $alltasks[] = $task;  
                    }
                }
            }
            //get the detail information about the task
            $all_tasks = [];
            foreach($alltasks as $alltask){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$alltask);
               $tool_tasks= Resources::model()->find($criteria);
               $all_tasks[] = $tool_tasks;
                
            }
            
            if($all_tasks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "task" => $all_tasks
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        /**
         * This is the function that list all task in a toolbox
         */
        public function retrieveAllTasksForThisTool($tool){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='parent_id=:id';
               $criteria->params = array(':id'=>$tool);
               $tasks= Resources::model()->findAll($criteria);
               
               $alltasks = [];
               foreach($tasks as $task){
                   
                   $alltasks[] = $task['id'];
               }
            
               return $alltasks;
        }
        
        
        /**
         * This is the function that retrieves all tasks/documents in a tool/batch/folder based on the processed user
         */
        public function retrieveAllTasksForThisToolByThisUser($tool,$processing_user){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='parent_id=:id and (create_user_id =:createid or update_user_id = "updateid)';
               $criteria->params = array(':id'=>$tool,':createid'=>$processing_user,':updateid'=>$processing_user);
               $tasks= Resources::model()->findAll($criteria);
               
               $alltasks = [];
               foreach($tasks as $task){
                   
                   $alltasks[] = $task['id'];
               }
            
               return $alltasks;
        }
        
        
        /**
         * This is the function retrieves all tasks/documents in a tool/batch within a date range
         */
        public function retrieveAllTasksForThisToolByThisDateRange($tool,$search_start_date,$search_end_date,$preferred_date){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='parent_id=:id';
               $criteria->params = array(':id'=>$tool);
               $tasks= Resources::model()->findAll($criteria);
             
               
               $alltasks = [];
               foreach($tasks as $task){
                   if($preferred_date == 'captured_date'){
                       if($this->isThisTaskOrDocumentProcessedWithinTheDateRange($search_start_date,$search_end_date,$task['create_time'])){
                           $alltasks[] = $task['id'];
                       }
                               
                   }else if($preferred_date == 'processed_date'){
                        if($this->isThisTaskOrDocumentProcessedWithinTheDateRange($search_start_date,$search_end_date,$task['document_processed_date'])){
                           $alltasks[] = $task['id'];
                        }
                   }else if($preferred_date == 'expiry_date'){
                       if($this->isThisTaskOrDocumentProcessedWithinTheDateRange($search_start_date,$search_end_date,$task['document_expiry_date'])){
                           $alltasks[] = $task['id'];
                        }
                   }
                   
               }
            
               return $alltasks;
            
        }
        
      
        
        /**
         * This is the function that spools all the task/documents in a tool/batch based on date range and user processor 
         */
        public function retrieveAllTasksForThisToolByThisDateRangeAndUser($tool,$search_start_date,$search_end_date,$preferred_date,$processing_user){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='parent_id=:id and create_user_id=:userid';
            $criteria->params = array(':id'=>$tool, ':userid'=>$processing_user);
            $tasks= Resources::model()->findAll($criteria);
             
               
               $alltasks = [];
               foreach($tasks as $task){
                   if($preferred_date == 'captured_date'){
                       if($this->isThisTaskOrDocumentProcessedWithinTheDateRange($search_start_date,$search_end_date,$task['create_time'])){
                           $alltasks[] = $task['id'];
                       }
                               
                   }else if($preferred_date == 'processed_date'){
                        if($this->isThisTaskOrDocumentProcessedWithinTheDateRange($search_start_date,$search_end_date,$task['document_processed_date'])){
                           $alltasks[] = $task['id'];
                        }
                   }else if($preferred_date == 'expiry_date'){
                       if($this->isThisTaskOrDocumentProcessedWithinTheDateRange($search_start_date,$search_end_date,$task['document_expiry_date'])){
                           $alltasks[] = $task['id'];
                        }
                   }
                   
               }
            
               return $alltasks;
            
        }
        
        
        
        /**
         * This is the function that determines if a document captured is within the required date range
         */
        public function isThisTaskOrDocumentProcessedWithinTheDateRange($search_start_date,$search_end_date,$captured_date){
            
            $start_date = getdate(strtotime($search_start_date));
            $end_date = getdate(strtotime($search_end_date));
            $captured_date = getdate(strtotime($captured_date));
            
            if($this->isStartDateLowerThanOrEqualToEndDate($start_date,$end_date)){
               if($this->isCapturedDateLowerThanStartDate($captured_date,$start_date)){
                    return false;
                }else if($this->isCapturedDateHigherThanEndDate($captured_date,$end_date)){
                    return false;
               }else{
                   
                   return true;
               }
           }else{
               return false;
           }
            
            
           
            
            
        }
        
        
        /**
         * This is the function that determines if start time is lower than the end time
         */
        public function isStartDateLowerThanOrEqualToEndDate($start_date,$end_date){
          
           if(!empty($end_date)){
                if($start_date['year']>$end_date['year']){
                return false;
            }else if($start_date['year']<$end_date['year']){
                return true;
            }else if($start_date['year'] == $end_date['year']){
                if($start_date['mon']>$end_date['mon']){
                    return false;
                }else if($start_date['mon']<$end_date['mon']){
                    return true;
                }else if($start_date['mon'] == $end_date['mon']){
                    if($start_date['mday']>$end_date['mday']){
                        return false;
                    }else if($start_date['mday']<$end_date['mday']){
                        return true;
                    }else if($start_date['mday']==$end_date['mday']){
                        return true;
                    }
                }
           }
          
        }else{
               if(empty($start_date)){
                   return false;
               }else{
                   return true;
               }
           } 
     
        }
        
        
        /**
         * This is the function that confirms if the captured date is lower than the start dte
         */
        public function isCapturedDateLowerThanStartDate($captured_date,$start_date){
            
            if($captured_date['year'] < $start_date['year']){
                return true;
            }else if($captured_date['year'] > $start_date['year']){
                return false;
            }else if($captured_date['year'] == $start_date['year']){
                if($captured_date['mon']< $start_date['mon']){
                    return true;
                }if($captured_date['mon']> $start_date['mon']){
                    return false;
                }else if($captured_date['mon'] == $start_date['mon']){
                    if($captured_date['mday'] < $start_date['mday']){
                        return true;
                    }else if($captured_date['mday'] > $start_date['mday']){
                        return false;
                    }else if($captured_date['mday'] == $start_date['mday']){
                        return false;
                    }
                }
            }
        }
        
        
        /**
         * This is the function that determines if the captured date is higher than the end date
         */
        public function isCapturedDateHigherThanEndDate($captured_date,$end_date){
          
               if($captured_date['year']> $end_date['year']){
                return true;
            }else if($captured_date['year']< $end_date['year']){
                return false;
            }else if($captured_date['year'] == $end_date['year']){
                if($captured_date['mon']> $end_date['mon']){
                    return true;
                }else if($captured_date['mon']< $end_date['mon']){
                    return false;
                }else if($captured_date['mday']== $end_date['mday']){
                   if($captured_date['mday']> $end_date['mday']){
                        return true;
                    }else if($captured_date['mday']< $end_date['mday']){
                        return false;
                    }else if($captured_date['mday'] == $end_date['mday']){
                        return false;
                    }
                }
            }
          
            
        }
        
        /**
         * This is the function that retrieves the preferred currency for a domain
         * 
         */
        public function actiongetThePreferredCurrencyOfADomain(){
            
            //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the prefferred currency code
            
            $currency_code = $this->getThisCurrencyCode($preferred_currency);
            
            //get the platform base currency
            
            $base_currency = $this->getThePlatformBaseCurrency();
            
            
            if(isset($_REQUEST['toolbox_id'])){
                $toolbox_id = $_REQUEST['toolbox_id'];
                
                if($base_currency == $preferred_currency){
                //get the toolbox price
                $price = $this->getTheToolboxPrice($toolbox_id);
            }else{
                //retrieve the exchange rate of the preferred currency
                        $dprice = $this->getTheToolboxPrice($toolbox_id);
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $new_value = ((double)$dprice) * ((double)$exchange_rate);
                        $price = $new_value;
            }
            }else{
                $price = "";
            }
                
            
            
            
            
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "currency_code" =>$currency_code,
                           "preferred_currency"=> $preferred_currency,
                           "price"=>$price
                       ));
        }
        
        
        /**
         * This is the function that gets the preferred currency for a domain
         */
        public function getThisDomainPreferredCurrency($domain_id){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='domain_id=:id and status="active"';
                     $criteria->params = array(':id'=>$domain_id);
                     $domain= DomainPolicy::model()->find($criteria);
                     
                     return $domain['domain_currency_preference'];
            
            
        }
        
        /**
         * get the preferred currency code
         */
        public function getThisCurrencyCode($preferred_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$preferred_currency);
            $currency = Currencies::model()->find($criteria); 
            
            return $currency['currency_code'];
        }
        
        
        /**
         * This is the function that gets the platform base currency
         */
        public function getThePlatformBaseCurrency(){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                    // $criteria->condition='country_id=:id';
                   //  $criteria->params = array(':id'=>$country_id);
                     $platform= PlatformSettings::model()->find($criteria);
                     
                     return $platform['platform_default_currency_id'];
            
        }
        
        /**
         * This is the function that gets the exchange rate of a currency
         */
        public function getThePreferredCurrencyExchangeRate($currency,$base_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='base_currency_id=:baseid and currency_id=:currencyid';
            $criteria->params = array(':baseid'=>$base_currency,':currencyid'=>$currency);
            $currency= CurrencyExchange::model()->find($criteria);
            
            return $currency['exchange_rate'];
        }
       
        /**
         * This is the function that gets the stored the toolbox price
         */
        public function getTheToolboxPrice($toolbox_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolbox_id);
            $toolbox = Resourcegroup::model()->find($criteria); 
            
            return $toolbox['price'];
            
            
        }
        
        /**
         * This is the function that retrieves the mininum subscription date
         */
        public function getTheMinimumSubscriptionDateOfThisToolboxServiceToThisDomain($toolbox_id,$domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='category_id=:id and resourcegroup_id=:toolboxid';
            $criteria->params = array(':id'=>$domain_id,':toolboxid'=>$toolbox_id);
            $subscription = ResourcegroupHasResourcegroupcategory::model()->find($criteria); 
            
            return $subscription['min_date'];
            
        }
        
        
        
         /**
         * This is the function that retrieves the maximum subscription date
         */
        public function getTheMaximumSubscriptionDateOfThisToolboxServiceToThisDomain($toolbox_id,$domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='category_id=:id and resourcegroup_id=:toolboxid';
            $criteria->params = array(':id'=>$domain_id,':toolboxid'=>$toolbox_id);
            $subscription = ResourcegroupHasResourcegroupcategory::model()->find($criteria); 
            
            return $subscription['max_date'];
            
        }
        
        
        /**
             * This is the function that extends the time to live of a service to a domain
             */
            public function ExtendThisServiceToThisDomain($toolbox_id,$domain_id,$subscribers,$number_of_years,$assign_name,$description,$store_id,$commencement_date){
                
              //get the number of years of subscription
              //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                //confirm if service exist for a domain
                if($this->isThisServiceToDomainAvailable($toolbox_id,$domain_id)){
                    //confirm if end of date is declared for this service to this domain
                    if($this->isEndOfDateDeclaredForThisServiceToThisDomain($toolbox_id,$domain_id)){
                        //get the end_date for the service to this domain
                        $end_date = getdate(strtotime($this->getTheEndDateOfThisServiceToThisToDomain($toolbox_id,$domain_id)));
                        $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                        if($end_date['year'] -$today['year']<=0 ){
                            if($end_date['mon']- $today['mon']<=0 ){
                                if(($end_date['mday']- $today['mday']<=0 )){
                                    $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d")+$day_diff, date("Y")+$number_of_years));
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon']-1;
                                if($end_date['mon']- $today['mon']<=0){
                                   $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d"), date("Y")+$number_of_years));  
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d")+$day_diff, date("Y")+$number_of_years));
                                }
                            }
                        }else{
                            $year_diff = $end_date['year'] -$today['year'];
                            if($end_date['mon']- $today['mon']<=0){
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years+$year_diff));
                                }else{
                                   $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d")+$day_diff, date("Y")+$number_of_years+$year_diff)); 
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon']-1;
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d"), date("Y")+$number_of_years+$year_diff));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d")+$day_diff, date("Y")+$number_of_years+$year_diff)); 
                                }
                            }
                        }
                       // extend the value of the service by then= new date value
                        $new_expiry_date = date("Y-m-d", $new_end_date);
                        
                        //get the existing subscription period
                        $number_of_years = $number_of_years + $this->getTheExistingSubscriptionPeriodForThisToolboxInThisDomain($toolbox_id,$domain_id);
                        if($this->extendThisServiceToDomain($toolbox_id,$domain_id,$new_expiry_date,$subscribers,$number_of_years,$assign_name,$description,$store_id,$commencement_date)){
                            return true;
                        }else{
                            return false;
                        }
                        
                    }
                }
                
                
                
            }
            
            
            /**
             * This is the function that assigns toolbox service to a domain
             */
            public function assignToolboxToDomain($toolbox_id,$domain_id,$subscribers,$store_id,$toolbox_status,$number_of_years,$min_date,$max_date,$assign_name,$description){
                //get the number of years for this subscription
                //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                $user_id = Yii::app()->user->id;
                                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('resourcegroup_has_resourcegroupcategory',
                                  array(
                                           'category_id'=>$domain_id,
                                           'assign_name'=>$assign_name,
                                           'assign_description'=>$description,
                                           'resourcegroup_id'=>$toolbox_id,
                                            'min_date'=>$min_date,
                                            'max_date'=>$max_date,
                                            'number_of_years'=>$number_of_years,
                                            'no_of_subscribers'=>$subscribers,
                                            'store_id'=>$store_id,
                                            'toolbox_status'=>$toolbox_status,
                                            'assigned_by'=>$user_id,
                                            'date_assigned'=>new CDbExpression('NOW()')
                               
		
                            )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
             /**
             * This is the function that is used to get the end date of a toolbox service to a domain
             */
            public function getTheEndDateOfThisServiceToThisToDomain($toolbox_id,$domain_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $date['max_date'];
                 
            }
            
            /**
             * This is the function that writes the new extended expiry date value to server
             */
            public function extendThisServiceToDomain($toolbox_id,$domain_id,$new_expiry_date,$subscribers,$number_of_years,$assign_name,$description,$store_id,$commencement_date ){
                
                $today = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                //get the number of years of subscription
                //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('resourcegroup_has_resourcegroupcategory',
                                  array(
                                   'min_date'=>$commencement_date,
                                   'max_date'=>$new_expiry_date, 
                                   'no_of_subscribers'=>$subscribers,
                                   'number_of_years'=>$number_of_years,
                                   'assign_name'=>$assign_name,
                                   'assign_description'=>$description,
                                   'store_id'=>$store_id,
                                   //'toolbox_status'=>"inactive",
                                   'assigned_by'=>Yii::app()->user->id,
                                   'date_assigned'=>new CDbExpression('NOW()')   
                           ),
                        ("resourcegroup_id=$toolbox_id and category_id=$domain_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            
             /**
             * This is the function that determines if end of date is declared for a service to a domains
             */
            public function isEndOfDateDeclaredForThisServiceToThisDomain($toolbox_id,$domain_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
            
                if(strtotime($date['max_date'])>0 || $date['max_date']!== NULL){
                   return true;
                 }else{
                     return false;
                 
                } 
                
            }
            
            /**
             * This is the function that determines if this service is actually available to this domain
             */
            public function isThisServiceToDomainAvailable($toolbox_id,$domain_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup_has_resourcegroupcategory')
                    ->where("resourcegroup_id = $toolbox_id and category_id=$domain_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            /**
             * This is the function that gets the existing subscription period for this toolbox service for this domain
             */
            public function getTheExistingSubscriptionPeriodForThisToolboxInThisDomain($toolbox_id,$domain_id){
                
                $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $period= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $period['number_of_years'];
                
            }
        
            
            /**
             * This is the function that list all private toolboxes assigned to a domain
             */
            public function actionretrievePrivateToolboxesAssignedToThisDomain(){
                
                //get the logged in user
                $user_id = Yii::app()->user->id;
                
                //get the category_id
                $domain_id = $_REQUEST['id'];
                
                //get the domain of the logged in user
                //$domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                //list all toolboxes ordered by a domain
                $toolboxes = $this->getAllOpenOrderedDomainToolboxes($domain_id);
                
                //retrieve all toolboxes that are private or restricted private
                $assigned_private_toolboxes = [];
                foreach($toolboxes as $toolbox){
                    if($this->isThisToolboxPrivateOrRestrictedPublic($toolbox)){
                        
                         $criteria = new CDbCriteria();
                         $criteria->select = '*';
                         $criteria->condition='toolbox_id=:toolboxid';
                         $criteria->params = array(':toolboxid'=>$toolbox);
                         $domaintoolbox= OrderHasToolboxes::model()->find($criteria);
                        if($this->isThisOrderOpen($domaintoolbox['order_id'],$domain_id)){
                             $assigned_private_toolboxes[] = $domaintoolbox;
                        } 
                       
                    }
                    
                }
                
                if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "order" => $assigned_private_toolboxes
                          
                           
                           
                          
                       ));
                       
                }
                
                
            }
            
            /**
             * This is the function that determines if an order is open
             */
            public function isThisOrderOpen($order_id,$domain_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order')
                    ->where("(id = $order_id and order_domain_id = $domain_id) and status='open'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
                
            }
            
            /**
             * This is the function that gets all ordered toolbox services by a domain
             */
            public function getAllOpenOrderedDomainToolboxes($domain_id){
                
                //get the domain open order id
                $order_id = $this->getDomainOpenOrder($domain_id);
                
                //get all the orders of this order
                $all_toolboxes = [];
                if($order_id !== NULL || $order_id != 0){
                    
                         $criteria = new CDbCriteria();
                         $criteria->select = '*';
                         $criteria->condition='order_id=:order';
                         $criteria->params = array(':order'=>$order_id);
                         $orders= OrderHasToolboxes::model()->findAll($criteria);
                         foreach($orders as $order){
                            $all_toolboxes[] = $order['toolbox_id']; 
                         }
                         return $all_toolboxes;
                    
                }else{
                    return 0;
                }
                
            }
            
            /**
             * This is the function that gets a domain's open order
             */
            public function getDomainOpenOrder($domain_id){
                
                         $criteria = new CDbCriteria();
                         $criteria->select = '*';
                         $criteria->condition='order_domain_id=:domainid and status=:status';
                         $criteria->params = array(':domainid'=>$domain_id,':status'=>'open');
                         $order= Order::model()->find($criteria);
                         
                         return $order['id'];
            }
            
            /**
             * This is the function that test or  a private or restricted private visibility status
             */
            public function isThisToolboxPrivateOrRestrictedPublic($toolbox_id){
                
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("id = $toolbox_id and (visibility = 'private' or visibility = 'private & restricted_public')");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            /**
             * This is the function that gets the minimum subscription day for a toolbox that was assigned to a domain 
             */
            public function getTheMinSubscriptionDayForThisToolboxInThisDomain($toolbox_id,$domain_id){
                
                $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $period= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $period['min_date'];
                
                
            }
            
            
            /**
             * This is the function that gets the maximum subscription day for a toolbox that was assigned to a domain 
             */
            public function getTheMaxSubscriptionDayForThisToolboxInThisDomain($toolbox_id,$domain_id){
                
                $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $period= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $period['max_date'];
                
                
            }
            
            
            /**
             * This is the function that determines if a toolbox is already assigned to a group
             */
            public function isToolboxNotAlreadyAssignedToThisGroup($group_id, $toolbox_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('group_has_resourcegroup')
                    ->where("group_id = $group_id and resourcegroup_id = $toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            
            /**
             * This is the function that determines if a toolbox is already assigned to a subgroup
             */
            public function isToolboxNotAlreadyAssignedToThisSubgroup($subgroup_id, $toolbox_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('subgroup_has_resourcegroup')
                    ->where("subgroup_id = $subgroup_id and resourcegroup_id = $toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            
            /**
             * This is the function that determines if a toolbox is already assigned to a user
             */
            public function isToolboxNotAlreadyAssignedToThisUser($user_id, $toolbox_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_has_resourcegroup')
                    ->where("user_id = $user_id and resourcegroup_id = $toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            /**
             * This is the function that extracts already assigned toolboxes to a group
             */
            public function alreadyAssignedToolboxesToThisGroup($group_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='group_id=:id';
               $criteria->params = array(':id'=>$group_id);
               $toolboxes= GroupHasResourcegroup::model()->findAll($criteria); 
               
               $alltoolboxes = [];
               foreach($toolboxes as $toolbox){
                   $alltoolboxes[] = $toolbox['resourcegroup_id'];
               }
               
               return $alltoolboxes; 
                
            }
            
            /**
             * This is the function that extracts already assigned toolboxes to a subgroup
             */
            public function alreadyAssignedToolboxesToThisSubgroup($subgroup_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='subgroup_id=:id';
               $criteria->params = array(':id'=>$subgroup_id);
               $toolboxes= SubgroupHasResourcegroup::model()->findAll($criteria); 
               
               $alltoolboxes = [];
               foreach($toolboxes as $toolbox){
                   $alltoolboxes[] = $toolbox['resourcegroup_id'];
               }
               
               return $alltoolboxes; 
                
            }
            
            
             /**
             * This is the function that extracts already assigned toolboxes to a user
             */
            public function alreadyAssignedToolboxesToThisUser($user_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='user_id=:id';
               $criteria->params = array(':id'=>$user_id);
               $toolboxes= UserHasResourcegroup::model()->findAll($criteria); 
               
               $alltoolboxes = [];
               foreach($toolboxes as $toolbox){
                   $alltoolboxes[] = $toolbox['resourcegroup_id'];
               }
               
               return $alltoolboxes; 
                
            }
            
            
            /**
             * This is the function that removes a toolbox from a group
             */
            public function removeThisToolboxFromThisGroup($toolbox_id, $group_id){
                
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('group_has_resourcegroup', 'group_id=:groupid and resourcegroup_id=:toolboxid', array(':groupid'=>$group_id, ':toolboxid'=>$toolbox_id ));
            
                return $result;
            }
            
            
            /**
             * This is the function that removes a toolbox from a subgroup
             */
            public function removeThisToolboxFromThisSubgroup($toolbox_id, $subgroup_id){
                
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('subgroup_has_resourcegroup', 'subgroup_id=:subgroupid and resourcegroup_id=:toolboxid', array(':subgroupid'=>$subgroup_id, ':toolboxid'=>$toolbox_id ));
            
                return $result;
            }
            
            
            /**
             * This is the function that removes a toolbox from a user
             */
            public function removeThisToolboxFromThisUser($toolbox_id, $user_id){
                
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('user_has_resourcegroup', 'user_id=:userid and resourcegroup_id=:toolboxid', array(':userid'=>$user_id, ':toolboxid'=>$toolbox_id ));
            
                return $result;
            }
            
           
            /**
             * This is the function that extracts all the tools in a toolbox
             */
            public function alreadyAssignedToolsToThisResourcegroup($toolbox_id){
                
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='resourcegroup_id=:id';
               $criteria->params = array(':id'=>$toolbox_id);
               $tools= ResourceHasResourcegroups::model()->findAll($criteria); 
               
               $alltools = [];
               foreach($tools as $tool){
                   $alltools[] = $tool['resource_id'];
               }
               
               return $alltools; 
            }
            
            
            /**
             * This is the function that removes a tool from a toolbox
             */
            public function removeThisToolFromThisResourcegroup($tool_id, $toolbox_id){
                
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('resource_has_resourcegroups', 'resource_id=:toolid and resourcegroup_id=:toolboxid', array(':toolid'=>$tool_id, ':toolboxid'=>$toolbox_id ));
            
                return $result;
                
            }
            
            /**
             * This is the function that test if a tool is already assigned to a toolbox
             */
            public function isToolNotAlreadyAssignedToThisResourcegroup($tool_id,$toolbox_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resource_has_resourcegroups')
                    ->where("resource_id = $tool_id and resourcegroup_id = $toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
            /**
             * This is the function that gets the domain id of a group
             */
            public function getTheDomainOfThisGroup($group_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$group_id);
                $group= Group::model()->find($criteria);
                
                return $group['domain_id'];
                
            }
            
            
            /**
             * This is the function that gets the toolbox name
             */
            public function getToolboxName($resourcegroup_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$resourcegroup_id);
                $toolbox= Resourcegroup::model()->find($criteria);
                
                return $toolbox['name'];
            }
            
            
            /**
             * This is the function that gets group name
             */
            public function getTheGroupName($group_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$group_id);
                $group= Group::model()->find($criteria);
                
                return $group['name'];
                
                
            }
            
            
            /**
             * This is the function that determines the name of a subgroup
             */
            public function getTheDomainOfThisSubgroup($subgroup_id){
                
                //get the group id of this subgroup
                $group_id = $this->getTheGroupIdOfThisSubgroup($subgroup_id);
                
                //get the domain of this group
                $domain_id = $this->getTheDomainOfThisGroup($group_id);
                
                return $domain_id;
            }
            
            /**
             * This is the function that gets the group id of a subgroup
             */
            public function getTheGroupIdOfThisSubgroup($subgroup_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$subgroup_id);
                $group= SubGroup::model()->find($criteria);
                
                return $group['group_id'];
                
            }
            
            /**
             * This is the function that gets the name of a subgroup
             */
            public function getTheSubgroupName($subgroup_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$subgroup_id);
                $group= SubGroup::model()->find($criteria);
                
                return $group['name'];
            }
            
            
            /**
             * This is the function that gea user name
             */
            public  function getTheUsername($user_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$user_id);
                $user= User::model()->find($criteria);
                
                $name = $user['firstname']." ".$user['middlename']. " ". $user['lastname'];
                
                return $name;
                
            }
            
            
            /**
             * This is the function that gets the domain for a tool
             */
            public function getTheResourceOrToolDomain($resource_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$resource_id);
                $resource= Resources::model()->find($criteria);
                
                return $resource['domain_id'];
                
            }
            
            /**
             * This is the function that gets the tool name
             */
            public function getTheToolName($resource_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$resource_id);
                $resource= Resources::model()->find($criteria);
                
                return $resource['name'];
                
            }
            
            
                 /**
         * This is the function that list all users task favourites
         */
        public function actionListAllUsersTaskFavourites(){
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //retrieve all active and on scheduled favourite task
            
            $all_tasks = $this->getAllActiveAndOnScheduledFavouriteTask($userid);
            
            $usable_tasks =[];
            
            foreach($all_tasks as $task){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='user_id=:id and resource_id=:task';
                $criteria->params = array(':id'=>$userid,':task'=>$task);
                $favourites= UserHasFavourites::model()->find($criteria);
                
                $usable_tasks[] = $favourites;
            }
            
            
            
            
             if($all_tasks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "tasks" =>$usable_tasks
                       ));
                       
                } 
            
        }
        
        
        /**
         * This is the function that gets all active and on scheduled tasks
         */
        public function getAllActiveAndOnScheduledFavouriteTask($user_id){
            
            //get the user domain
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            //retrieve all tasks in a user's favourite container
            $favourite_tasks = $this->getAllUsersFavouriteTask($user_id);
            
            $all_tasks = [];
            
            foreach($favourite_tasks as $task){
                if($this->isTaskActiveAndOnScheduledOnDomain($task,$domain_id,$user_id)){
                    $all_tasks[] = $task;
                }
            }
                    
            return $all_tasks;       
        }
        
        /**
         * This is the function that gets all favourite tasks for a user irrespective toolbox or domain status
         */
        public function getAllUsersFavouriteTask($user_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='user_id=:id';
                $criteria->params = array(':id'=>$user_id);
                $favourites= UserHasFavourites::model()->findAll($criteria);
                
                $all_tasks = [];
                foreach($favourites as $favourite){
                     $all_tasks[] = $favourite['resource_id'];
                }
            
                return $all_tasks;
        }
        
        
        /**
         * This is the function that determines if a task is active and on Scheduled in a domain
         */
        public function isTaskActiveAndOnScheduledOnDomain($task,$domain_id,$user_id){
            
            //get all the toolboxes in this users favourite container
            $toolboxes = [];
           // $toolboxes = $this->getAllTheToolboxInThisUserFavouriteContainer($user_id);
            
            //get the required task toolbox
            $toolbox_id = $this->getTheToolboxInThisUserFavouriteContainer($user_id,$task);
            
            //foreach($toolboxes as $toolbox_id){
               
                //confirm if toolbox has the task in question
             if($this->isTaskInThisToolbox($task,$toolbox_id)){
                    
                    //verify if toolbox is on schedule on both domain and on toolbox
                    if($this->isToolboxActiveAndOnScheduleOnThisDomain($domain_id,$toolbox_id)){
                        //confirm if the toolbox is active in all the subgroups a user is assigned to
                        if($this->isToolboxActiveAndOnScheduleOnUsersSubgroups($user_id,$toolbox_id)){
                            return true;
                    
                    }else{
                        //confirm if this toolbox is active and on schedule if directly assigned to the user
                        if($this->isToolboxForThisUserOnSchedule($user_id,$toolbox_id)){
                            return true;
                    }else{
                        return false;
                    }
                }
            }else{
                return false;
            }
                    
               }
                
            
            //}//end of foreach statement
            
        }
        
        
        /**
         * This is the function that determines if a task is in a toolbox
         */
        public function isTaskInThisToolbox($task_id,$toolbox_id){
            
            //get the tools in this toolbox
            $tools = [];
            $tools = $this->getAllTheToolsInThisToolbox($toolbox_id);
            $counter = 0;
            foreach( $tools as $tool){
                //confirm if tool is active and on schedule
              if($this->isThisToolOnScheduleInThisToolbox($toolbox_id, $tool)){
                 if($this->isTaskInThisTool($task_id,$tool)){
                   $counter = $counter + 1;
                }
              }  
                
            }
           if($counter > 0){
               return true;
           }else{
               return false;
           }
            
           
        }
      
        
        /**
         * This is the function that gets the toolbox of the task in the favourite container
         */
        public function getTheToolboxInThisUserFavouriteContainer($user_id,$task_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='user_id=:id and resource_id=:taskid';
                $criteria->params = array(':id'=>$user_id,':taskid'=>$task_id);
                $favourites= UserHasFavourites::model()->find($criteria);
                
                return $favourites['resourcegroup_id'];
            
        }
        
        
        /**
         * This is the function that determines if task is in a tool
         */
        public function isTaskInThisTool($task_id,$tool_id){
           
            //detetrmine if tool is a duplicate or not
            if($this->isThisToolADuplicate($tool_id)){
                return ($this->confirmIfTaskIsInDuplicateTool($task_id,$tool_id));
                
            }else{
                return ($this->confirmIfTaskIsInTool($task_id,$tool_id));
            }
            
           
            
        }
        
        /**
         * This is the function that confirms if task is in tool
         */
        public function confirmIfTaskIsInTool($task_id,$tool_id){
                 $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("id = $task_id and parent_id = $tool_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        /**
         * This is the function that confirms if task is in duplicate tool
         */
        public function confirmIfTaskIsInDuplicateTool($task_id,$tool_id){
            
               $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('tool_has_task')
                    ->where("task_id = $task_id and tool_id = $tool_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        /**
         * This is the function that detet=rmines if a tool is a duplicate
         */
        public function isThisToolADuplicate($tool_id){
            
                  $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("id = $tool_id and is_duplicate=1");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
            
        }
        
        
        /**
         * This is the function that gets all the tool in a toolbox
         */
        public function getAllTheToolsInThisToolbox($toolbox_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resourcegroup_id=:id';
                $criteria->params = array(':id'=>$toolbox_id);
                $tools= ResourceHasResourcegroups::model()->findAll($criteria);
                
                $all_tools = [];
                foreach($tools as $tool){
                     $all_tools[] = $tool['resource_id'];
                }
            
                return $all_tools;
            
            
        }
        /**
         * This is the function that gets the toolbox with the favourite task
         */
        public function getAllTheToolboxInThisUserFavouriteContainer($user_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='user_id=:id';
                $criteria->params = array(':id'=>$user_id);
                $favourites= UserHasFavourites::model()->findAll($criteria);
                
                $all_toolboxes = [];
                foreach($favourites as $favourite){
                    $all_toolboxes[]=$favourite['resourcegroup_id'];
                }
                return $all_toolboxes;
            
        }
        
       
        /**
         * This is the function that determines if a toolbox is active and on schedule on user's subgroup(s)
         */
        public function isToolboxActiveAndOnScheduleOnUsersSubgroups($user_id,$toolbox_id){
            
            //get all the user's subgroup(s)
            $user_subgroups = [];
            $user_subgroups =$this->getAllSubgroupsForThisUser($user_id);
            
            foreach($user_subgroups as $subgroup){
                if($this->isUserOnScheduledInThisSubgroup($subgroup,$user_id)){
                   //confirm if this toolbox is on schedule on this subgroup
                    if($this->isThisToolboxOnScheduleInThisSubgroup($toolbox_id, $subgroup)){
                        return true;
                    }else{
                        return false;
                    }
                    
                    
                }else{
                    //get the group for this user
                    $group_id = $this->getTheGroupIdOfThisSubgroup($subgroup);
                    //confirm if this toolbox is on schedule on this group
                    if($this->isToolboxInThisGroupOnSchedule($group_id, $toolbox_id)){
                        return true;
                    }else{
                        return false;
                    }
                    
                }
            }
            
            
            
        }
        
         /**
         * This is the function that retrieves all task assigned to a user
         */
        public function actionListAllTasksAssignedToAUser(){
            
            //retrieve the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $usertools = $this->determineAllToolsAssignedToThisUser($userid);
            
            $allusertasks = [];
            $duplicate_task = [];
            $original_tasks=[];
            
            foreach($usertools as $usertool){
                if($this->isThisToolADuplicate($usertool)){
                    //get the duplicated task
                   $duplicate_task = array_merge($duplicate_task,$this->getTheDuplicateTasksFromThisTool($usertool));
                    
                }else{
                    //get the task in this tool
                    
                    $original_tasks = array_merge($original_tasks,$this->getOriginalTasksFromThisTool($usertool));
                }
               
                
            }
            $allusertasks = array_unique(array_merge($duplicate_task,$original_tasks));
            
            //get the details task information
            
            $required_tasks = [];
            foreach($allusertasks as $thistask){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$thistask);
                $tasks= Resources::model()->find($criteria);
                
                $required_tasks[]= $tasks;
                
                
            }
            
            
            if($usertools===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "task" =>$required_tasks
                           
                       ));
                       
                } 
            
            
            
        }
        
        
        /**
         * This is the function that gets all task in a duplicate tool
         */
        public function getTheDuplicateTasksFromThisTool($tool_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='tool_id=:id';
                $criteria->params = array(':id'=>$tool_id);
                $tasks= DuplicateToolHasTask::model()->findAll($criteria);
                
                $all_tasks = [];
                foreach($tasks as $task){
                    $all_tasks[] = $task['task_id'];
                }
                return $all_tasks;
        }
       
        
        /**
         * This is the function that gets the task from the original tools
         */
        public function getOriginalTasksFromThisTool($tool_id){
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='parent_id=:id';
                $criteria->params = array(':id'=>$tool_id);
                $tasks= Resources::model()->findAll($criteria);
                
                $all_tasks = [];
                foreach($tasks as $task){
                    $all_tasks[] = $task['id'];
                }
                return $all_tasks;
        }
        
       
        
        
         /**
         * This is the function that determines all tools assigned to a user
         */
        public function determineAllToolsAssignedToThisUser($user_id){
           //get all the subgroups this user belongs to 
            $subgroups = [];
            $subgroups = $this->getAllSubgroupsThisUserBelongTo($user_id);
            
            //get all the active and on scheduled toolboxes assigned to this subgroups
            $allsubgroup_toolboxes = [];
            
            foreach($subgroups as $subgroup){
                
                $allsubgroup_toolboxes = $this->getAllToolboxesAssignedToThisSubgroup($subgroup);
            }
           
            //get all the active and on scheduled toolboxes that was directly assigned to this user
            $alluser_toolboxes = [];
            $alluser_toolboxes = $this->getAllOnScheduledToolboxesDirectlyAssignedToUser($user_id);
            
            //merge all active and on scheduled toolboxes from both subgroups and directly to user
            $alltoolboxes = [];
            
             $alltoolboxes = array_unique(array_merge($allsubgroup_toolboxes,$alluser_toolboxes));
            
             
             //get all the tools assigned to each of these toolboxes
             $all_tools = [];
             foreach($alltoolboxes as $toolbox){
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='resourcegroup_id=:id';
                 $criteria->params = array(':id'=>$toolbox);
                 $tools= ResourceHasResourcegroups::model()->findAll($criteria);
                
                foreach($tools as $tool){
                    if($this->isThisToolOnScheduleInThisToolbox($toolbox, $tool['resource_id'])){
                        $all_tools[] = $tool['resource_id'];
                    }
                    
                }
                
                
             }
            $tools = array_unique($all_tools);
            
            //$tools = $all_tools;
            
           return  $tools;
            
            
        }
        
        
        /**
         * Just testing
         */
        public function actionjustTesting($user_id=1){
            
            $tools = [];
            $tools = $this->determineAllToolsAssignedToThisUser($user_id);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "tools" =>$tools
                         
                          
                       ));
            
        }
        
        
        /**
         * This is the function that retreives all information about both the master 
         * and the slave task for the purpose of chaining 
         */
        public function actionRetrieveAllUserTaskForChaining(){
            
           //logged in user is
            $userid = Yii::app()->user->id;
            
            $id = $_REQUEST['id'];
            //$id = 4;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='master_id=:id and user_id=:user';
            $criteria->params = array(':id'=>$id, ':user'=>$userid);
            $slavetasks= TaskToTask::model()->findAll($criteria);
            
            //list all task for this user
            $usertools = $this->determineAllToolsAssignedToThisUser($userid);
            
           $allusertasks = [];
            $duplicate_task = [];
            $original_tasks=[];
            
            foreach($usertools as $usertool){
                if($this->isThisToolADuplicate($usertool)){
                    //get the duplicated task
                   $duplicate_task = array_merge($duplicate_task,$this->getTheDuplicateTasksFromThisTool($usertool));
                    
                }else{
                    //get the task in this tool
                    
                    $original_tasks = array_merge($original_tasks,$this->getOriginalTasksFromThisTool($usertool));
                }
               
                
            }
            $allusertasks = array_unique(array_merge($duplicate_task,$original_tasks));
            
            //get the details task information
            
            $required_tasks = [];
            foreach($allusertasks as $thistask){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$thistask);
                $tasks= Resources::model()->find($criteria);
                
                $required_tasks[]= $tasks;
                
                
            }
            
            //get the parent id of the given task
                $criteria2 = new CDbCriteria();
                $criteria2->select = 'id, parent_id';
                $criteria2->condition='id=:id';
                $criteria2->params = array(':id'=>$id);
                $parent= Resources::model()->find($criteria2);
                
                //get the name of the parent id
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, name';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$parent['parent_id']);
                $parentname= Resources::model()->find($criteria3);
                
                
                if($slavetasks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "alltasks" => $required_tasks,
                            "slaves" =>$slavetasks,
                            "toolname" =>$parentname
                           
                           
                          
                       ));
                       
                } 
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all task assigned to a user
         */
        public function actionListAllSimilarTasksAcrossUserToolboxes(){
            
            //retrieve the id of the logged in user
            $userid = Yii::app()->user->id;
            
           $taskname = $_REQUEST['name'];
           // $toolid = $_REQUEST['toolid'];
           //$taskname = "Excel2010 + word 2010";
            $string = preg_replace('/\s/', '', $taskname);
            $singleTasks = explode('+',$string);
            $usertools = $this->determineAllToolsAssignedToThisUser($userid);
            
            $allusertasks = [];
            
            foreach($usertools as $usertool){
                if(!$this->isThisToolADuplicate($usertool)){
                  foreach($singleTasks as $singleTask){
                   $q = "SELECT id FROM resources where parent_id=$usertool and name REGEXP '$singleTask'" ;
                    $cmd = Yii::app()->db->createCommand($q);
                    $results = $cmd->query();
                    foreach($results as $result){
                     $allusertasks[] = $result['id'];
                    }
               }
                }
               
                
                
            }
            
            $similar_task = [];
            
            foreach($allusertasks as $allusertask){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$allusertask);
                $tasks= Resources::model()->findAll($criteria);
                
                $similar_task = array_merge($similar_task, $tasks);
            }
            
            
            
            if($similar_task===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "task" =>$similar_task,
                            "string" =>$singleTasks
                           
                           
                          
                       ));
                       
                } 
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of icon file
         */
        public function isIconTypeAndSizeLegal($domainid){
            
           $size = []; 
            if(isset($_FILES['icon']['name'])){
                $tmpName = $_FILES['icon']['tmp_name'];
                $iconFileName = $_FILES['icon']['name'];    
                $iconFileType = $_FILES['icon']['type'];
                $iconFileSize = $_FILES['icon']['size'];
            } 
           if (isset($_FILES['icon'])) {
             $filename = $_FILES['icon']['tmp_name'];
             list($width, $height) = getimagesize($filename);
           }
      

           
            $platform_width = $this->getThePlatformSetIconWidth();
            $platform_height = $this->getThePlatformSeticonHeight();
            
            $width = $width;
            $height = $height;
           
            //$size = $width * $height;
           
            $icontypes = $this->retrieveAllTheIconMimeTypes();
            
          
           
            //if(($iconFileType === 'image/png'|| $iconFileType === 'image/jpg' || $iconFileType === 'image/jpeg') && ($iconFileSize = 256 * 256)){
            if((in_array($iconFileType,$icontypes)) && ($platform_width == $width && $platform_height = $height)){
                return true;
               
            }else{
                return false;
            }
            
        }



/**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousIconName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Resourcegroup::model()->find($criteria);
            
            
            return $icon['icon'];
            
            
        }
        
        /**
         * This is the function that retrieves the previous icon size
         */
        public function retrieveThePrreviousIconSize($id){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Resourcegroup::model()->find($criteria);
            
            
            return $icon['icon_size'];
        }
		
		
		
		 /**
         * This is the function that gets the platform height setting
         */
        public function getThePlatformSeticonHeight(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_height'];
        }
		
		
		
		 /**
         * This is the function that gets the platform icon set width
         */
        public function getThePlatformSetIconWidth(){
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_width'];
        }
		
		
		
		/**
         * This is the function that retrieves all icon mime types in the platform
         */
        public function retrieveAllTheIconMimeTypes(){
            
            $icon_mimetype = [];
            $icon_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon_mime = PlatformSettings::model()->find($criteria); 
            
            $icon_mimetype = explode(',',$icon_mime['icon_mime_type']);
            foreach($icon_mimetype as $icon){
                $icon_types[] =$icon; 
                
            }
            
            return $icon_types;
            
        }
		
		
		
		/**
         * This is the function that moves icons to its directory
         */
        public function moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename){
            
            if(isset($_FILES['icon']['name'])){
                        $tmpName = $_FILES['icon']['tmp_name'];
                        $iconName = $_FILES['icon']['name'];    
                        $iconType = $_FILES['icon']['type'];
                        $iconSize = $_FILES['icon']['size'];
                  
                   }
                    
                    if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != 'toolbox_unavailable.png'){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['icons'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIconFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                         if($icon_filename != 'toolbox_unavailable.png'){
                             
                             if($this->removeTheExistingIconFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['icons'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                           }
                         }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingIconFile($id){
            
            if($this->isTheIconNotTheDefault($id)){
                //retreve the existing zip file from the database
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Resourcegroup::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               $directoryPath = "c:\\xampp\htdocs\appspace_assets\\icons\\";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['icon'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
            
                
            }else{
                return true;
            }
            
            
        }
        
	
         /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheIconNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Resourcegroup::model()->find($criteria);
                
                if($icon['icon'] == 'toolbox_unavailable.png' || $icon['icon'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIconFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, icon';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Resourcegroup::model()->find($criteria);
                
                if($icon['icon']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }

        
         /*
      * This is the function that determines if a domain is exempted from having an initiator verifier
      */
     public function isInitiatorVerifierRequired($domain_id){
        
         if($this->doesPlatformSupportsInitiatorVerifier() == true){
              if($this->isDomainExemptedFromHavingInitiatorVerifier($domain_id)== true){
                return false;
              }else{
                return true;
              }
         }else{
             return false;
         }
        
         
     }
     
     /**
      * This is the function that determines if a domain supports initiator verifier
      */
     public function isDomainExemptedFromHavingInitiatorVerifier($domain_id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $domain = DomainPolicy::model()->find($criteria); 
            
            if($domain['exempt_domain_initiator_verifier'] == 1){
                return true;
            }else{
                return false;
            }
     }
     
     /**
      * This is the function that determines if the platform supports initiator verifier
      */
     public function doesPlatformSupportsInitiatorVerifier(){
         
         if($this->isPlatformInSupportOfHavingInitiatorVerifier()== true){
             return true;
         }else{
             return false;
         }
         
     }
     
     /**
      * This is the function that determines if this platform supports initiator verifier
      */
     public function isPlatformInSupportOfHavingInitiatorVerifier(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $platform = PlatformSettings::model()->find($criteria); 
            
            if($platform['enable_domain_initiator_verifier'] == 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
     /**
      * This is the function that determines if domain supports platform checker verifier
      */
     public function doesPlatformSupportsCheckerVerifier(){
         
         if($this->isPlatformInSupportOfHavingCheckerVerifier()== true){
             return true;
         }else{
             return false;
         }
     }
     
     
     /** 
      * This is the function that gets the checker verifier value from the database
      */
     public function isPlatformInSupportOfHavingCheckerVerifier(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $platform = PlatformSettings::model()->find($criteria); 
            
            if($platform['enable_platform_checker_verifier'] == 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     /**
      * This is the funtion that confirms a box or folder for storage
      */
     public function actionconfirmTheStorageOfThisBoxOrFolder(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisBoxOrFolder($id);
          
         if($this->isConfirmedStorageOfThisBoxOrFolderSuccessful($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            
                            "msg" => "Confirmation of Box or Folder storage is successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => "Confirmation of Box or Folder storage is not successful. Possibly storage was not requested or the box is already on storage"
                               )
                       );
         }
         
     }
     
     
     
     /**
      * This is the function that gets the domain id given the box of folder id
      */
     public function getTheDomainIdOfThisBoxOrFolder($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $box = Resourcegroup::model()->find($criteria);
            
            return $box['domain_id'];
         
     }
     
     
     /**
      * This is the function that confirms the storage of a box or folder at the domain level
      */
     public function isConfirmedStorageOfThisBoxOrFolderSuccessful($id,$domain_id){
         
         if($this->isBoxOrFolderNotInStorage($id)){
             if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isThisBoxOrFolderCreatedOrJustUpdated($id)){
                 if($this->isConfirmationOfBoxOrFolderStorageASucess($id)){
                     return true;
                 }else{
                    return false;
                }
             }else{
                 return false;
             }
             
             
         }else{
             return false;
         }
             
         }else{
             return false;
         }
         
         
     }
     
     
     
     /**
      * This is the function that confirms if a box or shoulder is just created or updated
      */
     /**
      * This is the function that determines if confirmation had been provided by the domain
      */
     public function isThisBoxOrFolderCreatedOrJustUpdated($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $box = Resourcegroup::model()->find($criteria);
            
            if($box['is_document_initiated_or_updated'] == 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
     /**
      * This is the function that determines if box or folder confirmation is a success
      */
     public function isConfirmationOfBoxOrFolderStorageASucess($id){
         
         $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('resourcegroup',
                            array(
                                   'is_storage_confirmed_by_domain_verifier'=>1,
                                   'verifier_user_id'=>Yii::app()->user->id,
                                   'storage_confirmed_by_domain_verifier_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
     }
     
     
     /**
      * This is the function that does the checking of confirmed storage request
      */
     public function actioncheckTheStorageOfThisBoxOrFolder(){
       
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisBoxOrFolder($id);
          
         if($this->isCheckedStorageOfThisBoxOrFolderSuccessful($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            
                            "msg" => "Successfully checked Box or Folder for storage"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => "Checking of Box or Folder for storage is not successful.Possibly storage was not requested or confirmed or the box is already on storage"
                               )
                       );
         }
         
         
         
     }
     
     
     /**
      * This is the fuction that checks if box or folders are fit for srorage
      */
     public function isCheckedStorageOfThisBoxOrFolderSuccessful($id,$domain_id){
         if($this->isBoxOrFolderNotInStorage($id)){
             if($this->doesPlatformSupportsCheckerVerifier()){
             if($this->isInitiatorVerifierRequired($domain_id)){
                 if($this->isDomainConfirmationInPlace($id)){
                     if($this->isCheckingBoxOrFolderSuccessful($id)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }else{
               if($this->isThisBoxOrFolderCreatedOrJustUpdated($id)){
                   
                  if($this->isCheckingBoxOrFolderSuccessful($id)){
                     return true;
                  }else{
                     return false;
                 }
               }else{
                   return false;
               }
                
                 
             }
         }else{
             if($this->isInitiatorVerifierRequired($domain_id)){
                 if($this->isDomainConfirmationInPlace($id)){
                     if($this->isCheckingBoxOrFolderSuccessful($id)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }else{
                 
                 if($this->isThisBoxOrFolderCreatedOrJustUpdated($id)){
                     if($this->isCheckingBoxOrFolderLeadingToStorageSuccessful($id)){
                        return true;
                    }else{
                     return false;
                    }
                     
                 }else{
                     return false;
                 }
                 
             }
         }
         } else{
             return false;
         }
         
     }
    
     
     /**
      * This is the function that determines if confirmation had been provided by the domain
      */
     public function isDomainConfirmationInPlace($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $box = Resourcegroup::model()->find($criteria);
            
            if($box['is_storage_confirmed_by_domain_verifier'] == 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     /**
      * This is the function that determines if checking of boxes or folders is successful 
      */
     public function isCheckingBoxOrFolderSuccessful($id){
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resourcegroup',
                            array(
                                   'is_storage_checked_by_platform_checker'=>1,
                                   'platform_checker_id'=>Yii::app()->user->id,
                                   'storage_checked_by_platform_checker_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
      /**
      * This is the function that determines if checking of boxes or folders is successful 
      */
     public function isCheckingBoxOrFolderLeadingToStorageSuccessful($id){
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resourcegroup',
                            array(
                                   'is_box_in_storage'=>1,
                                   'is_storage_checked_by_platform_checker'=>1,
                                   'platform_checker_id'=>Yii::app()->user->id,
                                   'storage_checked_by_platform_checker_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that ensures the successfully checking at the platform level leads to storage
      */
     public function isCheckingBoxOrFolderLeadsToStorage($id){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resourcegroup',
                            array(
                                   'is_box_in_storage'=>1,
                                   'is_storage_checked_by_platform_checker'=>1,
                                   'platform_checker_id'=>Yii::app()->user->id,
                                   'storage_checked_by_platform_checker_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
     }
     
     /**
      * This is the function that does the verification of box or folder for storage
      */
     public function actionverifyTheStorageOfThisBoxOrFolder(){
         
          $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisBoxOrFolder($id);
          
         if($this->isVerificationOfStorageOfThisBoxOrFolderSuccessful($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            
                            "msg" => "Successfully verified Box or Folder for storage"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => "Verification of Box or Folder for storage is not successful. Possibly storage was not checked successfully or the box is already on storage"
                               )
                       );
         }
         
     }
     
     
     
     /**
      * This is the function that verifies if storage of the box of folder is successful
      */
     public function isVerificationOfStorageOfThisBoxOrFolderSuccessful($id,$domain_id){
          if($this->isBoxOrFolderNotInStorage($id)){
           if($this->doesPlatformSupportsCheckerVerifier()){
             if($this->isBoxOrFoldersCheckedSuccessfully($id)){
                 if($this->isBoxOrFolderVerificationASuccess($id)){
                     return true;
                 }else{
                     return false;
                 }
                 
                 
             }else{
                 return false;
             }
             
        }else{
            return false;
        } 
          }else{
              return false;
          }
         
   }
     
   
   
   /**
    * This is the function that checks if box or folder is checked successfully
    */
   public function isBoxOrFoldersCheckedSuccessfully($id){
       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $box = Resourcegroup::model()->find($criteria);
            
            if($box['is_storage_checked_by_platform_checker'] == 1){
                return true;
            }else{
                return false;
            }
       
   }
   
   /**
    * This is the function that confirms the success of the box or folder verification
    */
   public function isBoxOrFolderVerificationASuccess($id){
       $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resourcegroup',
                            array(
                                   'is_box_in_storage'=>1,
                                   'is_storage_verified_by_platform_verifier'=>1,
                                   'platform_checker_verifier_id'=>Yii::app()->user->id,
                                   'storage_verified_by_platform_verifier_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                } 
       
   }
   
   
     /**
      * This is the function that does the rejection of box or folder during confirmation
      */
     public function actionrejectTheConfirmTheStorageOfThisBoxOrFolder(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisBoxOrFolder($id);
          
         if($this->isRejectionOfConfirmedStorageOfThisBoxOrFolderSuccessful($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            
                            "msg" => "Rejection of Confirmation of Box or Folder storage is successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => "Rejection of Confirmation of Box or Folder storage is not successful. Possibly storage was not requested or the box is already on storage"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that effects the rejection of confirmation of box or folder for storage at the domain level
      */
     public function isRejectionOfConfirmedStorageOfThisBoxOrFolderSuccessful($id,$domain_id){
         if($this->isBoxOrFolderNotInStorage($id)){
           if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isThisBoxOrFolderCreatedOrJustUpdated($id)){
                  if($this->isRejectionOfConfirmationOfBoxOrFolderStorageASucess($id)){
                        return true;
                  }else{
                        return false;
                  }
                 
             }else{
                 return false;
             }
            
             
         }else{
             return false;
         }
         }else{
             
             return false;
         } 
         
     }
     
     /**
      * This is the function that confirms if rejection of confirmed storage box or folder is a success
      */
     public function isRejectionOfConfirmationOfBoxOrFolderStorageASucess($id){
         
         $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('resourcegroup',
                            array(
                                   'is_document_initiated_or_updated'=>0,
                                   'is_storage_confirmed_by_domain_verifier'=>0,
                                   'verifier_user_id'=>Yii::app()->user->id,
                                   'storage_confirmed_by_domain_verifier_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that does the rejection of box or folder storage during checking phase
      */
     public function actionrejectTheCheckingTheStorageOfThisBoxOrFolder(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisBoxOrFolder($id);
          
         if($this->isRejectionOfCheckedBoxOrFolderForStorageSuccessful($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            
                            "msg" => "Rejection of Checked Box or Folder for storage is successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => "Rejection of checked Box or Folder for storage is not successful. Possibly storage was not requested or confirmed or the box is already on storage"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that determines  the rejection of the box or folder storage during the checking phase at the domain
      */
     public function isRejectionOfCheckedBoxOrFolderForStorageSuccessful($id,$domain_id){
         if($this->isBoxOrFolderNotInStorage($id)){
             
             if($this->doesPlatformSupportsCheckerVerifier()){
             if($this->isInitiatorVerifierRequired($domain_id)){
                 if($this->isDomainConfirmationInPlace($id)){
                     if($this->isRejectionOfCheckedBoxOrFolderSuccessful($id)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }else{
              if($this->isThisBoxOrFolderCreatedOrJustUpdated($id)){
                  if($this->isRejectionOfCheckedBoxOrFolderSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
              }else{
                  return false;
              }   
              
                 
             }
         }else{
             if($this->isInitiatorVerifierRequired($domain_id)){
                 if($this->isDomainConfirmationInPlace($id)){
                     if($this->isRejectionOfCheckedBoxOrFolderNotLeadToStorage($id)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }else{
                if($this->isThisBoxOrFolderCreatedOrJustUpdated($id)){
                  if($this->isRejectionOfCheckedBoxOrFolderNotLeadToStorage($id)){
                     return true;
                    }else{
                     return false;
                 }
                    
                }else{
                    return false;
                }
                
                 
             }
         }
         }else{
             return false;
         }
         
         
     }
     
     
     /**
      * This is the function that confirms if box is not in storage
      */
     public function isBoxOrFolderNotInStorage($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $box = Resourcegroup::model()->find($criteria);
            
            if($box['is_box_in_storage'] == 0){
                return true;
            }else{
                return false;
            }
         
     }
     
     /**
      * This is the function that confirms if rejection of box or folder during the checking phase is successful
      */
     public function isRejectionOfCheckedBoxOrFolderSuccessful($id){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resourcegroup',
                            array(
                                   'is_document_initiated_or_updated'=>0,
                                   'is_storage_confirmed_by_domain_verifier'=>0,
                                   'is_storage_checked_by_platform_checker'=>0,
                                   'platform_checker_id'=>Yii::app()->user->id,
                                   'storage_checked_by_platform_checker_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
     }
     
     
     /**
      * This is the function that determines the final rejection of box or folder storage during storage request
      */
     public function isRejectionOfCheckedBoxOrFolderNotLeadToStorage($id){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resourcegroup',
                            array(
                                   'is_document_initiated_or_updated'=>0,
                                   'is_storage_confirmed_by_domain_verifier'=>0,
                                   'is_box_in_storage'=>0,
                                   'is_storage_checked_by_platform_checker'=>0,
                                   'platform_checker_id'=>Yii::app()->user->id,
                                   'storage_checked_by_platform_checker_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that does folder or box rejection during verification phase
      */
     public function actionrejectTheVerificationTheStorageOfThisBoxOrFolder(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisBoxOrFolder($id);
          
         if($this->isRejectionOfVerifiedBoxOrFolderForStorageSuccessful($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            
                            "msg" => "Rejection of Verified Box or Folder for storage is successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => "Rejection of Verified Box or Folder for storage is not successful.Possibly storage was not checked or the box is already on storage"
                               )
                       );
         }
         
     }
        
     
     
     /**
      * This is the function that determines the rejection of box or folder storage during the verification phase
      */
     public function isRejectionOfVerifiedBoxOrFolderForStorageSuccessful($id,$domain_id){
          if($this->isBoxOrFolderNotInStorage($id)){
              
           if($this->doesPlatformSupportsCheckerVerifier()){
             if($this->isBoxOrFoldersCheckedSuccessfully($id)){
                 if($this->isRejectionOfBoxOrFolderAtVerificationASuccess($id)){
                     return true;
                 }else{
                     return false;
                 }
                 
                 
             }else{
                 return false;
             }
             
        }else{
            return false;
        }
          }else{
              
              return false;
          }
          
         
     }
     
     
     /**
      * This is the function that determines if rejection at the verification phase is a success
      */
     public function isRejectionOfBoxOrFolderAtVerificationASuccess($id){
         
         $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resourcegroup',
                            array(
                                   'is_box_in_storage'=>0,
                                   'is_document_initiated_or_updated'=>0,
                                   'is_storage_confirmed_by_domain_verifier'=>0, 
                                   'is_storage_checked_by_platform_checker'=>0, 
                                   'is_storage_verified_by_platform_verifier'=>1,
                                   'platform_checker_verifier_id'=>Yii::app()->user->id,
                                   'storage_verified_by_platform_verifier_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                } 
         
     }
            
	
     
     /**
         * This is the box that retrieves all neighbours permitted to request for boxes within a box
         */
        public function actionretrieveTheNeighbourhoodsThatArePermittedToRequestForBoxes(){
            
            
            $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = NeighbourhoodsThatCouldRequestForBoxes::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all clusters permitted to request for boxes on this domain
         */
        public function actionretrieveTheClustersThatArePermittedToRequestForBoxes(){
            
            
            $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected clusters with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ClustersThatCouldRequestForBoxes::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        /**
         * This is the function that gets the domain owner id of a box & folder
         */
        public function getTheDomainOwnerOfThisBox($id){
            
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$id);
             $selected = Resourcegroup::model()->find($criteria2);
             
             return $selected['id'];
            
        }
     
        
         /**
         * This is the function that retrieves the document types that determines the batches & file to accept in a box & folder 
         */
        public function actionretrieveDocumentTpesThatDeterminesTheBatchToAcceptInABox(){
            
            
            $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected document types with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BoxToAcceptBatchesFromDocumentTypes::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
        }
        
     
        
        /**
         * This is the function that retrieves the document categories that determines the batches & file to accept in a box & folder 
         */
        public function actionretrieveDocumentCategoriesThatDeterminesTheBatchToAcceptInABox(){
            
             $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Products::model()->findAll($criteria);   
           
             //get the selected document categories with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BoxToAcceptBatchesFromDocumentCategories::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
        }
        
        
        
        
        /**
         * This is the function that retrieves the neighbours that are permitted to consume boxes & files on the platform 
         */
        public function actionretrieveNeighbourhoodsWithThePermissionToConsumeBoxes(){
            
            $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = NeighbourhoodsThatConsumeBoxesOnRequest::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
        }
        
        
        
        
         /**
         * This is the function that retrieves the clusters that are permitted to consume boxes & files on the platform 
         */
        public function actionretrieveClustersWithThePermissionToConsumeBoxes(){
            
            $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected clusters with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ClustersThatConsumeBoxesOnRequest::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
        }
        
        
        
        
        /**
         * This is the function that retrieves the processors with exclusive permission to add batches to this box & folder 
         */
        public function actionretrieveProcessorsWhoseBatchesCouldBeAcceptedByThisBox(){
            
            $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = User::model()->findAll($criteria);   
           
             //get the selected processors with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BoxToAcceptBatchesFromProcessor::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
        }
        
        
        
          /**
         * This is the function that retrieves the neighbourhoods with exclusive permission to add batches to this box & folder
         */
        public function actionretrieveNeighbourhoodsWhoseMemberBatchesCouldBeAcceptedByThisBox(){
            
            $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BoxToAcceptBatchesFromNeighbourhood::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
        }
        
        
        
            /**
         * This is the function that retrieves the clusters with exclusive permission to add batches to this box & folder
         */
        public function actionretrieveClustersWhoseMemberBatchesCouldBeAcceptedByThisBox(){
            
            $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BoxToAcceptBatchesFromCluster::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
        }
        
        
        
        
            /**
         * This is the function that selects the neighbourhoods permitted for domain box request
         * 
         */
        
        public function actionAddPermittedNeighbourhoodsForBoxesOnBox(){
            
            //get the domain policy id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('neighbourhoods_that_could_request_for_boxes', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hood'])){
               foreach($_POST['hood'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('neighbourhoods_that_could_request_for_boxes',
                	array('box_id'=>$box_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Members of the selected neighbourhood(s) will be permitted to request for this boxes & folders";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
              $msg = "There are no selected neighbourhood(s) that will be permitted to request for this boxes & folders";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       )); 
               
           }
 
        }
        
        
        
        
         /**
         * This is the function that selects the clusters permitted for domain box request
         * 
         */
        
        
        public function actionAddPermittedClustersForBoxesOnBox(){
            
            //get the domain policy id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('clusters_that_could_request_for_boxes', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['cluster'])){
               foreach($_POST['cluster'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('clusters_that_could_request_for_boxes',
                	array('box_id'=>$box_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Members of the selected clusters(s) will be permitted to request for this boxes & folders";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               $msg = "There are no selected clusters(s) that will be permitted to request for this boxes & folders";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
           
         
            
        }
        
        
        
        /**
         * This is the function that adds the document types that will determine the batches & files taht could be acceptable in a box & folder
         */
        public function actionAddDocumentTypesThatAreAcceptableToBatchesInBoxesOnBox(){
            
             //get the domain policy id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('box_to_accept_batches_from_document_types', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['types'])){
                foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('box_to_accept_batches_from_document_types',
                	array('box_id'=>$box_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These document types will determine the batches & files that will be accepted in this box & folder";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There will be no document types that will determine the batches & files to be accepted in this box & folder";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
           }
           
            
            
        }
        
        
        
        
         /**
         * This is the function that adds the document types that will determine the batches & files taht could be acceptable in a box & folder
         */
        public function actionAddDocumentCategoriesThatAreAcceptableToBatchesInBoxesOnBox(){
            
             //get the domain policy id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('box_to_accept_batches_from_document_categories', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
            if(isset($_POST['categories'])){
                foreach($_POST['categories'] as $category){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('box_to_accept_batches_from_document_categories',
                	array('box_id'=>$box_id,
				'category_id'=>$category,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These document categories will determine the batches & files to be accepted in this box & folder";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
                $msg = "There are no document categories that will determine the batches & files to be accepted in this box & folder";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
        }
        
        
        
         /**
         * This is the function that adds the neighbourhoods with the permission to collect boxes & folders on request
         */
        public function actionAddNeighbourhoodsWithPermissionToCollectBoxesOnBox(){
            
             //get the domain policy id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('neighbourhoods_that_consume_boxes_on_request', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('neighbourhoods_that_consume_boxes_on_request',
                	array('box_id'=>$box_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The members of these neighbourhoods is permitted to consume this boxes & folders";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhods that are permitted to consume this boxes & folders";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
            
            
            
        }
	
        
        
         /**
         * This is the function that adds the clusters with the permission to collect boxes & folders on request
         */
        public function actionAddClustersWithPermissionToCollectBoxesOnBox(){
            
             //get the domain policy id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('clusters_that_consume_boxes_on_request', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('clusters_that_consume_boxes_on_request',
                	array('box_id'=>$box_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The members of these clusters are permitted to consume this boxes & folders";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters that are permitted to consume this boxes & folders";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
        
        
         /**
         * This is the function that adds the processors  with the permission to add batches & filed to this box 
         */
        public function actionAddProcessorsWhoseBatchesWillBeAcceptedInThisBox(){
            
             //get the box id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('box_to_accept_batches_from_processor', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
            if(isset($_POST['processors'])){
                foreach($_POST['processors'] as $processor){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('box_to_accept_batches_from_processor',
                	array('box_id'=>$box_id,
				'processor_id'=>$processor,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The members of these processors with permission to add batches & files to this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no processors with the permission to add batches & files to this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
        
        /**
         * This is the function that adds the neighbourhoods  with the permission to add batches & filed to this box 
         */
        public function actionAddNeighbourhoodsWhosememberBatchesWillBeAcceptedInThisBox(){
            
             //get the box id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('box_to_accept_batches_from_neighbourhood', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
            if(isset($_POST['hoods'])){
                foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('box_to_accept_batches_from_neighbourhood',
                	array('box_id'=>$box_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The members of these neighbourhoods with permission to add batches & files to this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no neighbourhoods with the permission to add batches & files to this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the clusters  with the permission to add batches & filed to this box 
         */
        public function actionAddCusterssWhosememberBatchesWillBeAcceptedInThisBox(){
            
             //get the box id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('box_to_accept_batches_from_cluster', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('box_to_accept_batches_from_cluster',
                	array('box_id'=>$box_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The members of these clusters with permission to add batches & files to this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters with the permission to add batches & files to this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        /**
         * This is the function that retrieves all the blacklist assigned directly to a box
         */
public function actionretrieveTheBlacklistsDirectlyApplicableToThisBox(){
    
         $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistApplicableToBox::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}




 /**
         * This is the function that retrieves all the blacklist assigned directly to a box
         */
public function actionretrieveTheWhitelistlistsDirectlyApplicableToThisBox(){
    
         $_id = $_REQUEST['box_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             $domain_id = $this->getTheDomainOwnerOfThisBox($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='box_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistApplicableToBox::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}



/**
         * This is the function that adds the balcklists that will be applicable on a box & folder 
         */
        public function actionAddBlacklistThatWillBeApplicableToThisBox(){
            
             //get the box id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_applicable_to_box', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_applicable_to_box',
                	array('box_id'=>$box_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will directly affect the behaviour of this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will directly affect the behaviour of this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
        
        /**
         * This is the function that adds the whitelists that will be applicable on a box & folder 
         */
        public function actionAddWhitelistThatWillBeApplicableToThisBox(){
            
             //get the box id
            
            $box_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_applicable_to_box', 'box_id=:id', array(':id'=>$box_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_applicable_to_box',
                	array('box_id'=>$box_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will directly affect the behaviour of this box & folder ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will directly affect the behaviour of this box & folder";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
}
