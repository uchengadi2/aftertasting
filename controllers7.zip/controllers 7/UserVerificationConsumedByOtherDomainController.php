<?php

class UserVerificationConsumedByOtherDomainController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','requesttoconsumethisuserverification'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that requests to consume an already domain verification
         */
        public function actionrequesttoconsumethisuserverification(){
            
            $model = new UserVerificationConsumedByOtherDomain;
            $user_id = Yii::app()->user->id;
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->domain_id = $domain_id;
            $model->verification_id = $_REQUEST['id'];
            $model->date_accepted = new CDbExpression('NOW()');
                       
             if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "A new user verification consumption request is added successfully";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to request for the consumption of this user verification was not succcessful. Please try again or contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
        }
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
	
}
