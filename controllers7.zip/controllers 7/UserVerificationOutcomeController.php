<?php

class UserVerificationOutcomeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','requestuserverificationrequest','updaterequestforuserverificationrequest',
                                    'verifyingthisuserverificationrequest'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new UserVerificationOutcome;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['UserVerificationOutcome']))
		{
			$model->attributes=$_POST['UserVerificationOutcome'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}
        
        
        /**
         * This is the function that requests for own user verification
         */
        public function actionrequestuserverificationrequest(){
            
            $model = new UserVerificationOutcome;
            
            $user_id = $_REQUEST['user_id'];
            $model->user_id = $user_id;
            if(isset($_REQUEST['is_name_verification_requested'])){
                 $model->is_name_verification_requested=$_REQUEST['is_name_verification_requested'];
                 $model->date_name_verification_was_requested = new CDbExpression('NOW()');
                 $model->name_was_verification_was_requested_by = $user_id;
                 $name = $_REQUEST['name'];
                
            }else{
                 $model->is_name_verification_requested=0;
                 $model->date_name_verification_was_requested = null;
                 $model->name_was_verification_was_requested_by = null;
                $name = $_REQUEST['name'];
            }
            if(isset($_REQUEST['is_address_verification_requested'])){
                $model->is_address_verification_requested = $_REQUEST['is_address_verification_requested'];
                $model->date_address_verification_was_requested = new CDbExpression('NOW()');
                $model->address_verification_request_was_requested_by = $user_id;
                $address = $_REQUEST['home_address'];
            }else{
                $model->is_address_verification_requested = 0;
                $model->date_address_verification_was_requested = null;
                $model->address_verification_request_was_requested_by = null;
                $address = $_REQUEST['home_address'];
            }
            if(isset($_REQUEST['is_residency_expiry_verification_requested'])){
                      $model->is_residency_expiry_verification_requested = $_REQUEST['is_residency_expiry_verification_requested'];
                      $model->date_residency_expiry_verification_was_request = new CDbExpression('NOW()');
                      $model->residency_expiry_verification_was_requested_by = $user_id;
                      $residency_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['residency_expiry_date'])); 
            }else{
                $model->is_residency_expiry_verification_requested = 0;
                $model->date_residency_expiry_verification_was_request = null;
                $model->residency_expiry_verification_was_requested_by = null;
               $residency_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['residency_expiry_date']));  
            }
            if(isset($_REQUEST['is_mobile_number_verification_requested'])){
                    $model->is_mobile_number_verification_requested = $_REQUEST['is_mobile_number_verification_requested'];
                    $model->date_mobile_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->mobile_number_verification_was_requested_by = $user_id;
                    $mobile_number = $_REQUEST['mobile_number'];
            }else{
                $model->is_mobile_number_verification_requested = 0;
                $model->date_mobile_number_verification_was_requested = null;
                $model->mobile_number_verification_was_requested_by = null;
                $mobile_number = $_REQUEST['mobile_number'];
            }
            if(isset($_REQUEST['is_bvn_verification_requested'])){
                    $model->is_bvn_verification_requested = $_REQUEST['is_bvn_verification_requested'];
                     $model->date_bvn_verification_was_requested = new CDbExpression('NOW()');
                     $model->bvn_verification_was_requested_by = $user_id;
                     $bvn = $_REQUEST['bvn'];
            }else{
                    $model->is_bvn_verification_requested = 0;
                     $model->date_bvn_verification_was_requested = null;
                     $model->bvn_verification_was_requested_by = null;
                    $bvn = $_REQUEST['bvn'];
            }
            if(isset($_REQUEST['is_nin_verification_requested'])){
                    $model->is_nin_verification_requested = $_REQUEST['is_nin_verification_requested'];
                     $model->date_nin_verification_was_requested = new CDbExpression('NOW()');
                     $model->nin_verification_was_requested_by = $user_id;
                     $nin = $_REQUEST['nin']; 
            }else{
                 $model->is_nin_verification_requested = 0;
                 $model->date_nin_verification_was_requested = null;
                 $model->nin_verification_was_requested_by = null;
                $nin = $_REQUEST['nin']; 
            }
            
            if(isset($_REQUEST['is_pvc_verification_requested'])){
                    $model->is_pvc_verification_requested = $_REQUEST['is_pvc_verification_requested'];
                     $model->date_pvc_verification_was_requested = new CDbExpression('NOW()');
                     $model->pvc_verification_was_requested_by = $user_id;
                     $pvc = $_REQUEST['pvc'];
            }else{
                $model->is_pvc_verification_requested = 0;
                $model->date_pvc_verification_was_requested = null;
                $model->pvc_verification_was_requested_by = null;
                 $pvc = $_REQUEST['pvc'];
            }
            if(isset($_REQUEST['is_pension_pin_verification_requested'])){
                    $model->is_pension_pin_verification_requested = $_REQUEST['is_pension_pin_verification_requested'];
                    $model->date_pension_pin_verification_was_requested = new CDbExpression('NOW()');
                    $model->pension_pin_verification_was_requested_by = $user_id;
                    $pension_pin = $_REQUEST['pension_pin'];
            }else{
                $model->is_pension_pin_verification_requested = 0;
                $model->date_pension_pin_verification_was_requested = null;
                $model->pension_pin_verification_was_requested_by = null;
                $pension_pin = $_REQUEST['pension_pin'];
            }
            if(isset($_REQUEST['is_international_passport_number_verification_requested'])){
                    $model->is_international_passport_number_verification_requested = $_REQUEST['is_international_passport_number_verification_requested'];
                    $model->date_international_passport_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->international_passport_number_verification_was_requested_by = $user_id;
                    $passport_number = $_REQUEST['passport_number'];
            }else{
                $model->is_international_passport_number_verification_requested = 0;
                $model->date_international_passport_number_verification_was_requested =null;
                $model->international_passport_number_verification_was_requested_by = null;
                $passport_number = $_REQUEST['passport_number'];
            }
             if(isset($_REQUEST['is_international_passport_expiry_verification_requested'])){
                    $model->is_international_passport_expiry_verification_requested = $_REQUEST['is_international_passport_expiry_verification_requested'];
                    $model->date_international_passport_expiry_verification_was_requested = new CDbExpression('NOW()');
                    $model->international_passport_expiry_verification_was_requested_by = $user_id;
                    $passport_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['passport_expiry_date'])); 
            }else{
                 $model->is_international_passport_expiry_verification_requested = 0;
                 $model->date_international_passport_expiry_verification_was_requested = null;
                 $model->international_passport_expiry_verification_was_requested_by = null;
                $passport_expiry_date= date("Y-m-d H:i:s", strtotime($_REQUEST['passport_expiry_date'])); 
            }
             if(isset($_REQUEST['is_driver_licence_number_verification_requested'])){
                    $model->is_driver_licence_number_verification_requested = $_REQUEST['is_driver_licence_number_verification_requested'];
                    $model->date_driver_licence_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->driver_licence_number_verification_was_requested_by = $user_id;
                    $driving_license_number = $_REQUEST['driving_license_number'];
            }else{
                 $model->is_driver_licence_number_verification_requested = null;
                 $model->date_driver_licence_number_verification_was_requested = null;
                 $model->driver_licence_number_verification_was_requested_by = null;
                $driving_license_number = $_REQUEST['driving_license_number'];
            }
             if(isset($_REQUEST['is_driver_licence_expiry_verification_requested'])){
                    $model->is_driver_licence_expiry_verification_requested = $_REQUEST['is_driver_licence_expiry_verification_requested'];
                    $model->date_driver_licence_expiry_verification_was_requested = new CDbExpression('NOW()');
                    $model->driver_licence_expiry_verification_was_requested_by = $user_id;
                    $license_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['license_expiry_date'])); 
            }else{
                $model->is_driver_licence_expiry_verification_requested = 0;
                $model->date_driver_licence_expiry_verification_was_requested = null;
                $model->driver_licence_expiry_verification_was_requested_by = null;
                $license_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['license_expiry_date'])); 
            }
             if(isset($_REQUEST['is_email_verification_requested'])){
                    $model->is_email_verification_requested = $_REQUEST['is_email_verification_requested'];
                    $model->date_email_verification_was_requested = new CDbExpression('NOW()');
                    $model->email_verification_was_requested_by = $user_id;
                    $email = $_REQUEST['email'];
            }else{
                $model->is_email_verification_requested = 0;
                $model->date_email_verification_was_requested = null;
                $model->email_verification_was_requested_by = null;
                $email = $_REQUEST['email'];
            }
           
            if(isset($_REQUEST['is_wechat_verification_requested'])){
                    $model->is_wechat_verification_requested= $_REQUEST['is_wechat_verification_requested'];
                     $model->date_wechat_verification_was_requested = new CDbExpression('NOW()');
                     $model->wechat_verification_was_requested_by = $user_id;
                     $wechat_profile = $_REQUEST['wechat_profile'];
            }else{
                $model->is_wechat_verification_requested= 0;
                $model->date_wechat_verification_was_requested = null;
                $model->wechat_verification_was_requested_by = null;
                $wechat_profile = $_REQUEST['wechat_profile'];
            }
              if(isset($_REQUEST['is_telegram_verification_requested'])){
                    $model->is_telegram_verification_requested = $_REQUEST['is_telegram_verification_requested'];
                    $model->date_telegram_verification_was_requested = new CDbExpression('NOW()');
                    $model->telegram_verification_was_requested_by = $user_id;
                    $telegram_profile = $_REQUEST['telegram_profile'];
            }else{
                $model->is_telegram_verification_requested = 0;
                $model->date_telegram_verification_was_requested=null;
                $model->telegram_verification_was_requested_by=null;
                $telegram_profile = $_REQUEST['telegram_profile'];
            }
           
            if(isset($_REQUEST['is_whatsapp_verification_requested'])){
                    $model->is_whatsapp_verification_requested = $_REQUEST['is_whatsapp_verification_requested'];
                     $model->date_whatsapp_verification_was_requested = new CDbExpression('NOW()');
                     $model->whatsapp_verification_was_requested_by = $user_id;
                     $whatsapp_profile = $_REQUEST['whatsapp_profile'];
            }else{
                $model->is_whatsapp_verification_requested = 0;
                $model->date_whatsapp_verification_was_requested =null;
                $model->whatsapp_verification_was_requested_by = null;
                $whatsapp_profile = $_REQUEST['whatsapp_profile'];
            }
            if(isset($_REQUEST['is_facebook_verification_requested'])){
                    $model->is_facebook_verification_requested = $_REQUEST['is_facebook_verification_requested'];
                     $model->date_facebook_verification_was_requested = new CDbExpression('NOW()');
                     $model->facebook_verification_was_requested_by = $user_id;
                     $facebook_profile = $_REQUEST['facebook_profile'];
            }else{
                $model->is_facebook_verification_requested = 0;
                $model->date_facebook_verification_was_requested =null;
                $model->facebook_verification_was_requested_by = null;
                $facebook_profile = $_REQUEST['facebook_profile'];
            }
            if(isset($_REQUEST['is_tweeter_verification_requested'])){
                    $model->is_tweeter_verification_requested = $_REQUEST['is_tweeter_verification_requested'];
                     $model->date_tweeter_verification_was_requested = new CDbExpression('NOW()');
                     $model->tweeter_verification_was_requested_by = $user_id;
                     $tweeter_handle = $_REQUEST['tweeter_handle'];
            }else{
                $model->is_tweeter_verification_requested = 0;
                $model->date_tweeter_verification_was_requested = null;
                $model->tweeter_verification_was_requested_by = null;
                $tweeter_handle = $_REQUEST['tweeter_handle'];
            }
            if(isset($_REQUEST['is_youtube_verification_requested'])){
                    $model->is_youtube_verification_requested = $_REQUEST['is_youtube_verification_requested'];
                     $model->date_youtube_verification_was_requested = new CDbExpression('NOW()');
                     $model->youtube_verification_was_requested_by = $user_id;
                     $youtube_channel = $_REQUEST['youtube_channel'];
            }else{
                $model->is_youtube_verification_requested = 0;
                $model->date_youtube_verification_was_requested = null;
                $model->youtube_verification_was_requested_by = null;
                $youtube_channel = $_REQUEST['youtube_channel'];
            }
             if(isset($_REQUEST['is_linkedin_verification_requested'])){
                    $model->is_linkedin_verification_requested = $_REQUEST['is_linkedin_verification_requested'];
                     $model->date_linkedin_verification_was_requested = new CDbExpression('NOW()');
                     $model->linkedin_verification_was_requested_by = $user_id;
                     $linkedin_profile = $_REQUEST['linkedin_profile'];
            }else{
                $model->is_linkedin_verification_requested = 0;
                $model->date_linkedin_verification_was_requested = null;
                $model->linkedin_verification_was_requested_by = null;
                $linkedin_profile = $_REQUEST['linkedin_profile'];
            }
             if(isset($_REQUEST['is_instagram_verification_requested'])){
                    $model->is_instagram_verification_requested = $_REQUEST['is_instagram_verification_requested'];
                     $model->date_instagram_verification_was_requested = new CDbExpression('NOW()');
                     $model->instagram_verification_was_requested_by = $user_id;
                     $instagram_profile = $_REQUEST['instagram_profile'];
            }else{
                $model->is_instagram_verification_requested = 0;
                $model->date_instagram_verification_was_requested = null;
                $model->instagram_verification_was_requested_by = null;
                $instagram_profile = $_REQUEST['instagram_profile'];
            }
            if(isset($_REQUEST['is_website_verification_requested'])){
                    $model->is_website_verification_requested = $_REQUEST['is_website_verification_requested'];
                     $model->date_website_verification_was_request = new CDbExpression('NOW()');
                     $model->website_verification_was_requested_by = $user_id;
                     $website = $_REQUEST['website'];
            }else{
                 $model->is_website_verification_requested = 0;
                 $model->date_website_verification_was_request = null;
                 $model->website_verification_was_requested_by = null;
                $website = $_REQUEST['website'];
            }
            if(isset($_REQUEST['is_website_expiry_verification_requested'])){
                    $model->is_website_expiry_verification_requested = $_REQUEST['is_website_expiry_verification_requested'];
                     $model->date_website_expiry_verification_was_request = new CDbExpression('NOW()');
                     $model->website_expiry_verification_was_requested_by = $user_id;
                     $website_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['website_expiry_date'])); 
            }else{
                $model->is_website_expiry_verification_requested = 0;
                $model->date_website_expiry_verification_was_request = null;
                $model->website_expiry_verification_was_requested_by = null;
                $website_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['website_expiry_date'])); 
            }
            if(isset($_REQUEST['is_picture_verification_requested'])){
                    $model->is_picture_verification_requested = $_REQUEST['is_picture_verification_requested'];
                    $model->date_picture_verification_was_requested = new CDbExpression('NOW()');
                    $model->picture_verification_was_requested_by = $user_id;
                   // $icon = $_REQUEST['icon'];
                 if($_FILES['picture']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $picture = $_FILES['picture']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $picture="";
                         
                    }//end of the determine size and type statement
                }else{
                   $picture=""; 
                }
            }else{
                $model->date_picture_verification_was_requested = null;
                $model->picture_verification_was_requested_by = null;
                if($_FILES['picture']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $picture = $_FILES['picture']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $picture="";
                         
                    }//end of the determine size and type statement
                }else{
                   $picture=""; 
                }
            }
                      
          //request for this domain verification
            if($this->isUserVerificationRequestMadeSuccesfully($user_id)){
                if($model->save()){
                    if($this->isUserRecordSuccessfullyUpdated($user_id,$name,$address,$residency_expiry_date,$mobile_number,$bvn,$nin,$pvc,$pension_pin,$passport_number,$passport_expiry_date,$driving_license_number,$license_expiry_date,$email,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$linkedin_profile,$instagram_profile,$website,$website_expiry_date,$picture)){
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"The request for the verification of your information had been recieved. We will inform you when we will commence work"
                        ));
                        
                        
                    }else{
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"There were issues trying to request for your information verification. Please contact service desk for assistance"
                        ));
                    }
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"There are validation issues hence the user verification request was not successful. Please check your inputs data and try again  or contact customer service for assistance"
                        ));
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Is possible you have a pending user verification request or that you were already verified. In this case all you could do is to update the domain verification request. Please contact customer service if you need further assistance"
                        ));
            }
            
            
        }
        
        
         /**
         * This is the function that determines if domain verification request was made successfully
         */
        public function isUserVerificationRequestMadeSuccesfully($user_id){
            $model = new UserVerificationRequest;
            return $model->isUserVerificationRequestMadeSuccesfully($user_id);
        }
        
          /**
         * This is the function that updates domain information at verification
         */
        public function isUserRecordSuccessfullyUpdated($user_id,$name,$address,$residency_expiry_date,$mobile_number,$bvn,$nin,$pvc,$pension_pin,$passport_number,$passport_expiry_date,$driving_license_number,$license_expiry_date,$email,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$linkedin_profile,$instagram_profile,$website,$is_website_verification_requested,$picture){
            $model = new User;
            return $model->isUserRecordSuccessfullyUpdated($user_id,$name,$address,$residency_expiry_date,$mobile_number,$bvn,$nin,$pvc,$pension_pin,$passport_number,$passport_expiry_date,$driving_license_number,$license_expiry_date,$email,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$linkedin_profile,$instagram_profile,$website,$is_website_verification_requested,$picture);
        }
        
        
        /**
         * This is the function that test for the suitability of an icon type
         */
        public function isFileTypeSuitable(){
            $model = new User;
            return $model->isFileTypeSuitable();
        }
        
        
        
        /**
         * This is the function that updates the request for user verification
         */
        public function actionupdaterequestforuserverificationrequest(){
            $_id = $_POST['verification_id'];
            $model= UserVerificationOutcome::model()->findByPk($_id);
            $user_id = $_REQUEST['user_id'];
            
             $model->user_id = $user_id;
            if(isset($_REQUEST['is_name_verification_requested'])){
                 $model->is_name_verification_requested=$_REQUEST['is_name_verification_requested'];
                 $model->date_name_verification_was_requested = new CDbExpression('NOW()');
                 $model->name_was_verification_was_requested_by = $user_id;
                 $name = $_REQUEST['name'];
                
            }else{
                 $model->is_name_verification_requested=0;
                 $model->date_name_verification_was_requested = null;
                 $model->name_was_verification_was_requested_by = null;
                $name = $_REQUEST['name'];
            }
            if(isset($_REQUEST['is_address_verification_requested'])){
                $model->is_address_verification_requested = $_REQUEST['is_address_verification_requested'];
                $model->date_address_verification_was_requested = new CDbExpression('NOW()');
                $model->address_verification_request_was_requested_by = $user_id;
                $address = $_REQUEST['home_address'];
            }else{
                $model->is_address_verification_requested = 0;
                $model->date_address_verification_was_requested = null;
                $model->address_verification_request_was_requested_by = null;
                $address = $_REQUEST['home_address'];
            }
            if(isset($_REQUEST['is_residency_expiry_verification_requested'])){
                      $model->is_residency_expiry_verification_requested = $_REQUEST['is_residency_expiry_verification_requested'];
                      $model->date_residency_expiry_verification_was_request = new CDbExpression('NOW()');
                      $model->residency_expiry_verification_was_requested_by = $user_id;
                      $residency_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['residency_expiry_date'])); 
            }else{
                $model->is_residency_expiry_verification_requested = 0;
                $model->date_residency_expiry_verification_was_request = null;
                $model->residency_expiry_verification_was_requested_by = null;
               $residency_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['residency_expiry_date']));  
            }
            if(isset($_REQUEST['is_mobile_number_verification_requested'])){
                    $model->is_mobile_number_verification_requested = $_REQUEST['is_mobile_number_verification_requested'];
                    $model->date_mobile_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->mobile_number_verification_was_requested_by = $user_id;
                    $mobile_number = $_REQUEST['mobile_number'];
            }else{
                $model->is_mobile_number_verification_requested = 0;
                $model->date_mobile_number_verification_was_requested = null;
                $model->mobile_number_verification_was_requested_by = null;
                $mobile_number = $_REQUEST['mobile_number'];
            }
            if(isset($_REQUEST['is_bvn_verification_requested'])){
                    $model->is_bvn_verification_requested = $_REQUEST['is_bvn_verification_requested'];
                     $model->date_bvn_verification_was_requested = new CDbExpression('NOW()');
                     $model->bvn_verification_was_requested_by = $user_id;
                     $bvn = $_REQUEST['bvn'];
            }else{
                    $model->is_bvn_verification_requested = 0;
                     $model->date_bvn_verification_was_requested = null;
                     $model->bvn_verification_was_requested_by = null;
                    $bvn = $_REQUEST['bvn'];
            }
            if(isset($_REQUEST['is_nin_verification_requested'])){
                    $model->is_nin_verification_requested = $_REQUEST['is_nin_verification_requested'];
                     $model->date_nin_verification_was_requested = new CDbExpression('NOW()');
                     $model->nin_verification_was_requested_by = $user_id;
                     $nin = $_REQUEST['nin']; 
            }else{
                 $model->is_nin_verification_requested = 0;
                 $model->date_nin_verification_was_requested = null;
                 $model->nin_verification_was_requested_by = null;
                $nin = $_REQUEST['nin']; 
            }
            
            if(isset($_REQUEST['is_pvc_verification_requested'])){
                    $model->is_pvc_verification_requested = $_REQUEST['is_pvc_verification_requested'];
                     $model->date_pvc_verification_was_requested = new CDbExpression('NOW()');
                     $model->pvc_verification_was_requested_by = $user_id;
                     $pvc = $_REQUEST['pvc'];
            }else{
                $model->is_pvc_verification_requested = 0;
                $model->date_pvc_verification_was_requested = null;
                $model->pvc_verification_was_requested_by = null;
                 $pvc = $_REQUEST['pvc'];
            }
            if(isset($_REQUEST['is_pension_pin_verification_requested'])){
                    $model->is_pension_pin_verification_requested = $_REQUEST['is_pension_pin_verification_requested'];
                    $model->date_pension_pin_verification_was_requested = new CDbExpression('NOW()');
                    $model->pension_pin_verification_was_requested_by = $user_id;
                    $pension_pin = $_REQUEST['pension_pin'];
            }else{
                $model->is_pension_pin_verification_requested = 0;
                $model->date_pension_pin_verification_was_requested = null;
                $model->pension_pin_verification_was_requested_by = null;
                $pension_pin = $_REQUEST['pension_pin'];
            }
            if(isset($_REQUEST['is_international_passport_number_verification_requested'])){
                    $model->is_international_passport_number_verification_requested = $_REQUEST['is_international_passport_number_verification_requested'];
                    $model->date_international_passport_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->international_passport_number_verification_was_requested_by = $user_id;
                    $passport_number = $_REQUEST['passport_number'];
            }else{
                $model->is_international_passport_number_verification_requested = 0;
                $model->date_international_passport_number_verification_was_requested =null;
                $model->international_passport_number_verification_was_requested_by = null;
                $passport_number = $_REQUEST['passport_number'];
            }
             if(isset($_REQUEST['is_international_passport_expiry_verification_requested'])){
                    $model->is_international_passport_expiry_verification_requested = $_REQUEST['is_international_passport_expiry_verification_requested'];
                    $model->date_international_passport_expiry_verification_was_requested = new CDbExpression('NOW()');
                    $model->international_passport_expiry_verification_was_requested_by = $user_id;
                    $passport_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['passport_expiry_date'])); 
            }else{
                 $model->is_international_passport_expiry_verification_requested = 0;
                 $model->date_international_passport_expiry_verification_was_requested = null;
                 $model->international_passport_expiry_verification_was_requested_by = null;
                $passport_expiry_date= date("Y-m-d H:i:s", strtotime($_REQUEST['passport_expiry_date'])); 
            }
             if(isset($_REQUEST['is_driver_licence_number_verification_requested'])){
                    $model->is_driver_licence_number_verification_requested = $_REQUEST['is_driver_licence_number_verification_requested'];
                    $model->date_driver_licence_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->driver_licence_number_verification_was_requested_by = $user_id;
                    $driving_license_number = $_REQUEST['driving_license_number'];
            }else{
                 $model->is_driver_licence_number_verification_requested = null;
                 $model->date_driver_licence_number_verification_was_requested = null;
                 $model->driver_licence_number_verification_was_requested_by = null;
                $driving_license_number = $_REQUEST['driving_license_number'];
            }
             if(isset($_REQUEST['is_driver_licence_expiry_verification_requested'])){
                    $model->is_driver_licence_expiry_verification_requested = $_REQUEST['is_driver_licence_expiry_verification_requested'];
                    $model->date_driver_licence_expiry_verification_was_requested = new CDbExpression('NOW()');
                    $model->driver_licence_expiry_verification_was_requested_by = $user_id;
                    $license_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['license_expiry_date'])); 
            }else{
                $model->is_driver_licence_expiry_verification_requested = 0;
                $model->date_driver_licence_expiry_verification_was_requested = null;
                $model->driver_licence_expiry_verification_was_requested_by = null;
                $license_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['license_expiry_date'])); 
            }
             if(isset($_REQUEST['is_email_verification_requested'])){
                    $model->is_email_verification_requested = $_REQUEST['is_email_verification_requested'];
                    $model->date_email_verification_was_requested = new CDbExpression('NOW()');
                    $model->email_verification_was_requested_by = $user_id;
                    $email = $_REQUEST['email'];
            }else{
                $model->is_email_verification_requested = 0;
                $model->date_email_verification_was_requested = null;
                $model->email_verification_was_requested_by = null;
                $email = $_REQUEST['email'];
            }
           
            if(isset($_REQUEST['is_wechat_verification_requested'])){
                    $model->is_wechat_verification_requested= $_REQUEST['is_wechat_verification_requested'];
                     $model->date_wechat_verification_was_requested = new CDbExpression('NOW()');
                     $model->wechat_verification_was_requested_by = $user_id;
                     $wechat_profile = $_REQUEST['wechat_profile'];
            }else{
                $model->is_wechat_verification_requested= 0;
                $model->date_wechat_verification_was_requested = null;
                $model->wechat_verification_was_requested_by = null;
                $wechat_profile = $_REQUEST['wechat_profile'];
            }
              if(isset($_REQUEST['is_telegram_verification_requested'])){
                    $model->is_telegram_verification_requested = $_REQUEST['is_telegram_verification_requested'];
                    $model->date_telegram_verification_was_requested = new CDbExpression('NOW()');
                    $model->telegram_verification_was_requested_by = $user_id;
                    $telegram_profile = $_REQUEST['telegram_profile'];
            }else{
                $model->is_telegram_verification_requested = 0;
                $model->date_telegram_verification_was_requested=null;
                $model->telegram_verification_was_requested_by=null;
                $telegram_profile = $_REQUEST['telegram_profile'];
            }
           
            if(isset($_REQUEST['is_whatsapp_verification_requested'])){
                    $model->is_whatsapp_verification_requested = $_REQUEST['is_whatsapp_verification_requested'];
                     $model->date_whatsapp_verification_was_requested = new CDbExpression('NOW()');
                     $model->whatsapp_verification_was_requested_by = $user_id;
                     $whatsapp_profile = $_REQUEST['whatsapp_profile'];
            }else{
                $model->is_whatsapp_verification_requested = 0;
                $model->date_whatsapp_verification_was_requested =null;
                $model->whatsapp_verification_was_requested_by = null;
                $whatsapp_profile = $_REQUEST['whatsapp_profile'];
            }
            if(isset($_REQUEST['is_facebook_verification_requested'])){
                    $model->is_facebook_verification_requested = $_REQUEST['is_facebook_verification_requested'];
                     $model->date_facebook_verification_was_requested = new CDbExpression('NOW()');
                     $model->facebook_verification_was_requested_by = $user_id;
                     $facebook_profile = $_REQUEST['facebook_profile'];
            }else{
                $model->is_facebook_verification_requested = 0;
                $model->date_facebook_verification_was_requested =null;
                $model->facebook_verification_was_requested_by = null;
                $facebook_profile = $_REQUEST['facebook_profile'];
            }
            if(isset($_REQUEST['is_tweeter_verification_requested'])){
                    $model->is_tweeter_verification_requested = $_REQUEST['is_tweeter_verification_requested'];
                     $model->date_tweeter_verification_was_requested = new CDbExpression('NOW()');
                     $model->tweeter_verification_was_requested_by = $user_id;
                     $tweeter_handle = $_REQUEST['tweeter_handle'];
            }else{
                $model->is_tweeter_verification_requested = 0;
                $model->date_tweeter_verification_was_requested = null;
                $model->tweeter_verification_was_requested_by = null;
                $tweeter_handle = $_REQUEST['tweeter_handle'];
            }
            if(isset($_REQUEST['is_youtube_verification_requested'])){
                    $model->is_youtube_verification_requested = $_REQUEST['is_youtube_verification_requested'];
                     $model->date_youtube_verification_was_requested = new CDbExpression('NOW()');
                     $model->youtube_verification_was_requested_by = $user_id;
                     $youtube_channel = $_REQUEST['youtube_channel'];
            }else{
                $model->is_youtube_verification_requested = 0;
                $model->date_youtube_verification_was_requested = null;
                $model->youtube_verification_was_requested_by = null;
                $youtube_channel = $_REQUEST['youtube_channel'];
            }
             if(isset($_REQUEST['is_linkedin_verification_requested'])){
                    $model->is_linkedin_verification_requested = $_REQUEST['is_linkedin_verification_requested'];
                     $model->date_linkedin_verification_was_requested = new CDbExpression('NOW()');
                     $model->linkedin_verification_was_requested_by = $user_id;
                     $linkedin_profile = $_REQUEST['linkedin_profile'];
            }else{
                $model->is_linkedin_verification_requested = 0;
                $model->date_linkedin_verification_was_requested = null;
                $model->linkedin_verification_was_requested_by = null;
                $linkedin_profile = $_REQUEST['linkedin_profile'];
            }
             if(isset($_REQUEST['is_instagram_verification_requested'])){
                    $model->is_instagram_verification_requested = $_REQUEST['is_instagram_verification_requested'];
                     $model->date_instagram_verification_was_requested = new CDbExpression('NOW()');
                     $model->instagram_verification_was_requested_by = $user_id;
                     $instagram_profile = $_REQUEST['instagram_profile'];
            }else{
                $model->is_instagram_verification_requested = 0;
                $model->date_instagram_verification_was_requested = null;
                $model->instagram_verification_was_requested_by = null;
                $instagram_profile = $_REQUEST['instagram_profile'];
            }
            if(isset($_REQUEST['is_website_verification_requested'])){
                    $model->is_website_verification_requested = $_REQUEST['is_website_verification_requested'];
                     $model->date_website_verification_was_request = new CDbExpression('NOW()');
                     $model->website_verification_was_requested_by = $user_id;
                     $website = $_REQUEST['website'];
            }else{
                 $model->is_website_verification_requested = 0;
                 $model->date_website_verification_was_request = null;
                 $model->website_verification_was_requested_by = null;
                $website = $_REQUEST['website'];
            }
            if(isset($_REQUEST['is_website_expiry_verification_requested'])){
                    $model->is_website_expiry_verification_requested = $_REQUEST['is_website_expiry_verification_requested'];
                     $model->date_website_expiry_verification_was_request = new CDbExpression('NOW()');
                     $model->website_expiry_verification_was_requested_by = $user_id;
                     $website_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['website_expiry_date'])); 
            }else{
                $model->is_website_expiry_verification_requested = 0;
                $model->date_website_expiry_verification_was_request = null;
                $model->website_expiry_verification_was_requested_by = null;
                $website_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['website_expiry_date'])); 
            }
      if(isset($_REQUEST['is_picture_verification_requested'])){
                    $model->is_picture_verification_requested = $_REQUEST['is_picture_verification_requested'];
                    $model->date_picture_verification_was_requested = new CDbExpression('NOW()');
                    $model->picture_verification_was_requested_by = $user_id;
                   // $icon = $_REQUEST['icon'];
                 if($_FILES['picture']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $picture = $_FILES['picture']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $picture="";;
                         
                    }//end of the determine size and type statement
                }else{
                   $picture=$this->getTheExistingUserPicture($user_id);; 
                }
            }else{
                $model->is_picture_verification_requested = 0;
                $model->date_picture_verification_was_requested = null;
                $model->picture_verification_was_requested_by = null;
                $picture = $this->getTheExistingUserPicture($user_id);
            }
           
         
          //request for this domain verification
            if($this->isUpdateOfUserVerificationRequestMadeSuccesfully($user_id)){
                if($model->save()){
                    if($this->isUserRecordSuccessfullyUpdated($user_id,$name,$address,$residency_expiry_date,$mobile_number,$bvn,$nin,$pvc,$pension_pin,$passport_number,$passport_expiry_date,$driving_license_number,$license_expiry_date,$email,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$linkedin_profile,$instagram_profile,$website,$website_expiry_date,$picture)){
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"The request for the update on the verification of your information had been recieved. We will inform you when we will commence work"
                        ));
                        
                        
                    }else{
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"There were issues trying to request for an update on your information verification. Please contact service desk for assistance",
                           "picture"=>$picture     
                                ));
                    }
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"There are validation issues hence the user verification request update was not successful. Please check your inputs data and try again  or contact customer service for assistance"
                        ));
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Is possible you have a pending user verification request or that you were already verified. Please try again or contact customer service if you need further assistance"
                        ));
            }
            
            
            
            
        }
        
        
        /**
         * This is the function to get the deafault user photo
         */
        public function getTheDefaultUserPhoto(){
            $model = new User;
            return $model->getTheDefaultUserPhoto();
        }
        
        
        /**
         * This is the function that gets the existing user picture
         */
        public function getTheExistingUserPicture($user_id){
            $model = new User;
            return $model->getTheExistingUserPicture($user_id);
        }
        
        
         /**
         * This is the function confirms if an update to domain verification was a success
         */
        public function isUpdateOfUserVerificationRequestMadeSuccesfully($user_id){
            $model = new UserVerificationRequest;
            return $model->isUpdateOfUserVerificationRequestMadeSuccesfully($user_id);
            
        }
        
        
        /**
         * This is the function that effects a domain verification
         */
        public function actionverifyingthisuserverificationrequest(){
            
            $_id = $_POST['verification_id'];
            $model=  UserVerificationOutcome::model()->findByPk($_id);
            $user_id = $_REQUEST['user_id'];
            $model->user_id = $user_id;
            if(isset($_REQUEST['is_name_verified'])){
                 $model->is_name_verified=$_REQUEST['is_name_verified'];
                 $model->date_name_was_verified = new CDbExpression('NOW()');
                 $model->name_was_verified_by = $user_id;
                                
            }
            if(isset($_REQUEST['is_address_verified'])){
                $model->is_address_verified = $_REQUEST['is_address_verified'];
                    $model->date_address_was_verified = new CDbExpression('NOW()');
                    $model->address_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_registration_number_verified'])){
                    $model->is_registration_number_verified = $_REQUEST['is_registration_number_verified'];
                    $model->date_registration_number_was_verified = new CDbExpression('NOW()');
                    $model->registration_number_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_residency_expiry_date_verified'])){
                    $model->is_residency_expiry_date_verified = $_REQUEST['is_residency_expiry_date_verified'];
                     $model->date_residency_expiry_was_verified = new CDbExpression('NOW()');
                     $model->residency_expiry_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_bvn_verified'])){
                    $model->is_bvn_verified = $_REQUEST['is_bvn_verified'];
                     $model->date_bvn_was_verified = new CDbExpression('NOW()');
                     $model->bvn_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_nin_verified'])){
                      $model->is_nin_verified = $_REQUEST['is_nin_verified'];
                      $model->date_nin_was_verified = new CDbExpression('NOW()');
                      $model->nin_was_verified_by = $user_id;
                      
            }
            if(isset($_REQUEST['is_pvc_verified'])){
                    $model->is_pvc_verified = $_REQUEST['is_pvc_verified'];
                     $model->date_pvc_was_verified = new CDbExpression('NOW()');
                     $model->pvc_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_pension_pin_verified'])){
                    $model->is_pension_pin_verified = $_REQUEST['is_pension_pin_verified'];
                    $model->date_pension_pin_was_verified = new CDbExpression('NOW()');
                    $model->pension_pin_was_verified_by = $user_id;
                   
            }
            if(isset($_REQUEST['is_international_passport_number_verified'])){
                    $model->is_international_passport_number_verified= $_REQUEST['is_international_passport_number_verified'];
                     $model->date_international_passport_number_was_verified = new CDbExpression('NOW()');
                     $model->international_passport_number_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_drivers_licence_number_verified'])){
                    $model->is_drivers_licence_number_verified = $_REQUEST['is_drivers_licence_number_verified'];
                     $model->date_driver_licence_number_was_verified = new CDbExpression('NOW()');
                     $model->driver_licence_number_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_international_passport_expiry_verified'])){
                    $model->is_international_passport_expiry_verified = $_REQUEST['is_international_passport_expiry_verified'];
                     $model->date_passport_expiry_was_verified = new CDbExpression('NOW()');
                     $model->passport_expiry_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_drivers_licence_expiry_verified'])){
                    $model->is_drivers_licence_expiry_verified = $_REQUEST['is_drivers_licence_expiry_verified'];
                     $model->date_licence_expiry_was_verified = new CDbExpression('NOW()');
                     $model->licence_expiry_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_website_verified'])){
                    $model->is_website_verified = $_REQUEST['is_website_verified'];
                     $model->date_website_was_verified = new CDbExpression('NOW()');
                     $model->website_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_picture_verified'])){
                    $model->is_picture_verified = $_REQUEST['is_picture_verified'];
                    $model->date_picture_was_verified = new CDbExpression('NOW()');
                    $model->picture_was_verified_by = $user_id;
                   // $icon = $_REQUEST['icon'];
                 if($_FILES['picture']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $picture = $_FILES['picture']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $picture="";
                         
                    }//end of the determine size and type statement
                }else{
                   $picture=""; 
                }
            }else{
                if($_FILES['picture']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $picture = $_FILES['picture']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $picture="";
                         
                    }//end of the determine size and type statement
                }else{
                   $picture=""; 
                }
            }
            if(isset($_REQUEST['is_website_expiry_verified'])){
                    $model->is_website_expiry_verified = $_REQUEST['is_website_expiry_verified'];
                     $model->date_website_expiry_was_verified = new CDbExpression('NOW()');
                     $model->website_expiry_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_email_verified'])){
                    $model->is_email_verified = $_REQUEST['is_email_verified'];
                    $model->date_email_was_verified = new CDbExpression('NOW()');
                    $model->email_was_verified_by = $user_id;
                   
            }
            if(isset($_REQUEST['is_wechat_verified'])){
                      $model->is_wechat_verified = $_REQUEST['is_wechat_verified'];
                      $model->date_wechat_was_verified = new CDbExpression('NOW()');
                      $model->wechat_was_verified_by = $user_id;
                      
            }
            
             if(isset($_REQUEST['is_telegram_verified'])){
                      $model->is_telegram_verified = $_REQUEST['is_telegram_verified'];
                      $model->date_telegram_was_verified = new CDbExpression('NOW()');
                      $model->telegram_was_verified_by = $user_id;
                      
            }
             if(isset($_REQUEST['is_whatsapp_verified'])){
                      $model->is_whatsapp_verified = $_REQUEST['is_whatsapp_verified'];
                      $model->date_whatsapp_was_verified = new CDbExpression('NOW()');
                      $model->whatsapp_was_verified_by = $user_id;
                      
            }
              if(isset($_REQUEST['is_facebook_verified'])){
                      $model->is_facebook_verified = $_REQUEST['is_facebook_verified'];
                      $model->date_facebook_was_verified = new CDbExpression('NOW()');
                      $model->facebook_was_verified_by = $user_id;
                      
            }
              if(isset($_REQUEST['is_linkedin_verified'])){
                      $model->is_linkedin_verified = $_REQUEST['is_linkedin_verified'];
                      $model->date_linkedin_was_verified = new CDbExpression('NOW()');
                      $model->linkedin_was_verified_by = $user_id;
                      
            }
             if(isset($_REQUEST['is_tweeter_verified'])){
                      $model->is_tweeter_verified = $_REQUEST['is_tweeter_verified'];
                      $model->date_tweeter_was_verified = new CDbExpression('NOW()');
                      $model->tweeter_was_verified_by = $user_id;
                      
            }
             if(isset($_REQUEST['is_youtube_verified'])){
                      $model->is_youtube_verified = $_REQUEST['is_youtube_verified'];
                      $model->date_youtube_was_verified = new CDbExpression('NOW()');
                      $model->youtube_was_verified_by = $user_id;
                      
            }
            if(isset($_REQUEST['is_instagram_verified'])){
                      $model->is_instagram_verified = $_REQUEST['is_instagram_verified'];
                      $model->date_instagram_was_verified = new CDbExpression('NOW()');
                      $model->instagram_was_verified_by = $user_id;
                      
            }
             if(isset($_REQUEST['is_mobile_number_verified'])){
                      $model->is_mobile_number_verified = $_REQUEST['is_mobile_number_verified'];
                      $model->date_mobile_number_was_verified = new CDbExpression('NOW()');
                      $model->mobile_number_was_verified_by = $user_id;
                      
            }
           //request for this domain verification
            if($this->isTheVerificationOfThisUserVerificationRequestMadeSuccesfully($user_id)){
                if($model->save()){
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"This verification request is effected successfully"
                        ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"There was a validation issue hence the user verification request was not successful verified. Please check your inputs data and try again  or contact customer service for assistance"
                        ));
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Is possible there is no pending user verification request for this user or that this user had already been verified. In this case all you could do is to update the user verification request. Please contact customer service if you need further assistance"
                        ));
            }
            
        }
        
        
        /**
         * This is the function that effects verifications on a domain verification request
         */
        public function isTheVerificationOfThisUserVerificationRequestMadeSuccesfully($user_id){
            $model = new UserVerificationRequest;
            return $model->isTheVerificationOfThisUserVerificationRequestMadeSuccesfully($user_id);
        }
        

}
