<?php

class DesignationsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','ListAllDesignationsInThePlatform'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewDesignation','UpdateDesignation','DeleteOneDesignation','ListAllTheDesignationsInThisDomain',
                                    'ListAllDesignationsInThePlatform','ListAllSubscribedOtherDomainDesignationsInThisDomain'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that adds a new designation
         */
        public function actionAddNewDesignation(){
            
            $model=new Designations;
            
            //logged in user id is
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            $model->designation = $_POST['designation'];
           
            $model->domain_id = $domainid;
            $model->create_user_id=$userid;
            $model->create_time = new CDbExpression('NOW()');
            
             if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = "'$model->designation' designation was succesfully created by this Domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Error Creating designation '$model->designation' for this domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
            
            
        }
        
        /**
         * This is the function that updates designation information
         */
        public function actionUpdateDesignation(){
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            $_id = $_POST['id'];
            $model=Designations::model()->findByPk($_id);
            
            $model->designation = $_POST['designation'];
           
            $model->domain_id = $domainid;
            $model->update_user_id=$userid;
            $model->update_time = new CDbExpression('NOW()');
            
             if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = "'$model->designation' Designation is succesfully updated by this Domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Error Updating desigation '$model->designation' by this domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
            
        }
        
        /**
         * This is the function that deletes one designation from a domain
         */
        public function actionDeleteOneDesignation(){
            
            $_id = $_POST['id'];
            //get the name of this designation
            $designation = $this->getThisDesignationName($_id);
            $model=Designations::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$designation' Designation was Successfully Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$designation' Designation was Not Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
        
        /**
         * This is the function that retrieves all designations belonging to a domain
         */
        public function actionListAllTheDesignationsInThisDomain(){
            
             //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")){
               
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               //$criteria->condition='domain_id!=:domainid';
               //$criteria->params = array(':domainid'=>$domainid);
               $designations = Designations::model()->findAll($criteria);
                 
            if($designations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "designation" => $designations
                          
                           
                           
                          
                       ));
                       
                }
               
           }else{
               
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='domain_id!=:domainid';
               $criteria->params = array(':domainid'=>$domainid);
               $designations = Designations::model()->findAll($criteria);
                 
            if($designations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "designation" => $designations
                          
                           
                           
                          
                       ));
                       
                }
           } 
            
        }
        
        
        /**
         * This is the function that list all designations in the platform
         * 
         */
        public function actionListAllDesignationsInThePlatform(){
            
            $criteria = new CDbCriteria();
               $criteria->select = '*';
               //$criteria->condition='domain_id!=:domainid';
               //$criteria->params = array(':domainid'=>$domainid);
               $designations = Designations::model()->findAll($criteria);
                 
            if($designations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "designation" => $designations
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
         /**
         * This is the function that gets the name of a designation
         */
        public function getThisDesignationName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $designation = Designations::model()->find($criteria);   
            
            return $designation['designation'];
        }
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
          /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
                
                
                
                
                
           
           
            
           
        }
        
        
        /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        
       
        
        /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }

	
        /**
         * This is the function that list all designation belonging to other domains which a domain its consuming its resources
         */
        public function actionListAllSubscribedOtherDomainDesignationsInThisDomain(){
            
            
             //get the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
           // $domain_id = 2;
            
            //get all other domain program & event subscribed to by this domain
            $all_other_domain_programs = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id);
            
            //get the domain of these programs
            $all_program_domains = [];
            foreach($all_other_domain_programs as $program){
                $all_program_domains[] = $this->getTheDomainOfThisProgram($program);
            }
            
            //get the designation for each of this domain
            
            $all_designations = [];
            foreach($all_program_domains as $domain){
               
                $all_designations[] = $this->getTheDesignationsInThisDomain($domain);
            }
            
            //get the one dimensional array of this designation
            $serialized_designations = $this->getOneDimensionalArrayOfThisDesignationArray($all_designations);
            //get all the details of the designations        
            $all_other_domain_designations = [];
            foreach($serialized_designations as $designation){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$designation);
               $designations = Designations::model()->find($criteria);
               $all_other_domain_designations[] = $designations;
                
            }
            if($all_other_domain_designations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "designation" => $all_other_domain_designations,
                           "domain_designations"=>$all_designations,
                           "serialized_designation"=>$serialized_designations
                               
        
                       ));
                       
                }
            
        }
        
        
        
         /**
         * This is the function that gets the list of other domain program & events consumed by this domain
         */
        public function getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id){
            
            $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='category_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $items= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisProgramAndEvent($item['resourcegroup_id'],$domain_id) === false){
                             //if($this->isMediaItemWithinTheDateRange(strtotime($item['max_date']),$start_date,$end_date)){
                              $all_media[] = $item['resourcegroup_id'];
                         // }
                       }
                          
                      }
                      
                       //get the unigue sessions in this program
                                            
                      return array_unique($all_media);
        }
        
        
        /**
             * This is the function that confirms if a program belongs to a domain
             */
            public function isThisDomainTheOwnerOfThisProgramAndEvent($toolbox_id,$domain_id){
                
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("domain_id = $domain_id && id =$toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
             /**
             * This is the function that gets only the unique sessions
             */
            public function getOneDimensionalArrayOfThisDesignationArray($designations){
                
                $all_designation = [];
                if(is_array($designations)){
                    foreach($designations as $designation){
                        if(is_array($designation)){
                            foreach($designation as $des){
                               $all_designation[] =  $des;
                            }
                        }else{
                           $all_designation[] = $designation; 
                        }
                    }
                    return array_unique($all_designation);
                }else{
                    return $designations;
                }
            }
            
           /**
            * This is the function that gets the domain of this program
            */ 
            public function getTheDomainOfThisProgram($program_id){
                
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='id=:id';
                    $criteria1->params = array(':id'=>$program_id);
                    $domain= Resourcegroup::model()->find($criteria1);
                    
                    return $domain['domain_id'];
                
            }
        
        
            /**
             * This is the function that gets the keywords in a domain
             */
            public function getTheDesignationsInThisDomain($domain_id){
                
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='domain_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $designations= Designations::model()->findAll($criteria1);
                    
                    $all_domain_designations = [];
                    foreach($designations as $designation){
                        $all_domain_designations[] = $designation['id'];
                    }
                    
                    return $all_domain_designations;
                
            }
        
        
}
